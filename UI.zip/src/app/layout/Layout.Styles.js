/**
 * @ External Dependencies
 */
import styled from "styled-components";
import Container from "../shared/styles/components/Container";
import { spacing } from "../shared/styles/global/variables";

const Page = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background-color: #f3f3f3;
  ${(props) =>
    props.center &&
    `
        justify-content: center;
   `}

  ${Container} {
    padding: ${spacing.size3} 0;
  }
`;

export default Page;
