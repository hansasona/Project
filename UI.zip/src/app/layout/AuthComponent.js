/**
 * @ External Dependencies
 */
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";

/**
 * @ Internal Dependencies
 */
import Container from "../shared/styles/components/Container";
import Page from "./Layout.Styles";

const AuthComponent = () => {
  return (
    <Fragment>
      <Page center>
        <Container>
          <Outlet />
        </Container>
      </Page>
    </Fragment>
  );
};

export default AuthComponent;
