/**
 * @ External Dependencies
 */
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";
import HeaderComponent from "../shared/components/header/Header";

const MainComponent = () => {
  return (
    <Fragment>
      <HeaderComponent />
      <Outlet></Outlet>
    </Fragment>
  );
};

export default MainComponent;
