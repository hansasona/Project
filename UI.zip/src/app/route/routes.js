import React from "react";
import { Routes, Route } from "react-router-dom";

// Layout
import AuthComponent from "../layout/AuthComponent";
import MainComponent from "../layout/MainComponent";

// Auth pages
import ChangePasswordComponent from "../pages/auth/ChangePasswordComponent";
import RegisterComponent from "../pages/auth/RegisterComponent";
import ResetPasswordComponent from "../pages/auth/ResetPasswordComponent";
import { Navigate } from "react-router-dom";
import { isUserLoggedin } from "../shared/utils/localStore";
// General pages
import Home from "../pages/home/HomeComponent";
import NotFound from "../pages/NotFound";
import LoginComponent from "../pages/auth/LoginComponent";
import ProductListingComponent from "../pages/product-listing/ProductListingComponent";
import ProductConfigurationComponent from "../pages/product-configuration/ProductConfigurationComponent";

const AppRoutes = () => {
  const Protected = ({ children }) => {
    if (!isUserLoggedin()) {
      return <Navigate to="/" replace />;
    }
    return children;
  };
  return (
    <Routes>
      <Route path="/" element={<AuthComponent />}>
        <Route path="/" element={<LoginComponent />} />
        <Route path="login" default element={<LoginComponent />} />
        <Route path="register" default element={<RegisterComponent />} />
        <Route
          path="reset-password"
          default
          element={<ResetPasswordComponent />}
        />
        <Route
          path="change-password"
          default
          element={<ChangePasswordComponent />}
        />
        <Route path="home" default element={<Protected> <Home /> </Protected>} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route path="/" element={<MainComponent />}>
        <Route
          path="product-listing"
          default
          element={<Protected> <ProductListingComponent /> </Protected>}
        />
        <Route
          path="product-configuration"
          default
          element={<ProductConfigurationComponent />}
        />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
