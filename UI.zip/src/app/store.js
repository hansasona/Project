import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import userSlice from "./redux/user";
import configSlice from "./redux/config";
import notificationSlice from "./redux/notificationSlice";
import uiSlice from "./redux/uiSlice";
const reducer = combineReducers({
  user: userSlice,
  notification: notificationSlice,
  ui: uiSlice,
  config: configSlice
});
const store = configureStore({
  reducer,
});
export default store;
