import React from "react";
import styled from "styled-components";
import Button from "../../shared/styles/components/Button";
import Card, { CardBody } from "../../shared/styles/components/Card";
import {
  ConfigurationWrapper,
} from "./ProductConfiguration.Styles";
import { colors, device, spacing } from "../../shared/styles/global/variables";


export const ConfigurationSummary = styled(ConfigurationWrapper)`
  align-items:center;
  max-width:1024px;
  display:flex;
  margin:0 auto;
  flex-direction:column;
  justify-content:center;
  color:${colors.muted};
  h3 {
     color:${colors.midnight};
     margin-bottom:${spacing.size3};
  }
  ${Button} {
    margin-left:${spacing.sm};
  }
`;

export const Column = styled.div``;

export const SummaryContentWrapper = styled.div`
  display: flex;
  width:100%;
  flex-wrap: wrap;
  padding: 0 ${spacing.size2};
  @media ${device.sm} {
    flex-direction: column;
  }
  && ${Column} {
    flex: 0 0 auto;
    width: 50%;
    display: flex;
    padding: 0 ${spacing.size1};
    text-align: center;
    @media ${device.sm} {
      width: 100%;
      margin-bottom: ${spacing.size3};
    }
    ${CardBody} {
      min-height:240px;
      display:flex;
      flex-direction:column;
      align-items: center;
    }
    p {
      margin-bottom: auto;
    }
    h4 {
      margin-bottom: ${spacing.size3};
    }
  }
`;

const ConfigurationSummaryComponent = () => {
  return (
    <ConfigurationSummary>
      <h3>Configuration Summary</h3>
      <SummaryContentWrapper>
        <Column>
          <Card>
            <CardBody>
              <h4>Traditional Next Step</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&apos;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <Button>Print Summary</Button>
            </CardBody>
          </Card>        
        </Column>
        <Column>
          <Card>
            <CardBody>
              <h4>Recommended Next Step</h4>
              <p>Lorem Ipsum is galley of type and scrambled it to make a type specimen book.</p>
              <Button>Submit Summary</Button>
            </CardBody>
          </Card>
        </Column>
      </SummaryContentWrapper>
    </ConfigurationSummary>
  );
};

export default ConfigurationSummaryComponent;
