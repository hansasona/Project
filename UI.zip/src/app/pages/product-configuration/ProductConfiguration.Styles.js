import styled from "styled-components";
import {
  fontWeight,
  colors,
  fontSize,
  borderRadius,
  device,
  spacing,
} from "../../shared/styles/global/variables";
import { FormGroup, FormLabel, FormSelect } from "../../shared/styles/components/Form";
import Button from "../../shared/styles/components/Button";

// Configuration Wrapper Content styles

export const ConfigurationWrapper = styled.div`
	display: flex;
	margin-left: -${spacing.size3};
	margin-right: -${spacing.size3};
	height: calc(100vh - 122px);
	@media ${device.lg} {
		flex-direction: column;
		overflow: auto;
		height: calc(100vh - 160px);
	}
`;

export const ConfigurePreview = styled.div`
	overflow: auto;
	flex-grow: 1;
	padding: ${spacing.size3};
	@media ${device.lg} {
		width: 100%;
		overflow: visible;
		flex-grow: 1;
	}
`;

export const ConfigureHeader = styled.div`
	display: flex;
	margin-bottom: ${spacing.size1};
	align-items: center;
	h3 {
		margin-bottom: 0;
		flex-grow: 1;
	}
`;

export const ConfigureForm = styled.div`
	overflow: auto;
	border-left: solid 1px ${colors.metal};
	flex-shrink: 0;
	background: ${colors.cotton};
	max-width: 540px;
	min-width: 35%;
	padding: ${spacing.size3};
	h3 {
		margin-bottom: ${spacing.size5};
	}
	${FormLabel} {
		${Button}{
			margin-left:${spacing.size3};
		}
	}
	@media ${device.lg} {
		padding-top: 0;
		width: 100%;
		overflow: inherit;
		max-width: 100%;
		border: none;
		background: none;
	}
`;

export const ConfigurationFooter = styled.div`
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	width: 100%;
	display: flex;
	justify-content: end;
	border-top: solid 1px ${colors.metal};
	padding: ${spacing.size1} ${spacing.size2};
	background: ${colors.cotton};
	@media ${device.sm} {
		justify-content: center;
	}
`;

// Product Preview Styles

export const ConfigureList = styled.div`
	display: flex;
	border-bottom: solid 1px ${colors.metal};
	padding-bottom: ${spacing.size1};
	margin-bottom: ${spacing.size4};

	@media ${device.md} {
		flex-wrap: wrap;
	}
	li {
		margin-right: ${spacing.size3};
		display: flex;
		align-items: center;
		flex-wrap: wrap;
		label {
			font-weight: ${fontWeight.fontWeightMedium};
			margin-right: ${spacing.sm};
			margin-bottom: 0;
			white-space: nowrap;
		}
		span {
			color: ${colors.haze};
		}
		@media ${device.md} {
			flex-direction: column;
			align-items: start;
			flex-grow: 1;
			margin-bottom: ${spacing.sm};
		}
	}
	li:last-child {
		margin-left: auto;
		margin-right: 0;
		flex-wrap: nowrap;
		@media ${device.md} {
			margin-left: 0;
			flex-direction: row;
			align-items: center;
		}
	}
	@media ${device.lg} {
		margin-bottom: 0;
	}
`;

export const ProductContainer = styled.div`
	margin-bottom: ${spacing.size4};
	padding-bottom: ${spacing.size2};
	border-bottom: solid 1px ${colors.metal};
	height:100%;
	display:flex;
	flex-direction:column;
`;

export const ProductItem = styled.div`
	display: flex;
	min-height: 400px;
	justify-content: center;
	align-items: center;
	flex-grow:1;
	color: ${colors.metal};
`;

export const PreviewList = styled.ul`
	display: flex;
	margin: auto;
	justify-content: Center;
	@media ${device.md} {
		flex-wrap:wrap;
		margin-bottom: ${spacing.size2};
	}
	li {
		border: solid 1px ${colors.metal};
		height: 48px;
		width: 66px;
		align-items: center;
		display: flex;
		padding: ${spacing.xs} ${spacing.sm} ${spacing.xs};
		flex-direction: column;
		margin-right: ${spacing.xs};
		background: ${colors.cotton};
		border-radius: ${borderRadius.xs};
		color: ${colors.haze};
		label {
			margin-top: auto;
			font-size: ${fontSize.xs};
			font-weight: ${fontWeight.fontWeightMedium};
			color: ${colors.haze};
		}
		@media ${device.md} {
			margin-bottom: ${spacing.xs};
		}
	}
`;

// Pricing Content

export const PricingContainer = styled.div`
	padding-left: ${spacing.size4};
	@media ${device.lg} {
		display: none;
	}
`;

export const PricingTitleTeaser = styled.div`
	display: flex;
	position: relative;
	align-items: center;
	align-items: center;
	margin-bottom: ${spacing.size2};
	> a {
		position: absolute;
		left: -${spacing.size5};
		margin-right: ${spacing.size2};
		transition: all 0.2s ease-in-out;
		transform: rotate(180deg);
	}
	h3 {
		margin-bottom: 0;
		margin-right: ${spacing.size2};
	}
`;

export const ProductContainerComponent = styled.div`
	${(props) =>
    props.modalProduct &&
		`
		${ProductContainer}{
			margin-bottom:0;
			border-bottom:0;
		}
  `}
`;
export const ImageItem = styled.div`
`;

export const AlignCenter = styled.div`
text-align:center;
display:flex;
flex-direction:column;
justify-content:center;
`;

export const ISOFormGroup = styled(FormGroup)`
	max-width:320px;
	margin:0 auto ${spacing.size3}; 
	justify-content:center;
	${FormSelect} {
		width:100px;
	}
`;

export const PlacementImage = styled.div`
	display:flex;
	flex-wrap:wrap;
	align-items:center;
	max-width:800px;
	margin:0px auto;
	justify-content:center;
	${ImageItem} {
		border:solid 1px ${colors.metal};
		max-width:340px;
		width:100%;
		margin:${spacing.size2};
		padding:${spacing.size2};
		svg {
			width:80%;
			height:50%;
			color:${colors.metal};
		}
	}
`;