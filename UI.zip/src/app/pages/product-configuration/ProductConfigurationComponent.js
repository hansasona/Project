import React, { Fragment, useState } from "react";
import TitleComponent from "../../shared/components/TitleComponent";
import Button from "../../shared/styles/components/Button";
import Container from "../../shared/styles/components/Container";
import * as Icon from "react-bootstrap-icons";

import {
  FormCheck,
  FormCheckList,
  FormGroup,
  FormLabel,
  FormSelect,
  InlineGroup,
} from "../../shared/styles/components/Form";
import {
  ConfigurationFooter,
  ConfigurationWrapper,
  ConfigureForm,
  ConfigureHeader,
  ConfigureList,
  ConfigurePreview,
  ImageItem,
  ISOFormGroup,
  PlacementImage,
  PricingContainer,
  PricingTitleTeaser,
} from "./ProductConfiguration.Styles";

import * as icons from "react-bootstrap-icons";
import Table from "../../shared/styles/components/Table";
import LabelList from "../../shared/styles/components/LabelList";
import { Link } from "react-router-dom";
import {
  HiddenLarge,
  VisibleLarge,
} from "../../shared/styles/components/Media.styled";
import ProductContainerComponent from "./ProductContainerComponent";
import Modal from "../../shared/styles/components/modal/Modal";
import PoleLengthModalComponent from "./PoleLengthModalComponent";
import LightHeadModalComponent from "./LightHeadModalComponent";
import { Lead } from "../../shared/styles/global/typography";
import { ModalBodyScroller, ModalInlineFooter, ModalPageBodyTitle, ModalTitle } from "../../shared/styles/components/modal/Modal.Styles";
import VehiclePlacement from "../../shared/components/VehiclePlacement";

const ProductConfigurationComponent = () => {
  const [active, setActive] = useState(false);
  const [poleActive, poleModalActive] = useState(false);
  const [lightHeadActive, lightHeadModalActive] = useState(false);
  const [VehiclePlacementActive, VehiclePlacementModalActive] = useState(false);
  const [ISOPlotActive, ISOPlotModalActive] = useState(false);

  const [isVisible, setVisible] = useState(true);

  const viewProductPreview = () => {
    setActive(true);
  };

  const viewPoleLengthModal = () => {
    poleModalActive(true);
  };

  const viewLightHeadModal = () => {
    lightHeadModalActive(true);
  };

  const viewVehiclePlacementModal = () => {
    VehiclePlacementModalActive(true);
  };

  const viewISOPlotModal = () => {
    ISOPlotModalActive(true);
  };

  return (
    <Fragment>
      <TitleComponent title="Product Listing" />
      <Container fluid>
        <ConfigurationWrapper>
          <ConfigurePreview>
            <ConfigureHeader>
              <h3>Your Light</h3>
              <VisibleLarge>
                <Button sm onClick={() => viewProductPreview()}>
									View Rendering
                </Button>
              </VisibleLarge>
            </ConfigureHeader>
            <ConfigureList>
              <li>
                <label>Lighting Size:</label>
                <span>Single</span>
              </li>
              <li>
                <label>Lumens:</label>
                <span>8875</span>
              </li>
              <li>
                <label>Amp Draw:</label>
                <span>6.5</span>
              </li>
              <li>
                <label>Light/Mounting:</label>
                <FormSelect>
                  <option>Light and Mounting</option>
                </FormSelect>
              </li>
            </ConfigureList>
            <HiddenLarge>
              <ProductContainerComponent />
            </HiddenLarge>
            <PricingContainer>
              <PricingTitleTeaser>
                <Link onClick={() => setVisible(!isVisible)}>
                  {isVisible ? (
                    <icons.ChevronDown size={28} />
                  ) : (
                    <icons.ChevronUp size={28} />
                  )}
                </Link>
                <h3>Pricing and Bill of Materials</h3>
                <LabelList>
                  <li>
                    <Link>View Installation Manual</Link>
                  </li>
                  <li>
                    <Link onClick={() => viewVehiclePlacementModal()}>Vehicle Placement</Link>
                  </li>
                  <li>
                    <Link onClick={() => viewISOPlotModal()}>View ISO Plot</Link>
                  </li>
                </LabelList>
              </PricingTitleTeaser>
              {isVisible && (
                <Table>
                  <thead>
                    <tr>
                      <th>QTY</th>
                      <th>MODEL</th>
                      <th>DESCRIPTION</th>
                      <th>LIST PRICE</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>PFH1P</td>
                      <td>Pioneer Plus Floodlight, 75 Watts, White, 12VDC</td>
                      <td>$1202</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>PFH1P</td>
                      <td>Pioneer Plus Floodlight, 75 Watts, White, 12VDC</td>
                      <td>$1202</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>PFH1P</td>
                      <td>Pioneer Plus Floodlight, 75 Watts, White, 12VDC</td>
                      <td>$1202</td>
                    </tr>
                  </tbody>
                </Table>
              )}
            </PricingContainer>
          </ConfigurePreview>
          <ConfigureForm>
            <h3>Additional Options</h3>
            <div>
              <FormGroup>
                <FormLabel>Choose a Model:</FormLabel>
                <FormSelect>
                  <option>Pioneer Plus Floodlight, 75 Watts</option>
                </FormSelect>
              </FormGroup>
              <FormGroup>
                <FormLabel>Choose a Color:</FormLabel>
                <FormCheckList>
                  <FormCheck>
                    <input type="radio" name="color" />
                    <span>White</span>
                  </FormCheck>
                  <FormCheck>
                    <input type="radio" name="color" />
                    <span>Black</span>
                  </FormCheck>
                </FormCheckList>
              </FormGroup>
              <FormGroup>
                <FormLabel>Choose a Voltage</FormLabel>
                <FormCheckList>
                  <FormCheck>
                    <input type="radio" name="voltage" />
                    <span>White</span>
                  </FormCheck>
                  <FormCheck>
                    <input type="radio" name="voltage" />
                    <span>Black</span>
                  </FormCheck>
                </FormCheckList>
              </FormGroup>
              <FormGroup>
                <FormLabel>Pole/Ped Mount Adapter With Handle</FormLabel>
                <FormCheckList>
                  <FormCheck>
                    <input type="checkbox" name="pole" />
                    <span>White</span>
                  </FormCheck>
                  <FormCheck>
                    <input type="checkbox" name="pole" />
                    <span>Black</span>
                  </FormCheck>
                </FormCheckList>
              </FormGroup>
              <FormGroup>
                <FormLabel>Choose a Mount</FormLabel>
                <FormSelect>
                  <option>3100 Series, Through Body</option>
                </FormSelect>
              </FormGroup>
              <FormGroup>
                <FormLabel>Pole Length</FormLabel>
                <InlineGroup>
                  <FormSelect>
                    <option>3100 Series, Through Body</option>
                  </FormSelect>
                  <Button xs default onClick={() => viewPoleLengthModal()}>
										Customize Pole Length
                  </Button>
                </InlineGroup>
              </FormGroup>
              <FormGroup>
                <FormLabel>Option 
                  <Button xs default onClick={() => viewLightHeadModal()}>Show Lighthead Layout Diagram</Button>
                </FormLabel>
                <FormCheckList>
                  <FormCheck>
                    <input type="radio" name="lightHead" />
                    <span>Floodlights</span>
                  </FormCheck>
                  <FormCheck>
                    <input type="radio" name="lightHead" />
                    <span>Spotlights</span>
                  </FormCheck>
                </FormCheckList>
              </FormGroup>
              <FormGroup>
                <FormLabel>Input Wire</FormLabel>
                <FormSelect>
                  <option>3100 Series, Through Body</option>
                </FormSelect>
              </FormGroup>
              <FormGroup>
                <FormLabel>Choose a Placement</FormLabel>
                <FormCheckList>
                  <FormCheck>
                    <input type="radio" name="placement" />
                    <span>Top</span>
                  </FormCheck>
                  <FormCheck>
                    <input type="radio" name="placement" />
                    <span>Bottom</span>
                  </FormCheck>
                </FormCheckList>
              </FormGroup>
            </div>
          </ConfigureForm>
          <ConfigurationFooter>
            <Button>Add to cart</Button>
          </ConfigurationFooter>
        </ConfigurationWrapper>
        {/* <ConfigurationSummaryComponent /> */}
      </Container>  
      {/* Product View Modal */}
      <Modal
        active={active}
        hideModal={() => setActive(false)}
        pageBodyModal
        fullScreen
        size="xl"
      >
        <ModalPageBodyTitle>
          <ModalTitle>Your Light</ModalTitle>
        </ModalPageBodyTitle>
        <ModalBodyScroller>
          <ProductContainerComponent />
        </ModalBodyScroller>     
      </Modal>
      {/* View Cart Modal */}
      <Modal
        active={poleActive}
        hideModal={() => poleModalActive(false)}
        pageBodyModal
        size="lg"
      >
        <ModalPageBodyTitle>
          <ModalTitle>Customize Your Pole Length</ModalTitle>
        </ModalPageBodyTitle>
        <ModalBodyScroller>
          <PoleLengthModalComponent />
        </ModalBodyScroller>
        <VisibleLarge>
          <ModalInlineFooter>
            <Button>Done</Button>
          </ModalInlineFooter>
        </VisibleLarge>     
      </Modal>
      {/* Light Head Modal Modal */}
      <Modal
        active={lightHeadActive}
        hideModal={() => lightHeadModalActive(false)}
        pageBodyModal
        size="lg"
      >
        <ModalPageBodyTitle>
          <ModalTitle>Lighthead Layout Diagram</ModalTitle>
        </ModalPageBodyTitle>
        <ModalBodyScroller>
          <LightHeadModalComponent />
        </ModalBodyScroller>
        <VisibleLarge>
          <ModalInlineFooter>
            <Button>Done</Button>
          </ModalInlineFooter>
        </VisibleLarge>  
      </Modal>
      <Modal
        active={VehiclePlacementActive}
        hideModal={() => VehiclePlacementModalActive(false)}
        modalType="fullscreen"
        title="Vehicle Placement"
        size="lg"
        scrollable
      >
        <VehiclePlacement />
      </Modal>

      <Modal
        active={ISOPlotActive}
        hideModal={() => ISOPlotModalActive(false)}
        title=""
        modalType="fullscreen"
        size="lg"
      >
        <ModalPageBodyTitle CenterAlign>
          <ModalTitle>ISO Plot</ModalTitle>
          <ISOFormGroup inline>
            <FormLabel>Distance to Ground:</FormLabel>
            <FormSelect small><option>12 Feet</option></FormSelect>
          </ISOFormGroup>
        </ModalPageBodyTitle>
        <ModalBodyScroller>
          <PlacementImage>
            <ImageItem><Icon.ImageAlt size={72} /></ImageItem>
          </PlacementImage>
        </ModalBodyScroller>
      </Modal>
     
    </Fragment>
  );
};

export default ProductConfigurationComponent;
