import React from "react";
import styled from "styled-components";
import { borderRadius, colors, spacing } from "../../shared/styles/global/variables";

import * as Icon from "react-bootstrap-icons";

export const ProductImage = styled.div`
	width: 360px;
	flex-shrink: 0;
	background: ${colors.fog};
	border: solid 1px ${colors.metal};
	height: 300px;
	margin-right: ${spacing.size3};
	justify-content: center;
	align-items: center;
	color: ${colors.metal};
	border-radius: ${borderRadius.xs};
	display: flex;
  margin:0 auto ${spacing.size3};
`;

const LightHeadModalComponent = () => {
  return (
    <ProductImage>
      <Icon.ImageAlt size={72} />
    </ProductImage>
  );
};

export default LightHeadModalComponent;
