import React, { Fragment } from "react";
import styled from "styled-components";
import * as icons from "react-bootstrap-icons";
import Modal from "../../shared/styles/components/modal/Modal";
import * as Icon from "react-bootstrap-icons";

import {
  PreviewList,
  ProductContainer,
  ProductItem,
} from "./ProductConfiguration.Styles";
import { Link } from "react-router-dom";
import { colors, spacing } from "../../shared/styles/global/variables";
import { ModalBodyScroller, ModalPageBodyTitle, ModalTitle } from "../../shared/styles/components/modal/Modal.Styles";

export const ConfigurationWrapper = styled.div`
	display: flex;
	
`;

export const ImageControl = styled.div`
  display:flex;
  align-items:center;
  justify-content:center;
  padding:${spacing.size2};
  a {
    margin:0 ${spacing.sm};
  }
`;

export const ProductImage = styled.div`
  display:flex;
  align-items:center;
  justify-content:center;
  padding:${spacing.size5}; 
  color:${colors.metal};
  
  svg {
    border:solid 1px ${colors.metal};
    max-width:300px;
    max-height:300px;
    height:100%;
    width:100%;
  }
`;

export const IconProductView = styled.div`
  border:solid 1px ${colors.metal};
  height: 12px;
  width: 30px;
  margin: 5px;
  ${(props) =>
    props.perspective &&
    `
		transform: rotate(9deg);
  `}
  ${(props) =>
    props.front &&
    `
    height: 15px;
	`}
  ${(props) =>
    props.side &&
    `
    width:15px;
    height:18px;
	`}
  ${(props) =>
    props.back &&
    `
    height: 15px;
	`}
  ${(props) =>
    props.top &&
    `
    height:10px;
	`}
  ${(props) =>
    props.perspective &&
    `
		transform: rotate(9deg);
  `}
`;


const ProductContainerComponent = () => {

  const [threeSixtyActive, threeSixtyModalActive] = React.useState(false);

  const threeSixtyViewModal = () => {
    threeSixtyModalActive(true);
  };

  return (
    <ProductContainer>
      <ProductItem>
        <icons.ImageAlt size={200} />
      </ProductItem>
      <PreviewList>
        <li>
          <IconProductView perspective />
          <label>PERSPECTIVE</label>
        </li>
        <li>
          <IconProductView front />
          <label>FRONT</label>
        </li>
        <li>
          <IconProductView side />
          <label>SIDE</label>
        </li>
        <li>
          <IconProductView back />
          <label>BACK</label>
        </li>
        <li>
          <IconProductView top />
          <label>TOP</label>
        </li>
        <li onClick={() => threeSixtyViewModal()} >
          <span></span>
          <label>360</label>
        </li>
      </PreviewList>
      {/* 360 View Modal */}
      <Modal
        active={threeSixtyActive}
        hideModal={() => threeSixtyModalActive(false)}
        size="lg"
      >
        <ModalPageBodyTitle CenterAlign>
          <ModalTitle>360 View</ModalTitle>
        </ModalPageBodyTitle>
        <ModalBodyScroller>
          <ProductImage>
            <Icon.ImageAlt size={72} />
          </ProductImage>
        </ModalBodyScroller>
        <ImageControl>
          <Link><Icon.ZoomIn size={21} /> </Link>
          <Link><Icon.ZoomOut size={21} /> </Link>
          <Link><Icon.ChevronLeft size={21} /> </Link>
          <Link><Icon.ChevronRight size={21} /> </Link>
        </ImageControl>
      </Modal>
    </ProductContainer>
   
  );
};

export default ProductContainerComponent;
