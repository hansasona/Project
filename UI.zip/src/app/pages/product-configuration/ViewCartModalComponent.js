import React from "react";
import styled from "styled-components";
import Button from "../../shared/styles/components/Button";
import { FormControl, FormGroup, FormLabel } from "../../shared/styles/components/Form";
import {
  ProductImage, ProductListItem, ProductCategoryList,
  ProductCategoryListItem,
  ProductItemBody,
  ProFooterTeaser,
} from "../product-listing/ProductListing.Styles";

import * as Icon from "react-bootstrap-icons";
import { colors, fontSize, fontWeight, spacing } from "../../shared/styles/global/variables";
import { ModalBodyScroller, ModalInlineFooter, ModalPageBodyTitle, ModalTitle } from "../../shared/styles/components/modal/Modal.Styles";
import { HiddenSmall } from "../../shared/styles/components/Media.styled";


export const PriceContent = styled.div`
  display:flex;
  align-items:center;
  ${FormLabel} {
    margin:0 ${spacing.size1} 0 0;
  }
`;

export const CardInfoTeaser = styled.div`
  display:flex;
  flex-direction:column;
  margin:0 0 ${spacing.size3};
  ${FormGroup} {
   flex-grow:1;
   min-width:200px;
   margin:0 0 ${spacing.xs};
   ${FormLabel} {
    min-width:120px;
   }
  }
`;

export const PriceValue = styled.div`
  font-weight:${fontWeight.fontWeightBold};
`;



export const TotalTeaser = styled.div`
	display: flex;
  justify-content:end;
  background: ${colors.metal};
  font-size: ${fontSize.xl};
  padding: ${spacing.size2} ${spacing.size3};
  margin: 0 -${spacing.size2};
`;

export const ViewCartContainer = styled.div`
  ${ProductListItem}{
    text-align:left;
    background:none;
    padding-bottom:${spacing.size2};
    &:last-child {
      border-bottom:none;
      margin-bottom:0;
    }
  }
  ${ProFooterTeaser} {
    display:flex;
    flex-wrap:wrap;
    margin-bottom:${spacing.size2};
  }
  ${PriceContent} {
    margin:${spacing.sm} 0 ${spacing.sm} auto;
  }
  ${FormGroup} {
    padding-top:${spacing.size2};
  }
  ${FormControl} {
    height:60px;
  }
`;

export const QtyInput = styled.div`
	display: flex;
  align-items:center;
  margin-right:${spacing.size2};
  div {
    margin-left:${spacing.size1};
    display:flex;
    align-items:center;
    border-radius:4px;
    overflow:hidden;
  }
  ${FormLabel} {
    margin-bottom:0;  
  }
  ${Button} {
    width:40px;
    margin:0;
    height:28px!important;
  }
  ${FormControl} {
    width:40px;
    padding:0;
    height:28px!important;
    text-align:center;
    font-weight:${fontWeight.fontWeightBold};
  }
`;

const ViewCartModalComponent = () => {
  return (
    <>
      <ModalPageBodyTitle>
        <ModalTitle>Your Cart (1)</ModalTitle>
        <HiddenSmall>
          <Button xs>View ISO Plot</Button>
        </HiddenSmall>
      </ModalPageBodyTitle>
      <ModalBodyScroller>
        <CardInfoTeaser>
          <FormGroup inline>
            <FormLabel>Customer Email</FormLabel>
            <FormControl inlineInput fluid value="jjohnson@company.com" readOnly />
          </FormGroup>
          <FormGroup inline>
            <FormLabel>Account Number</FormLabel>
            <FormControl inlineInput fluid value="220675531" readOnly />
          </FormGroup>
          <FormGroup inline>
            <FormLabel>Purchase Order</FormLabel>
            <FormControl inlineInput fluid value="PD88725517898" readOnly />
          </FormGroup>
        </CardInfoTeaser>
        <ViewCartContainer>
          <ProductListItem>
            <ProductImage>
              <Icon.ImageAlt size={72} />
            </ProductImage>
            <ProductItemBody>
              <h5>Pioneer Plus Floodlight 75 Watts</h5>
              <ProductCategoryList>
                <ProductCategoryListItem proImage>
                  <ProductImage>
                    <Icon.ImageAlt size={72} />
                  </ProductImage>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Lighting Size:</label>
                  <span>Single</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Model Number:</label>
                  <span>PFH1P</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Lumens:</label>
                  <span>8875</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Amp Draw:</label>
                  <span>6.5, 3.25</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Voltage:</label>
                  <span>12VDC, 24VDC</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Optics Pattern:</label>
                  <span>Spot</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Color:</label>
                  <span>Black, White</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Mounting Options:</label>
                  <span>
                    Side Mount Pole, Pedestal, Universal Bail, Brow,
                    Lightbar, Recessed, Shelf, Telescoping, Through
                    Body, Tri-pod, Ground Tri-pod, Lo-Profile Pedestal,
                    DC Telescoping Pole, Side Mount Pedestal
                  </span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Lighting Size:</label>
                  <span>Single</span>
                </ProductCategoryListItem>
                <ProductCategoryListItem>
                  <label>Lighting Size:</label>
                  <span>Single</span>
                </ProductCategoryListItem>
              </ProductCategoryList>
              <PriceContent>
                <FormLabel>List Price: </FormLabel>
                <PriceValue>$1915</PriceValue>
              </PriceContent>
              <ProFooterTeaser>
                <QtyInput>
                  <FormLabel>Qty.</FormLabel>
                  <div>
                    <Button icon flat sm><Icon.DashLg size={18} /></Button>
                    <FormControl />
                    <Button icon flat sm><Icon.PlusLg size={18} /></Button>
                  </div>
                </QtyInput>
                <Button xs default>
                  Remove Product
                </Button>
              </ProFooterTeaser>
              <Button sm primary>
                Customize
              </Button>
              <FormGroup>
                <FormLabel>Special Instructions</FormLabel>
                <FormControl as="textarea" fluid />
              </FormGroup>
            </ProductItemBody>
          </ProductListItem>
        </ViewCartContainer>
        <TotalTeaser>
          <PriceContent>
            <FormLabel>Order total: </FormLabel>
            <PriceValue>$1915</PriceValue>
          </PriceContent>
        </TotalTeaser>
      </ModalBodyScroller> 
      <ModalInlineFooter>
        <Button default>Print Summery</Button>
        <Button>Submit Configuration</Button>
      </ModalInlineFooter>
    </>
  );
};

export default ViewCartModalComponent;
