import React from "react";
import styled from "styled-components";
import Button from "../../shared/styles/components/Button";
import { Lead } from "../../shared/styles/global/typography";

import {
  ConfigurationWrapper,
} from "./ProductConfiguration.Styles";
import { colors, spacing } from "../../shared/styles/global/variables";


export const ConfigurationSubmit = styled(ConfigurationWrapper)`
  align-items:center;
  flex-direction:column;
  justify-content:center;
  color:${colors.muted};
  h3 {
     color:${colors.midnight};
  }
  ${Button} {
    margin-left:${spacing.sm};
  }
`;
const ConfigurationSubmittedComponent = () => {
  return (
    <ConfigurationSubmit>
      <h3>Configuration Submitted</h3>
      <Lead>Thank you for submitting! You should receive a confirmation email shortly.</Lead>
      <p>If you submitted it by mistake <Button sm>Cancel Submission</Button></p>
    </ConfigurationSubmit>
  );
};

export default ConfigurationSubmittedComponent;
