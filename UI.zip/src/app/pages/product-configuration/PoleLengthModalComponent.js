import React from "react";
import styled from "styled-components";
import { FormSelect } from "../../shared/styles/components/Form";
import {
  ProductImage, ProductListItem, ProductCategoryList,
  ProductCategoryListItem,
  ProductItemBody,
} from "../product-listing/ProductListing.Styles";

import * as Icon from "react-bootstrap-icons";
import { device, spacing } from "../../shared/styles/global/variables";


export const InlineForm = styled.div`
  display:flex;
  align-items:center;
  padding:10px;
  flex-wrap:wrap;
  ${FormSelect} {
    margin:${spacing.xs} ${spacing.sm} ${spacing.xs} 0;
    width:120px;
  }
`;

export const ViewCartContainer = styled.div`
  display:flex;
  justify-content:center;

  ${ProductListItem}{
    background:none;
    align-items:center;
    padding-bottom:${spacing.size2};
    display:flex;
    &:last-child {
      border-bottom:none;
      margin-bottom:0;
    }
    ${ProductCategoryListItem} {
      padding:0!important;
    }
    ${ProductItemBody} {
       margin-bottom:${spacing.size2};
    }
  }
  
  ${ProductImage} {
    margin:0 0 0 ${spacing.size4};
    display:flex;
    height:200px;
    width:200px;
    @media ${device.md} {
      margin:0;
    }
  }
 
`;


const PoleLengthModalComponent = () => {
  return (
    <>
      <ViewCartContainer>
        <ProductListItem>
          <ProductItemBody>
            <ProductCategoryList>
              <ProductCategoryListItem>
                <label>Lighthead Model Number</label>
                <span>PFH1P</span>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Pole Model Number</label>
                <span>870870B2</span>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Dimension:</label>
                <InlineForm>
                  <FormSelect small><option>Pole Length</option></FormSelect>
                  <FormSelect small><option>57 in.</option></FormSelect>
                </InlineForm>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Dimension &apos;A&apos;</label>
                <span>68.5</span>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Dimension &apos; B&apos;:</label>
                <span>66 3/8</span>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Dimension &apos;H&apos;</label>
                <span>69 3/8</span>
              </ProductCategoryListItem>
              <ProductCategoryListItem>
                <label>Inner Pole Length:</label>
                <span>56</span>
              </ProductCategoryListItem>
            </ProductCategoryList>
          </ProductItemBody>
          <ProductImage>
            <Icon.ImageAlt size={72} />
          </ProductImage>
        </ProductListItem>      
      </ViewCartContainer>
    </>
  );
};

export default PoleLengthModalComponent;
