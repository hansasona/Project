// Frame Components
import React, { Fragment } from "react";
import styled from "styled-components";
import * as Icon from "react-bootstrap-icons";
import Button from "../shared/styles/components/Button";

import logo from "../../assets/images/logo.svg";
import { Brand } from "./auth/Auth.Styles";
import { Lead } from "../shared/styles/global/typography";
import { colors, fontSize, fontWeight, spacing } from "../shared/styles/global/variables";


const NotFoundContainer = styled.div`
  text-align:center;
  h1 {
    padding-top:${spacing.size8};
    font-size:${fontSize.display4};
    font-weight:${fontWeight.fontWeightThin};
    margin-bottom:${spacing.size1};
  }
  ${Lead} {
    margin-bottom:${spacing.size8};
    color:${colors.muted};
  }
`;



const NotFound = () => {
  return (
    <Fragment>
      <NotFoundContainer>
        <Brand src={logo} alt="Illumination Designer" />
        <h1>404</h1>
        <Lead>
          Looks like something broken here. The page you requested could not be
          found.
        </Lead>
        <Button hasIcon to="/dashboard">
          <Icon.ArrowLeft /> Back to Home
        </Button>
      </NotFoundContainer>
    </Fragment>
  );
};

export default NotFound;
