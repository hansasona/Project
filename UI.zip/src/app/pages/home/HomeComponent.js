import React, { Fragment, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Card, { CardBody } from "../../shared/styles/components/Card";
import {
  Brand,
  CardButtonWrapper,
  Column,
  HomeContentWrapper,
  IconWrapper,
  StyledHeaderWrapper,
  StyledTitle,
} from "./Home.Styles";

import * as icons from "react-bootstrap-icons";
import logo from "../../../assets/images/logo.svg";
import {
  Lead
} from "../../shared/styles/global/typography";
import Button from "../../shared/styles/components/Button";
import TitleComponent from "../../shared/components/TitleComponent";
import ConfigListModal from "../home/ConfigListModal";

import { colors, spacing } from "../../shared/styles/global/variables";
import { Link, useNavigate} from "react-router-dom";
import ListGroup, { NoResult } from "../../shared/styles/components/ListGroup";
import Modal from "../../shared/styles/components/modal/Modal";
import {
  FormControl,
  FormGroup,
  InputGroupAddons,
} from "../../shared/styles/components/Form";
import { getConfigs, setConfigId, createNewConfig } from "../../redux/config";
import LoadingOverlay from "../../shared/styles/ui/spinners/LoadingOverlay";
import { useHistory, withRouter } from "react-router-dom";
import { LoaderComponent } from "../../shared/styles/components/Spinner";
import MyAccountComponent from "../../shared/components/MyAccountComponent";
import { getUserId, getUserName } from "../../shared/utils/localStore";
import { pagesizeDropdownOptions } from "../../shared/constants/config";

const HomeComponent = () => {
  const dispatch = useDispatch();
  const [active, setActive] = useState(false);
  const showLoader = useSelector((state) => state.config.showLoader);
  const isLoading = useSelector((state) => state.config.isLoading);
  const navigate = useNavigate();
  const viewModalConfigureList = () => {
    setActive(true);
  };
  
  //To get the config list when page loads first time
  useEffect(() => {
    const body = {"pageSize": pagesizeDropdownOptions[0]};
    dispatch(getConfigs(body));
  }, []);
  const { configList } = useSelector((state) => state.config);
  const viewConfigData = (e, configDetails) => {
    e.preventDefault();
    dispatch(setConfigId(configDetails));
    navigate("/product-listing");
  };
  const topThree = () =>
    configList?.length ? (
      configList.map((config, index) =>
        index < 3 ? (
          <li onClick={(e) => { viewConfigData(e, config); }} key={config.id} >
            <Link>{config.configName}</Link>
          </li>
        ) : null
      )
    ) : (
      <NoResult>No Configuration Available</NoResult>
    );
  // Appends local date, time and zone to configuration file name.
  const createConfigName = () => {
    const date = new Date();
    const day = date.toDateString().slice(date.toDateString().indexOf(" ") + 1, date.toDateString().length);
    const currentTime = date.toLocaleTimeString().split(":").join(".");
    const currentDay = day.split(" ").join("-");
    const currentDate = `${currentDay}-${currentTime}`;
    //var zone = moment?.tz?.guess();
    //var abbr = moment?.tz(zone)?.format("z");
    return `${"Illumination"}-${currentDate}`;
  };
  // create new Configuration 
  const createNewConfigData = () => {
    const request = { configName: createConfigName(), userId: getUserId(), emailId: getUserName() };
    dispatch(createNewConfig(request)).unwrap()
      .then(() => navigate("/product-listing"));
  };
  return (
    <Fragment>
      <TitleComponent title="Home page" />
      <StyledHeaderWrapper>
        <a href="http://www.whelen.com" target="_blank" rel="noreferrer">
          <Brand src={logo} alt="Illumination Designer" />
        </a>
        <StyledTitle>Illumination Designer</StyledTitle>
        <MyAccountComponent />
      </StyledHeaderWrapper>
      <HomeContentWrapper>
        <Column>
          <Card flex>
            <CardBody large flex>
              <Lead>Create a New Configuration</Lead>
              <IconWrapper>
                <icons.FolderPlus
                  height={spacing.size7}
                  color={colors.concrete}
                  width={spacing.size7}
                ></icons.FolderPlus>
              </IconWrapper>
              <CardButtonWrapper>
                <Button isLoading={isLoading} onClick={() => createNewConfigData()}>Create Configuration</Button>
              </CardButtonWrapper>
            </CardBody>
          </Card>
        </Column>
        <Column>
          <Card dimmer flex>
            <CardBody large flex>
              <Lead>Or Revisit and Existing Configuration</Lead>
              { showLoader ? (
                <LoaderComponent />
              ) : (
                <ListGroup>
                  { topThree() }
                </ListGroup>
              )}
              <CardButtonWrapper>
                <Button onClick={() => viewModalConfigureList()}>
									View all Configurations
                </Button>
              </CardButtonWrapper>
            </CardBody>
          </Card>
        </Column>
      </HomeContentWrapper>
      <Modal
        active={active}
        hideModal={() => setActive(false)}
        title="Configuration List"
        size="sm"
      >
        <ConfigListModal />
      </Modal>
    </Fragment>
  );
};

export default HomeComponent;
