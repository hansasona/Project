import styled from "styled-components";

import {
  colors,
  device,
  fontWeight,
  spacing,
} from "../../shared/styles/global/variables";
import ListGroup from "../../shared/styles/components/ListGroup";
import { Lead } from "../../shared/styles/global/typography";
import MyAccountComponent from "../../shared/components/MyAccountComponent";
import { MyAccount } from "../../shared/components/header/Header.Styles";

export const Brand = styled.img`
  width: 8rem;
  margin-bottom: ${spacing.size4};
  @media ${device.sm} {
    width: 6rem;
  }
`;

export const StyledHeaderWrapper = styled.header`
  text-align: center;
  margin-bottom: ${spacing.size5};
  ${MyAccount} {
    position:absolute;
    right:1rem;
    top:0;
    text-align:left;
    border:none;
  }
`;

export const StyledTitle = styled.h2`
  font-weight: ${fontWeight.fontWeightMedium};
`;

export const Column = styled.div``;

export const HomeContentWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  padding: 0 ${spacing.size2};
  @media ${device.sm} {
    flex-direction: column;
  }
  && ${Column} {
    flex: 0 0 auto;
    width: 50%;
    display: flex;
    padding: 0 ${spacing.size1};
    text-align: center;
    @media ${device.sm} {
      width: 100%;
      margin-bottom: ${spacing.size3};
    }
    ${Lead} {
      margin-bottom: ${spacing.size3};
    }

    ${ListGroup} {
      max-height: 200px;
      overflow: auto;
      border: solid 1px ${colors.metal};
      margin-bottom: ${spacing.size3};
      text-align: left;
    }
  }
`;

export const CardButtonWrapper = styled.div`
  margin-top: auto;
`;

export const IconWrapper = styled.div`
  margin: ${spacing.size3} ${spacing.size4} ${spacing.size6};
  flex-grow: 1;
  display: flex;
  align-items: center;
  justify-content: center;
`;


export const ConfigListPager = styled.div`
  padding-top: ${spacing.size3};
  flex-grow: 1;
  display: flex;
  align-items: center;
  ol {
    margin-left:auto;
    display:flex;
    li {
      margin:0 ${spacing.size1};
      &.disable {
        color:${colors.gray50};
      }
    }
  }
`;