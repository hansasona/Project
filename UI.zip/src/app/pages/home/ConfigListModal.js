import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  FormControl,
  InputGroupAddons,
  LinkClose,
} from "../../shared/styles/components/Form";
import * as icons from "react-bootstrap-icons";
import Select from "react-select";
import Card from "../../shared/styles/components/Card";
import { getConfigs, setConfigId } from "../../redux/config";
import ReactTooltip from "react-tooltip";
import reactStringReplace from "react-string-replace";
import { ListGroupScrollList } from "../../shared/styles/components/ListGroup";
import { ConfigListPager } from "./Home.Styles";
import { LoaderComponent } from "../../shared/styles/components/Spinner";
import { Link, useNavigate} from "react-router-dom";
import { pagesizeDropdownOptions } from "../../shared/constants/config";

const ConfigListModal = () => {
  const dispatch = useDispatch();
  const { configList, lastEvaluatedKey, showLoader } = useSelector((state) => state.config);
  const [loading, setLoading] = useState(false);
  const [showReset, setShowReset] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [searchedVal, setSearchedVal] = useState("");
  const [pageSize, setPageSize] = useState(pagesizeDropdownOptions[0]);
  const [isPrevBtnActive, setIsPrevBtnActive] = useState("disabled");
  const [isNextBtnActive, setIsNextBtnActive] = useState("");
  const [prePageTokens, setPrePageTokens] = useState([]);
  const [nextPageToken, setNextPageToken] = useState("");
  const [configListData, setConfigListData] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getConfigurations(" ", " ", pageSize);
  }, []);

  useEffect(() => {
    setConfigListData(configList);
    if (lastEvaluatedKey && configList.length) {
      setNextPageToken(lastEvaluatedKey);
      setIsNextBtnActive("");
    } else {
      setIsNextBtnActive("disabled");
    }
  }, [configList]);

  // Method use to get configData
  const getConfigurations = async (pageToken, filterVal, pageVal) => {
    setConfigListData([]);
    setLoading(true);
    const body = {"pageSize": pageVal.value, "pageToken": pageToken, "filterVal": filterVal};
    dispatch(getConfigs(body));
    setLoading(false);
  };

  // function invoke on Next button click
  const btnNextClick = (e) => {
    e.preventDefault();
    prePageTokens.push(nextPageToken);
    setIsPrevBtnActive("");
    getConfigurations(nextPageToken, searchVal, pageSize);
  };
 
  // handle onChange event of the dropdown
  const pageChange = (e) => {
    setPageSize(e);
    setPrePageTokens([]);
    setIsPrevBtnActive("disabled");
    setNextPageToken("");
    getConfigurations("", searchVal, e);
  };
  
  // function invoke when Previous button click
  const btnPrevClick = (e) => {
    e.preventDefault();
    if (prePageTokens.length > 1) {
      getConfigurations(prePageTokens[prePageTokens.length - 2], searchVal, pageSize);
      prePageTokens.pop();
    } else {
      prePageTokens.pop();
      getConfigurations("", searchVal, pageSize);
      setIsPrevBtnActive("disabled");
    }
    setIsNextBtnActive("");
  };

  const viewConfigData = (e, configDetails) => {
    e.preventDefault();
    dispatch(setConfigId(configDetails));
    navigate("/product-listing");
  };

  // config data 
  const renderBody = () =>
    configListData?.length ? (
      configListData.map((config) => (
        <li key={config.id}>
          <a
            href="#"
            data-dismiss="modal"
            onClick={(e) => {
              viewConfigData(e, config);
            }}
          >
            <div
              data-tip={config.configName}
              data-for={config.configName}
            >
              {reactStringReplace(config.configName, searchedVal, (match, i) => (
                <span key={i} style={{ fontWeight: "bold" }}>
                  {match}
                </span>
              ))}
            </div>
          </a>
          <ReactTooltip
            id={config.configName}
            place="right"
            multiline
            type="light"
            effect="solid"
            className="list-tooltip"
            backgroundColor="#aba9a9"
          />
        </li>  
      ))
    ) : (
      <li>
        <div className="nodata-record">No Configuration Available</div>
      </li>
    );
  
  const onReset = () => {
    setPrePageTokens([]);
    setIsPrevBtnActive("disabled");
    setNextPageToken("");
    setSearchVal("");
    setSearchedVal("");
    setShowReset(false);
  };
  // Function uses for clear filter data
  const onLoad = () => {
    onReset();
    getConfigurations("", "", pageSize);
  };

  // Enter key handler
  const onKeyDownHandler = (e) => {
    if (e.keyCode === 13) {
      handleSearch();
    }
  };
  // function use to set filter value
  const updateInputValue = (evt) => {
    setSearchVal(evt.target.value);
    if (evt.target.value) {
      setShowReset(true);
    } else {
      setShowReset(false);
      if (searchVal) {
        onLoad();
      }
    }
  };

  // Function uses to filter configData' data
  const handleSearch = () => {
    if (searchVal) {
      // setSort(sortInside);
      setNextPageToken("");
      setSearchedVal(searchVal);
      setIsPrevBtnActive("disabled");
      setPrePageTokens([]);
      getConfigurations("", searchVal, pageSize);
      setShowReset(true);
    }
  };

  // placeholder to solve eslint error
  const handleClick = () => {};

  // Function uses for clear filter data
  const onResetHandler = (e) => {
    e.preventDefault();
    onLoad();
  };

  return (
    <>
      <InputGroupAddons>
        <icons.Search size={18} />
        <FormControl
          type="text"
          className="search"
          placeholder="Search"
          value={searchVal}
          onChange={updateInputValue}
          onKeyDown={onKeyDownHandler}
        />
        {showReset ? (
          <LinkClose as="a" href="javasript:void(0);"
            onClick={onResetHandler}
            onKeyDown={handleClick}
          >
            <icons.XLg size={18} />
          </LinkClose>
        ) : null}
      </InputGroupAddons>
      <Card dimmer>
        <ListGroupScrollList>
          { showLoader ? (
            <LoaderComponent />
          ) : (
            <div>
              { renderBody() }
            </div>
          )}
        </ListGroupScrollList>
        
      </Card>
      { !loading ? (
        <>
          <ConfigListPager>
            <Select
              onChange={pageChange}
              options={pagesizeDropdownOptions}
              name="role"
              className="select-xsdd"
              autoFocus={false}
              isSearchable={false}
              value={pageSize}
            />
            <ol>
              {isPrevBtnActive === "disabled" ? (
                <li className="breadcrumb-item disable" aria-current="page">
                  <div>Prev</div>
                </li>
              ) : (
                <li className="page-item">
                  <a href="#" onClick={btnPrevClick}>
                      Prev
                  </a>
                </li>
              )}
              <div className="pipe">|</div>
              {isNextBtnActive === "disabled" ? (
                <li className="breadcrumb-item disable">
                  <div>Next</div>
                </li>
              ) : (
                <li>
                  <a href="#" onClick={btnNextClick}>
                    Next
                  </a>
                </li>
              )}
            </ol>
          </ConfigListPager>
         
        </>
      ) : null}
    </>
  );
};
  
export default ConfigListModal;