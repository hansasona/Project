import React, { Fragment, useState } from "react";
import styled from "styled-components";
import Card, { CardBody } from "../../shared/styles/components/Card";
import { ProductImage, StyledHeaderWrapper, CloseIcon } from "./ProductListing.Styles";

import * as Icon from "react-bootstrap-icons";
import { colors, device, fontSize, spacing } from "../../shared/styles/global/variables";
import { Link } from "react-router-dom";
import Button from "../../shared/styles/components/Button";
import CompareDetailedComponent from "./CompareDetailedComponent";
import Modal from "../../shared/styles/components/modal/Modal";
import { useSelector, useDispatch } from "react-redux";
import { setCompareProducts } from "../../redux/config";

const CompareCard = styled(Card)`
  position: fixed;
  margin-bottom: ${spacing.size2};
  left: 50%;
  z-index: 102;
  bottom: ${spacing.size2};
  margin: 0;
  transform: translateX(-50%);
  box-shadow: 0 0 25px rgb(0 0 0 / 13%);

  width: 540px;
  @media ${device.sm} {
    left: ${spacing.size2};
    right: ${spacing.size2};
    width: auto;
    transform: translateX(0%);
  }

  ${StyledHeaderWrapper} {
    margin-bottom: ${spacing.size2};
  }

  ${(props) =>
    props.fadeIn &&
    `
		transition: all 0.5ms ease;
		opacity:1;  	
`};
`;

const FlexBox = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  @media ${device.sm} {
    flex-direction: column;
  }
`;

const PromoList = styled.ul`
  display: flex;
  margin-right: ${spacing.size2};
  flex-grow: 1;
  margin-bottom: 0;
  @media ${device.sm} {
    margin-right: 0;
    width: 100%;
  }
  li {
    flex-grow: 1;
    flex-basis: 60px;
    position: relative;
    margin-right: ${spacing.size1};
    @media ${device.md} {
      margin-bottom: ${spacing.size1};
    }
    &:last-child {
      margin-right: 0;
    }
    a {
      position: absolute;
      right: -5px;
      top: -5px;
      background: ${colors.blackberry};
      color: ${colors.cotton};
      font-size: ${fontSize.xs};
      height: 14px;
      width: 14px;
      line-height: 16px;
      text-align: center;
      border-radius: 50%;
      &:hover {
        color: ${colors.fog};
      }
    }
    ${ProductImage} {
      width: 100%;
      height: 60px;
    }
  }
`;

const CompareSelectionComponent = ({ isCompareOn, products, removeProduct, clearAllSelection }) => {
  const [active, setActive] = useState(false);
  const viewCompareDetailedModal = () => {
    setActive(true);
  };

  return (
    <Fragment>
      {isCompareOn && products.length && (
        <CompareCard fadeIn>
          <CardBody>
            <StyledHeaderWrapper>
              <h6>Select Up to 4 Items to Compare</h6> 
              <Button btnLink sm onClick={() => clearAllSelection()}> Clear </Button>
            </StyledHeaderWrapper>
           
            <FlexBox>
              <PromoList>
                <li>
                  <ProductImage>{typeof products[0] !== "undefined" && <Icon.ImageAlt size={36} /> } </ProductImage>
                  <Link>
                    {typeof products[0] !== "undefined" && <Icon.XLg onClick={() => removeProduct(products[0])} />}
                  </Link>
                </li>
                <li>
                  <ProductImage>{typeof products[1] !== "undefined" && <Icon.ImageAlt size={36} />}</ProductImage>
                  {typeof products[1] !== "undefined" && (
                    <Link>
                      <Icon.XLg onClick={() => removeProduct(products[1])} />
                    </Link>
                  )}
                </li>
                <li>
                  <ProductImage>{typeof products[2] !== "undefined" && <Icon.ImageAlt size={36} />}</ProductImage>
                  {typeof products[2] !== "undefined" && (
                    <Link>
                      <Icon.XLg onClick={() => removeProduct(products[2])} />
                    </Link>
                  )}
                </li>
                <li>
                  <ProductImage>{typeof products[3] !== "undefined" && <Icon.ImageAlt size={36} />}</ProductImage>
                  {typeof products[3] !== "undefined" && (
                    <Link>
                      <Icon.XLg onClick={() => removeProduct(products[3])} />
                    </Link>
                  )}
                </li>
              </PromoList>
              <Button small onClick={() => viewCompareDetailedModal()} disabled={products.length < 2}>
                Compare
              </Button>
            </FlexBox>
          </CardBody>
        </CompareCard>
      )}
      <Modal scrollable active={active} hideModal={() => setActive(false)} size="xl" title="Detailed Comparison">
        <CompareDetailedComponent />
      </Modal>
    </Fragment>
  );
};

export default CompareSelectionComponent;
