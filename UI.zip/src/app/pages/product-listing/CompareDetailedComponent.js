import React, { Fragment } from "react";
import styled from "styled-components";
import * as Icon from "react-bootstrap-icons";
import { ProductImage } from "./ProductListing.Styles";
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
} from "../../shared/styles/global/variables";
import { Lead } from "../../shared/styles/global/typography";
import {
  FormGroup,
  FormLabel,
  FormSelect,
} from "../../shared/styles/components/Form";
import { useSelector } from "react-redux";
import IsoPlotNew from "./IsoPlot";


const DetailCardContainer = styled.div`
	display: flex;
	padding-left: 100px;
	position: relative;
	margin-bottom: ${spacing.size3};
	aside {
		position: absolute;
		left: 0;
		top: 170px;
		width: 100px;
		li {
			background: ${colors.concrete};
			color: ${colors.midnight};
			min-height: 28px;
			font-weight: ${fontWeight.fontWeightBold};
			border-bottom: solid 1px ${colors.metal};
			font-size: ${fontSize.sm};
			padding: ${spacing.sm} ${spacing.sm};
		}
	}
`;

const CompareCardScroller = styled.div`
	overflow: auto;
	display: flex;
	flex-direction: column;
	flex-grow: 1;
`;

const ListContainer = styled.div`
	display: flex;
	${ProductImage} {
		margin: 0px auto ${spacing.size2};
		width: 90%;
		height: 120px;
	}
	${Lead} {
		font-size: ${fontSize.lg};
		font-weight: ${fontWeight.fontWeightMedium};
		padding: 0 ${spacing.size2};
		margin-bottom: ${spacing.size2};
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	li {
		white-space: nowrap;
		border-bottom: solid 1px ${colors.metal};
		font-size: ${fontSize.sm};
		padding: ${spacing.sm} ${spacing.sm};
		color: ${colors.haze};
	}
`;

const ListItem = styled.div`
	min-width: 160px;
	width: 25%;
	max-width: 400px;
	text-align: center;
	flex-grow: 1;
`;

const IsoTitleTeaser = styled.div`
	padding-top: ${spacing.size3};
	${FormGroup} {
		width: 300px;
		margin: 0 auto;
		flex-wrap: nowrap;
	}
	text-align: center;
	margin-bottom: ${spacing.size3};
`;
const CompareDetailedComponent = () => {
  const { compareProducts } = useSelector(state => state.config);
  return (
    <Fragment>
      <DetailCardContainer>
        <aside>
          <ul>
            <li>Voltage:</li>
            <li>Amp Draw:</li>
            <li>Wattage:</li>
            <li>Lumens:</li>
          </ul>
        </aside>
        <CompareCardScroller>
          <ListContainer>
            { compareProducts.length && compareProducts.map((prod) => (
              <ListItem key={prod.modelNumber}>
                <ProductImage>
                  <Icon.ImageAlt size={36} />
                </ProductImage>
                <Lead>{prod?.description}</Lead>
                <ul>
                  <li>{prod?.voltage ? prod?.voltage : "-"}</li>
                  <li>{prod?.ampDraw ? prod?.ampDraw : "-"}</li>
                  <li>{prod?.wattage ? prod?.wattage : "-"}</li>
                  <li>{prod?.lumens ? prod?.lumens : "-"}</li>
                </ul>
              </ListItem>
            )) }
          </ListContainer>
          <IsoTitleTeaser>
            <h4>ISO Plot Data</h4>
            <FormGroup inline>
              <FormLabel>Distance to Ground:</FormLabel>
              <FormSelect>
                <option>12 Feet</option>
              </FormSelect>
            </FormGroup>
          </IsoTitleTeaser>
          <ListContainer>
            { compareProducts.length && compareProducts.map((prod) => (
              <ListItem key={prod.modelNumber}>
                <ProductImage>
                  <Icon.ImageAlt size={36} />
                </ProductImage>
              </ListItem>
            ))}
          </ListContainer>
        </CompareCardScroller>
      </DetailCardContainer>
    </Fragment>
  );
};

export default CompareDetailedComponent;
