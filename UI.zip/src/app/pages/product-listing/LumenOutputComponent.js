import React, { Fragment } from "react";
import styled from "styled-components";
import * as Icon from "react-bootstrap-icons";
import { ProductImage } from "./ProductListing.Styles";
import { fontSize, spacing } from "../../shared/styles/global/variables";

const LumenContainer = styled.div`
	${ProductImage} {
		width: 100%;
		height: 90px;
		min-width: 100px;
	}
	padding-left: 80px;
	position: relative;
	aside {
		position: absolute;
		left: 0;
		top: 30px;
		width: 80px;
		li {
			min-height: 90px;
			margin-bottom: 8px;
			display: flex;
			align-items: center;
		}
	}
	table {
		width: 100%;
		overflow-x: auto;
		th,
		td {
			white-space: nowrap;
			font-size: ${fontSize.sm};
			padding: ${spacing.xs} ${spacing.sm};
			width: 100px;
		}
	}
`;

const TableContainer = styled.div`
	overflow: auto;
`;
const LumenOutputComponent = () => {
  return (
    <Fragment>
      <LumenContainer>
        <aside>
          <li>Spot</li>
          <li>flood</li>
        </aside>
        <TableContainer>
          <table>
            <thead>
              <tr>
                <th>300 Lumens</th>
                <th>600 Lumens</th>
                <th>900 Lumens</th>
                <th>1200 Lumens</th>
                <th>1500 Lumens</th>
                <th>2000 Lumens</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
              </tr>
              <tr>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
                <td>
                  <ProductImage>
                    <Icon.ImageAlt size={36} />
                  </ProductImage>
                </td>
              </tr>
            </tbody>
          </table>
        </TableContainer>
      </LumenContainer>
    </Fragment>
  );
};

export default LumenOutputComponent;
