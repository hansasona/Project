import React, { Fragment, useState, useEffect } from "react";
import Card, {
  CardBody,
  CardHeader,
  CardTitle,
} from "../../shared/styles/components/Card";
import { FormCheck, FormCheckList } from "../../shared/styles/components/Form";
import {
  AccordionBody,
  AccordionContent,
  AccordionHeader,
  AccordionItem,
  FilterWrapper,
} from "./ProductListing.Styles";
import { productsData } from "../../redux/user";
import { useSelector, useDispatch } from "react-redux";
const Accordion = ({ title, children }) => {
  const [isOpen, setOpen] = React.useState(false);
  return (
    <AccordionItem>
      <AccordionHeader isOpen={isOpen} onClick={() => setOpen(!isOpen)}>
        {title}
      </AccordionHeader>
      <AccordionBody isOpen={isOpen}>
        <AccordionContent>{children}</AccordionContent>
      </AccordionBody>
    </AccordionItem>
  );
};
const FilterAccordion = ({ handleFilter,currentremoveitem,filterRemove}) => {
  useEffect(() => {
    const filterObj={
      color:"White",
      modelNumber:"PSL1BB",  
      mountType:"",  
      ampDraw:"null",  
      voltage:"12V",  
      price:"1202",  
      lightSize:"Single"
    };
    dispatch(productsData(filterObj));
  }, []);
  const dispatch = useDispatch();
  const { getProductList } = useSelector((state) => state.user);
  const [colorFilter, setcolorFilter] = useState([]);
  const [lightSizeFilter, setlightSizeFilter] = useState([]);
  const [priceFilter, setpriceFilter] = useState([]);
  const [lumens, setlumens] = useState([]);
  const [mountType, setmountType] = useState([]);
  const [emissionPattern, setemissionPattern] = useState([]);
  const [voltage, setvoltage] = useState([]);
  const [lightSizeChecked, setlightSizeChecked] = useState([]);
  const [colorChecked,setcolorChecked]=useState([]);
  const [emissionCheck,setemissionCheck]=useState([]);
  const [checkmountType,setcheckmountType]=useState([]);
  const [lumenCheck,setlumenCheck]=useState([]);
  const [checkVoltage,setcheckVoltage]=useState([]);
  const [checkprice,setcheckprice]=useState([]);
  const [colorFilterdata,setcolorFilterdata]=useState([]);
 
  
  

  useEffect(() => {
    let color = getProductList?.records;
    let lightdata = getProductList?.records;
    let price = getProductList?.records;
    let lumens = getProductList?.records;
    let mountType=getProductList?.records;
    let emissionPattern=getProductList?.records;
    let voltage=getProductList?.records;

    if (voltage && voltage.length > 0) {
      voltage = voltage.filter((value, index, self) =>
        index === self.findIndex((t) => (
          t.voltage === value.voltage
        ))
      );
      setvoltage(voltage);
    }
    if (emissionPattern && emissionPattern.length > 0) {
      emissionPattern = emissionPattern.filter((value, index, self) =>
        index === self.findIndex((t) => (
          t.emissionPattern === value.emissionPattern
        ))
      );
      setemissionPattern(emissionPattern);
    }
    if (mountType && mountType.length > 0) {
      mountType = mountType.filter((value, index, self) =>

        index === self.findIndex((t) => (
          t.mountType === value.mountType
        ))
      );
      setmountType(mountType);
    }
    if (lumens && lumens.length > 0) {
      lumens = lumens.filter((value, index, self) =>

        index === self.findIndex((t) => (
          t.lumens === value.lumens
        ))
      );
      setlumens(lumens);
    }
    if (price && price.length > 0) {
      price = price.filter((value, index, self) =>

        index === self.findIndex((t) => (
          t.price === value.price
        ))
      );
      setpriceFilter(price);
    }
    if (color && color.length > 0) {
      color = color.filter((value, index, self) =>

        index === self.findIndex((t) => (
          t.color === value.color
        ))
      );
      console.log(color);
      setcolorFilter(color);
    }
    if (lightdata && lightdata.length > 0) {
      lightdata = lightdata.filter((value, index, self) =>

        index === self.findIndex((t) => (
          t.lightSize === value.lightSize
        ))
      );
      setlightSizeFilter(lightdata);
    }
  }, [getProductList]);
  
  useEffect(()=>{
    let data=new Array(lightSizeFilter.length).fill(false);
    setlightSizeChecked(data);
    let colordata=new Array(colorFilter.length).fill(false);
    setcolorChecked(colordata);
    let emissiondata=new Array(emissionPattern.length).fill(false);
    setemissionCheck(emissiondata);
    let mounttype=new Array(mountType.length).fill(false);
    setcheckmountType(mounttype);
    let lumensdata=new Array(lumens.length).fill(false);
    setlumenCheck(lumensdata);
    let voltagedata=new Array(voltage.length).fill(false);
    setcheckVoltage(voltagedata);
    let pricedata=new Array(priceFilter.length).fill(false);
    setcheckprice(pricedata);
  },[lightSizeFilter,colorFilter,emissionPattern,mountType,lumens,voltage,priceFilter]);

  useEffect(()=>{
    if(currentremoveitem.type==="size"){
      let lightposition=lightSizeFilter.findIndex(item=>item.lightSize===currentremoveitem.filter);
      handleChangeLightSize(lightposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="color"){
      setcolorFilterdata((prev)=>{
        const result = prev.filter(item=>item!==currentremoveitem.filter);
        console.log("removed checked items : ",result);
        return result;
      });
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="emissionPattern"){
      let emisiionposition=emissionPattern.findIndex(item=>item.emissionPattern===currentremoveitem.filter);
      handleChangeLightSize(emisiionposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="mountType"){
      let mountposition=mountType.findIndex(item=>item.mountType===currentremoveitem.filter);
      handleChangeLightSize(mountposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="lumens"){
      let lumenposition=lumens.findIndex(item=>item.lumens===currentremoveitem.filter);
      handleChangeLightSize(lumenposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="voltage"){
      let voltageposition=voltage.findIndex(item=>item.voltage===currentremoveitem.filter);
      handleChangeLightSize(voltageposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
    if(currentremoveitem.type==="price"){
      let priceposition=priceFilter.findIndex(item=>item.price===currentremoveitem.filter);
      handleChangeLightSize(priceposition,currentremoveitem.type);
      filterRemove(currentremoveitem.filter);
    }
  },[currentremoveitem,lightSizeFilter,colorFilter,emissionPattern,mountType,lumens,voltage,priceFilter]);

  const handleChangeLightSize=(position,type)=>{
    if(type==="size"){
      const updatedState=lightSizeChecked.map((item,index)=>{
        return index===position?!item:item;
      });
      setlightSizeChecked(updatedState);
    }
    if(type==="color"){
      const updatedcolorState=colorChecked.map((item,index)=>{
        return index===position?!item:item;
      });
      setcolorChecked(updatedcolorState);
    }
    if(type==="emissionPattern"){
      const updatedemisionState=emissionCheck.map((item,index)=>{
        return index===position?!item:item;
      });
      setemissionCheck(updatedemisionState);
    }
    if(type==="mountType"){
      const mountTypeState=checkmountType.map((item,index)=>{
        return index===position?!item:item;
      });
      setcheckmountType(mountTypeState);
    }
    if(type==="lumens"){
      const lumensState=lumenCheck.map((item,index)=>{
        return index===position?!item:item;
      });
      setlumenCheck(lumensState);
    }
    if(type==="voltage"){
      const voltageState=checkVoltage.map((item,index)=>{
        return index===position?!item:item;
      });
      setcheckVoltage(voltageState);
    }
    if(type==="price"){
      const priceState=checkprice.map((item,index)=>{
        return index===position?!item:item;
      });
      setcheckprice(priceState);
    }
  };
  const onchangeLightSize =(size,type,position)=>{
    handleFilter(size,type);
    handleChangeLightSize(position,type);
  };
  const handleFilterData = (filterdata)=>{
    let type=Object.keys(filterdata)[0];
    console.log("type",type);
    console.log("filterdata",filterdata);
    handleFilter(filterdata[type],type);
    if(type==="color"){
      setcolorFilterdata((prev)=>{
        if(prev.includes(filterdata[type])){
          let data = prev.filter(item=>item!==filterdata[type]);
          return data;
        }else{
          return [...prev,filterdata[type]];
        }
      });
    }
    // dispatch(productsData(filterdata));
  };

  useEffect(()=>{
    console.log(colorFilterdata);
  },[colorFilterdata]);
  return (
    <Fragment>
      <Card>
        <CardHeader>
          <CardTitle>Filter</CardTitle>
        </CardHeader>
        <CardBody>
          <FilterWrapper>
            <Accordion title="Size">
              <FormCheckList>
                {/* {lightSizeFilter.map((item, i) => {
                  return (item.lightSize === null ? "":<FormCheck key={i}>
                    <input type="checkbox" checked={lightSizeChecked[i]}                
                      onChange={() => onchangeLightSize(item.lightSize, "size",i)} />
                    <span>{item.lightSize}</span>
                  </FormCheck>
                  );
                })} */}
                <FormCheck>
                  <input type="checkbox"                 
                    onChange={() => dispatch(productsData({lightSize:"single"}))} />
                  <span>{"Single"}</span>
                </FormCheck>                  
              </FormCheckList>
            </Accordion>
            <Accordion title="Color">
              <FormCheckList>
                {/* {colorFilter.map((item, i) => {
                  return (item.color === null ? "":<FormCheck key={i}>
                    <input type="checkbox" checked={colorChecked[i]}    
                      onChange={() => dispatch(productsData({color:item.color}))} />
                    <span>{item.color}</span>
                  </FormCheck>
                  );
                })} */}
              </FormCheckList>
              <FormCheckList>
                <FormCheck>
                  <input type="checkbox" checked={colorFilterdata.includes("White")}   
                    onChange={() =>handleFilterData({color:"White"})} />
                  <span>{"White"}</span>
                </FormCheck>
                <FormCheck>
                  <input type="checkbox" checked={colorFilterdata.includes("Black")}   
                    onChange={() =>handleFilterData({color:"Black"})} />
                  <span>{"Black"}</span>
                </FormCheck>
                <FormCheck>
                  <input type="checkbox"  checked={colorFilterdata.includes("Black/Chrome")}    
                    onChange={() =>handleFilterData({color:"Black/Chrome"})} />
                  <span>{"Black/Chrome"}</span>
                </FormCheck>
              </FormCheckList>
            </Accordion>
            <Accordion title="Mount Type">
              <FormCheckList>
                {mountType.map((item, i) => {
                  return (
                    item.mountType === null ? "":<FormCheck key={i}>
                      <input type="checkbox" checked={checkmountType[i]}
                        onChange={() => onchangeLightSize(item.mountType, "mountType",i)} />
                      <span>{item.mountType}</span>
                    </FormCheck>);
                })}
              </FormCheckList>
            </Accordion>
            <Accordion title="Emission Pattern">
              <FormCheckList>
                {emissionPattern.map((item, i) => {
                  return ( item.emissionPattern === null ? "":<FormCheck key={i}>
                    <input type="checkbox" checked={emissionCheck[i]}   
                      onChange={() => onchangeLightSize(item.emissionPattern, "emissionPattern",i)} />
                    <span>{item.emissionPattern}</span>
                  </FormCheck>
                  );
                })}
              </FormCheckList>
            </Accordion>
            <Accordion title="Lumens">
              <FormCheckList>
                {lumens.map((item, i) => {
                  return (
                    item.lumens === null ? "":<FormCheck key={i}>
                      <input type="checkbox" checked={lumenCheck[i]}
                        onChange={() => onchangeLightSize(item.lumens, "lumens",i)} />
                      <span>{item.lumens}</span>
                    </FormCheck> );})}
              </FormCheckList>
            </Accordion>
            <Accordion title="Voltage">
              <FormCheckList>
                {voltage.map((item, i) => {
                  return (
                    item.voltage === null  ? "":<FormCheck key={i}>
                      <input type="checkbox" checked={checkVoltage[i]}
                        onChange={() => onchangeLightSize(item.voltage, "voltage",i)} />
                      <span>{item.voltage}</span>
                    </FormCheck> );})}
              </FormCheckList>
            </Accordion>
            <Accordion title="Price">
              <FormCheckList>
                {priceFilter.map((item, i) => {
                  return (
                    item.price === null  ? "":<FormCheck key={i}>
                      <input type="checkbox" checked={checkprice[i]}
                        onChange={() => onchangeLightSize(item.price, "price",i)} />
                      <span>{item.price}</span>
                    </FormCheck> );})}
              </FormCheckList>
            </Accordion>
          </FilterWrapper>
        </CardBody>
      </Card>
    </Fragment>
  );
};

export default FilterAccordion;
