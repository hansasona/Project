import styled from "styled-components";
import {
  fontWeight,
  colors,
  fontSize,
  borderRadius,
  device,
  spacing,
} from "../../shared/styles/global/variables";
import { FormCheck, FormGroup } from "../../shared/styles/components/Form";
import { VisibleMedium } from "../../shared/styles/components/Media.styled";
import Button from "../../shared/styles/components/Button";

export const ProductListTitle = styled.div`
	padding: ${spacing.size3} 0;
	margin: 0 -${spacing.size1};
	text-align: center;
	h3 {
		font-weight: ${fontWeight.fontWeightLight};
		font-size: ${fontSize.h3};
		margin-bottom: ${spacing.xs};
	}
	p {
		color: ${colors.muted};
		margin: 0;
	}
`;

export const StyledHeaderWrapper = styled.div`
	display: flex;
	flex-grow: 1;
	align-items: center;

	> div {
		flex-grow: 1;
		p {
			color: ${colors.muted};
			margin-bottom: ${spacing.sm};
			strong {
				color: ${colors.blackberry};
			}
		}
	}
	h6 { 
		flex-grow: 1;
		margin: 0;
	}
	aside {
		min-width: 250px;
		${FormGroup} {
			display: flex;
			justify-content: end;
			select {
				max-width: 160px;
			}
		}
	}
`;

export const CloseIcon = styled.div`
	float: right;
`;

export const ProductListingWrapper = styled.div`
	display: flex;
	margin-left: -${spacing.size1};
	margin-right: -${spacing.size1};
	@media ${device.md} {
		flex-direction: column;
	}
`;

export const FilterSidebar = styled.div`
	width: 360px;
	flex-shrink: 0;
	padding: 0 ${spacing.size1};
	@media ${device.lg} {
		flex-grow: 1;
		width: auto;
	}
`;

export const ProductListContent = styled.div`
	flex-grow: 1;
	padding: 0 ${spacing.size1};
`;

// Product Listing Styling

export const ProductList = styled.ul``;

export const ProductImage = styled.div`
	width: 220px;
	flex-shrink: 0;
	background: ${colors.fog};
	border: solid 1px ${colors.metal};
	height: 220px;
	margin-right: ${spacing.size3};
	justify-content: center;
	align-items: center;
	color: ${colors.metal};
	border-radius: ${borderRadius.xs};
	display: flex;
	@media ${device.lg} {
		width: 160px;
		height: 160px;
	}
`;
export const ProductListItem = styled.li`
	margin-bottom: ${spacing.size3};
	padding-bottom: ${spacing.size3};
	border-bottom: solid 1px ${colors.metal};
	display: flex;
	background: ${colors.cotton};
	@media ${device.md} {
		flex-direction: column;
	}
	&:last-child {
		border-bottom: none;
		padding: 0;
		margin: 0;
	}
	@media ${device.lg} {
		${ProductImage} {
			display: none;
		}
	}
`;

export const ProductItemBody = styled.div`
	// padding: ${spacing.size3} ${spacing.size4};
	flex-grow: 1;
	h5 {
		margin-bottom: ${spacing.size2};
	}
`;

export const ProFooterTeaser = styled.div`
	display: flex;
	align-items: center;
	${Button} {
		margin-right: ${spacing.size1};
	}
`;

export const ProductCategoryListItem = styled.li``;

export const ProductCategoryList = styled.ul`
	border: solid 1px ${colors.metal};
	border-radius: ${borderRadius.xs};
	&& > ${ProductCategoryListItem} {
		border-bottom: solid 1px ${colors.metal};
		font-size: ${fontSize.sm};
		font-weight: ${fontWeight.normal};
		display: flex;
		overflow: none;
		label,
		span {
			padding: 10px;
			display: block;
		}
		label {
			flex-grow: auto;
			width: 160px;
			flex-shrink: 0;
			border-right: solid 1px ${colors.metal};
			background: ${colors.gray25};
			font-weight: ${fontWeight.fontWeightMedium};
			@media ${device.lg} {
				width: 120px;
			}
		}
		span {
			color: ${colors.muted};
		}
	}
	${ProductImage} {
		width: 100%;
		display: flex;
		padding: ${spacing.size1};
	}

	${ProductCategoryListItem} {
		${(props) =>
    props.proImage &&
			`
        display: none;
        @media ${device.lg} {
          display:flex;
          padding:${spacing.size1};
        }
    `}
	}

	&& > ${ProductCategoryListItem}:first-child {
		display: none;
		@media ${device.lg} {
			display: flex;
			padding: ${spacing.size1};
		}
	}

	&& > ${ProductCategoryListItem}:last-child {
		border-bottom: none;
	}
`;

export const FilterComponent = styled.div`
	display: flex;
	flex-wrap:wrap;
	align-items: center;
	overflow:auto;
	max-height:80px;
	@media ${device.md} {
		max-height:60px;	
	}
	h6 {
		margin: ${spacing.xs} ${spacing.size1} ${spacing.xs} 0;
		flex-grow:0;
	}
`;

export const FilterWrapper = styled.div``;

export const AccordionContent = styled.div`
	padding: 0 0 ${spacing.size1} 0;
	li {
		margin-bottom: ${spacing.xs};
		font-size: ${fontSize.sm};
		${FormCheck} {
			margin-bottom: 0;
		}
	}
`;

export const AccordionItem = styled.div`
	overflow: hidden;
	transition: max-height 0.3s cubic-bezier(1, 0, 1, 0);
	height: auto;
	max-height: 9999px;
	border-bottom: solid 1px ${colors.cloud};
	&&:last-child {
		border-bottom: none;
		${AccordionContent} {
			padding: ${spacing.size1} ${spacing.size1} 0 ${spacing.size1};
		}
	}
`;

export const AccordionHeader = styled.div`
	font-weight: ${fontWeight.fontWeightMedium};
	cursor: pointer;
	padding: ${spacing.size1} 0;
	display: flex;
	justify-content: space-between;
	align-items: center;

	&::after {
		content: "";
		width: 0;
		height: 0;
		border-left: 5px solid transparent;
		border-right: 5px solid transparent;
		border-top: 5px solid ${colors.blackberry};
	}

	&:hover,
	&.open {
		color: ${colors.haze};
	}

	${(props) =>
    props.isOpen &&
		`
    color:${colors.haze};
    &::after {
      content: "";
      border-bottom-color:${colors.haze};
      border-top: 0;
      border-bottom: 5px solid;
    }
    
  `}
`;

export const AccordionBody = styled.div`
	${(props) =>
    !props.isOpen &&
		`
      max-height: 0;
      transition: max-height 0.35s cubic-bezier(0, 1, 0, 1);
      color:${colors.haze};
  `}
`;

export const FilterModal = styled.div`
	@media ${device.md} {
		display: none;
		${(props) =>
    props.isOpenFilter &&
			`
        display:block;
        padding: ${spacing.size3};
        position: fixed;
        background: ${colors.cotton};
        left: 0;
        right: 0;
        top: 0;
        overflow: auto;
        bottom: 0;
        z-index: 101;
    `}

		${FormGroup} {
			margin-bottom: ${spacing.size2};
			label {
				margin: 0 ${spacing.size1} 0 0;
			}
		}

		footer {
			text-align: center;
			padding: ${spacing.size2};
		}
	}
`;

export const SearchBoxContent = styled.div`
	display: flex;
	align-items: end;
	margin-bottom: ${spacing.size2};
	${VisibleMedium} {
		margin-right: ${spacing.size1};
	}
	${FormGroup} {
		flex-grow: 1;
	}
`;

export const FilterModalTitle = styled.div`
	display: flex;
	align-items: center;
	margin-bottom: ${spacing.size2};
	h3 {
		margin: 0;
		flex-grow: 1;
	}
`;
