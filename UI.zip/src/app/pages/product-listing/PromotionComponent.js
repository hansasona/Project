import React, { Fragment } from "react";
import styled from "styled-components";
import Card, { CardBody } from "../../shared/styles/components/Card";
import { ProductImage, StyledHeaderWrapper } from "./ProductListing.Styles";

import * as Icon from "react-bootstrap-icons";
import { device, spacing } from "../../shared/styles/global/variables";
import { Link } from "react-router-dom";

const PromotionCard = styled(Card)`
  margin-bottom: ${spacing.size3};

  ${StyledHeaderWrapper} {
    margin-bottom: ${spacing.size2};
    h4 {
      margin: 0;
      flex-grow: 1;
    }
  }
`;

const PromoList = styled.ul`
  display: flex;
  // flex-wrap: wrap;
  li {
    width: 100%;
    min-width: auto;
    flex-grow: 1;
    margin-right: ${spacing.size2};
    &:last-child {
      margin-right: 0;
    }
    @media ${device.lg} {
      margin-right: ${spacing.size1};
    }
    ${ProductImage} {
      width: 100%;
      height: 180px;
      @media ${device.lg} {
        height: auto;
        padding: ${spacing.size3} 0;
        svg {
          width: 50%;
          height: auto;
        }
      }
      @media ${device.sm} {
        padding: ${spacing.size2} 0;
      }
    }
  }
`;

const PromotionComponent = () => {
  return (
    <Fragment>
      <PromotionCard>
        <CardBody>
          <StyledHeaderWrapper>
            <h4>Promotional Offers</h4>
            <Link>
              <Icon.XLg />
            </Link>
          </StyledHeaderWrapper>
          <PromoList>
            <li>
              <ProductImage>
                <Icon.ImageAlt size={72} />
              </ProductImage>
            </li>
            <li>
              <ProductImage>
                <Icon.ImageAlt size={72} />
              </ProductImage>
            </li>
            <li>
              <ProductImage>
                <Icon.ImageAlt size={72} />
              </ProductImage>
            </li>
            <li>
              <ProductImage>
                <Icon.ImageAlt size={72} />
              </ProductImage>
            </li>
          </PromoList>
        </CardBody>
      </PromotionCard>
    </Fragment>
  );
};

export default PromotionComponent;
