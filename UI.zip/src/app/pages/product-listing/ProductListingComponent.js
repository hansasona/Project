import React, { useEffect, useState } from "react";
import Card, {
  CardBody,
  CardHeader,
} from "../../shared/styles/components/Card";
import * as Icon from "react-bootstrap-icons";

import {
  FilterComponent,
  FilterModal,
  FilterModalTitle,
  FilterSidebar,
  ProductCategoryList,
  ProductCategoryListItem,
  ProductImage,
  ProductItemBody,
  ProductListContent,
  ProductListingWrapper,
  ProductListItem,
  ProductListTitle,
  ProFooterTeaser,
  SearchBoxContent,
  StyledHeaderWrapper,
} from "./ProductListing.Styles";

import Button from "../../shared/styles/components/Button";
import TitleComponent from "../../shared/components/TitleComponent";
import { Fragment } from "react";
import { Link } from "react-router-dom";
import {
  FormControl,
  FormGroup,
  FormLabel,
  FormSelect,
  InputGroup,
  FormCheck,
} from "../../shared/styles/components/Form";
import Container from "../../shared/styles/components/Container";
import FilterAccordion from "./FilterAccordion";
import PromotionComponent from "./PromotionComponent";
import CompareSelectionComponent from "./CompareSelectionComponent";
import {
  HiddenMedium,
  HiddenSmall,
  VisibleMedium,
} from "../../shared/styles/components/Media.styled";
import LabelList from "../../shared/styles/components/LabelList";
import Modal from "../../shared/styles/components/modal/Modal";
import LumenOutputComponent from "./LumenOutputComponent";
import { useDispatch, useSelector } from "react-redux";
import { productsData } from "../../redux/user";
import { LoaderComponent } from "../../shared/styles/components/Spinner";
import { NoResult } from "../../shared/styles/components/ListGroup";

const ProductListingComponent = () => {
  const dispatch = useDispatch();
  const { getProductList, showLoader } = useSelector((state) => state.user);
  const [isOpenFilter, setOpenFilter] = React.useState(false);
  const [active, setActive] = useState(false);
  const [isCompareOn, setCompareOn] = React.useState(false);
  const [filterProduct, setFilterProduct] = useState([]);
  const [filterCriteria, setfilterCriteria] = useState([]);
  const [currentremoveitem, setcurrentremoveitem] = useState([]);

  const viewLumenOutputModal = () => {
    setActive(true);
  };
  useEffect(() => {
    dispatch(productsData());
  }, []);
  useEffect(() => {
    console.log("getproductlist",getProductList?.records);
  }, [getProductList]);
  const handleFilterRemove = (filterItem, i) => {
    setcurrentremoveitem(filterItem);
    setfilterCriteria(prev => {
      return prev.filter((item, index) => {
        return index !== i;
      });
    });
  };
  const filterCheck = (condition) => {
    console.log(condition);
    if(condition.length > 0){
      condition.map((item)=>{
        console.log(item); 
        dispatch(productsData(item));
      }); 
    }else{
      dispatch(productsData());
    }
   
  };
  const filterRemove = (condiction) => {
    let finalcondition = filterCriteria;
    finalcondition = finalcondition.filter((item) => item.filter !== condiction);
    console.log("finalcondition",finalcondition);
    filterCheck(finalcondition);
  };
  const handleFilter = (filter, type) => {
    let condition = [];
    const conditionItem = {
      filter: filter,
      type: type,
    };
    // console.log(conditionItem);
    setfilterCriteria(prev => {
      let indexOfitem = prev.map(i => i.filter).indexOf(filter);
      if (indexOfitem !== -1) {
        let finalprev = prev;
        finalprev.splice(indexOfitem, 1);
        condition = finalprev;
        filterCheck(condition);
        console.log("finalprev",finalprev);
        return finalprev;
      } else {
        
        filterCheck([...prev,conditionItem]);
        console.log("finalArr",[...prev,conditionItem]);

        return [...prev,conditionItem];
      }
    });
  };

  useEffect(()=>{
    console.log(filterCriteria);
  },[filterCriteria]);
  return (

    <Fragment>
      <TitleComponent title="Product Listing" />
      <Container fluid pageContent>
        <ProductListTitle>
          <h3>Please choose a light to customize</h3>
          <HiddenSmall as="p">
            Not sure how much light you need?{" "}
            <Button xs onClick={() => viewLumenOutputModal()}>
              Compare lumen output
            </Button>
          </HiddenSmall>
        </ProductListTitle>
        <ProductListingWrapper>
          <FilterSidebar>
            <SearchBoxContent>
              <VisibleMedium>
                <Button icon onClick={() => setOpenFilter(!isOpenFilter)}>
                  <Icon.Funnel size={16} />
                </Button>
              </VisibleMedium>
              <FormGroup>
                <FormLabel small>Search by Name or Model Number</FormLabel>
                <InputGroup>
                  <FormControl />
                  <Button icon>
                    <Icon.Search size={16} />
                  </Button>
                </InputGroup>
              </FormGroup>
            </SearchBoxContent>
            <FilterModal isOpenFilter={isOpenFilter}>
              <VisibleMedium>
                <FilterModalTitle>
                  <h3>Sort & Filter</h3>
                  <Link onClick={() => setOpenFilter(!isOpenFilter)}>
                    <Icon.XLg size={21} />
                  </Link>
                </FilterModalTitle>
                <FormGroup inline>
                  <FormLabel>Sort by:</FormLabel>
                  <FormSelect>
                    <option>Featured</option>
                    <option>Alphabetical</option>
                    <option>Price Low to High</option>
                    <option>Price High to Low</option>
                  </FormSelect>
                </FormGroup>
              </VisibleMedium>
              <FilterAccordion handleFilter={handleFilter} currentremoveitem={currentremoveitem}
                filterRemove={filterRemove} />
              <VisibleMedium as="footer">
                <Button>Apply & Show Results</Button>
              </VisibleMedium>
            </FilterModal>
          </FilterSidebar>
          <ProductListContent>
            <PromotionComponent />
            <Card dimmer flex>
              <CardHeader>
                <StyledHeaderWrapper>
                  <div>
                    <p>
                      Displaying <strong>{getProductList?.records?.length}</strong> products
                    </p>
                    <FilterComponent>
                      <h6>Filters Applied :</h6>
                      <LabelList dismissible>
                        {filterCriteria?.length > 0 && filterCriteria.map((flterItem, i) => {
                          return (
                            <li key={i}>
                              <Link>
                                {flterItem.type}:{flterItem.filter} 
                                <span onClick={() => handleFilterRemove(flterItem, i)}>
                                  <Icon.XLg />                                                                   
                                </span>
                              </Link>
                            </li>
                          );
                        })} 
                      </LabelList>
                    </FilterComponent>
                  </div>
                  <HiddenMedium as="aside">
                    <FormGroup inline>
                      <FormLabel>Sort by:</FormLabel>
                      <FormSelect>
                        <option>Featured</option>
                        <option>Alphabetical</option>
                        <option>Price Low to High</option>
                        <option>Price High to Low</option>
                      </FormSelect>
                    </FormGroup>
                  </HiddenMedium>
                </StyledHeaderWrapper>
              </CardHeader>
              {!showLoader ?
                <CardBody>
                  { getProductList?.records?.map((item,i) => {
                    return (
                      <ProductListItem key={i}>
                        <ProductImage>
                          <Icon.ImageAlt size={72} />
                        </ProductImage>
                        <ProductItemBody> <h5 >{item.description}</h5>
                          <ProductCategoryList>
                            <ProductCategoryListItem proImage>
                              <ProductImage>
                                <Icon.ImageAlt size={72} />
                              </ProductImage>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Lighting Size:</label>
                              <span>{item.lightSize}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Model Number:</label>
                              <span>{item.modelNumber}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Lumens:</label>
                              <span>{item.lumens}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Amp Draw:</label>
                              <span>{item.ampDraw}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Voltage:</label>
                              <span>{item.voltage}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Emission Pattern:</label>
                              <span>{item.emissionPattern}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Color:</label>
                              <span>{item.color}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Mounting Options:</label>
                              <span>{item.mountType}</span>
                            </ProductCategoryListItem>
                            <ProductCategoryListItem>
                              <label>Price:</label>
                              <span>Starting at ${item.price}</span>
                            </ProductCategoryListItem>
                          </ProductCategoryList>
                          <ProFooterTeaser>
                            <Button sm primary>
                                Customize
                            </Button>
                            <FormCheck>
                              <input
                                type="checkbox"
                                onChange={() => setCompareOn(!isCompareOn)}
                              />
                              <span>Compare</span>
                            </FormCheck>
                          </ProFooterTeaser>
                        </ProductItemBody>
                      </ProductListItem>
                    );
                  })
                  }
                </CardBody> : <LoaderComponent />}
              {!getProductList?.records.length ? (
                <NoResult>Product not Available</NoResult>
              ) : ""}
            </Card>
          </ProductListContent>
        </ProductListingWrapper>
        <CompareSelectionComponent isCompareOn={isCompareOn} />
        <Modal
          active={active}
          hideModal={() => setActive(false)}
          title="Understanding Lumen Output"
          size="xl"
        >
          <LumenOutputComponent />
        </Modal>
      </Container>
    </Fragment>
  );
};

export default ProductListingComponent;
