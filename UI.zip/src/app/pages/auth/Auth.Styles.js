/**
 * @ External Dependencies
 */
import styled from "styled-components";
/**
 * @ Internal Dependencies
 */
import {
  colors,
  device,
  fontSize,
  fontWeight,
  spacing,
} from "../../shared/styles/global/variables";
import Card, { CardBody } from "../../shared/styles/components/Card";
import { StyledExternalLink } from "../../shared/styles/global/typography";
import { FormGroup } from "../../shared/styles/components/Form";
import Button from "../../shared/styles/components/Button";

export const AuthCard = styled(Card)`
  margin: 0 auto;
  max-width: 600px;
  ${(props) =>
    props.autoWidth &&
    `
    max-width: 90%;
    @media ${device.sm} {
      max-width: 100%;
    }
    ${AuthBody} {
      @media ${device.md} {
        padding: 50px 30px;
      }
    }
   
   
  `}
  @media ${device.sm} {
    margin: 0 ${spacing.size2};
  }
`;

export const AuthBody = styled(CardBody)`
  padding: 50px 100px 30px;

  @media ${device.sm} {
    padding: 50px 30px;
  }
`;

export const StyledHeaderWrapper = styled.div`
  margin: ${spacing.size2} auto ${spacing.size6};
  text-align: center;
  a {
    display: inline-block;
    margin-bottom: ${spacing.size4};
  }
  h5 {
    font-size: ${fontSize.normal};
    font-weight: ${fontWeight.fontWeightLight};
    margin-bottom: ${spacing.xs};
    color: ${colors.haze};
  }
`;

export const StyledTitle = styled.h2`
  font-weight: ${fontWeight.fontWeightMedium};
`;

export const Brand = styled.img`
  width: 8rem;
  @media ${device.sm} {
    width: 6rem;
  }
`;

export const FormFieldWrapper = styled.div`
  margin-bottom: ${spacing.size5};
  ${(props) =>
    props.flex &&
    `
      display:flex;
      flex-wrap:wrap;
      margin:0 -${spacing.size1} ${spacing.size5};
      @media ${device.sm} {
       flex-direction:column;
      }
      && ${FormGroup} {
        flex: 0 0 auto;
        width: 50%;
        padding:0 ${spacing.size1};
        @media ${device.sm} {
          width: 100%;
         }
      }
      
    `}
`;

export const StyledFooterWrapper = styled.div`
  text-align: center;
`;

export const FormButtonWrapper = styled.div`
  text-align: center;

  ${Button} {
    width: 220px;
  }
`;

export const StyledLinkWrapper = styled.div`
  padding-top: ${spacing.size2};
  text-align: center;

  small {
    margin-bottom: ${spacing.size4};
    display: block;
  }

  ${StyledExternalLink} {
    display: inline-block;
    margin-bottom: ${spacing.size4};
  }
`;

export const footerLogo = styled.img`
  width: 9rem;
  @media ${device.lg} {
    width: 7rem;
  }
`;
