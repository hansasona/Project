import React, { Fragment,useState } from "react";
import * as Yup from "yup";
import { changePassword ,fetchRefreshedToken} from "../../redux/user";
import { getRefreshToken } from "../../shared/utils/localStore";
import { useDispatch } from "react-redux";
import { LinkAddons, Validation,InputGroup } from "../../shared/styles/components/Form";
import {
  FormGroup,
  FormLabel,
  FormControl,
} from "../../shared/styles/components/Form";
import * as icons from "react-bootstrap-icons";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";

const ChangePasswordComponent = ({onCloseChangePasswordModal}) => {
  const passwordRegexp =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.[\]{}()?\-“!@#%&/,><’:;|_~`])\S{8,256}$/;
  const dispatch = useDispatch();
  const changePasswordYupSchema = Yup.object({
    currentPassword: Yup.string()
      .required("Current Password is required")
      .min(8, "Minimum 8 characters required")
      .matches(
        passwordRegexp,
        "Password requires uppercase, lowercase, symbols and numbers"
      ),
    newPassword: Yup.string()
      .required("New Password is required")
      .min(8, "Minimum 8 characters required")
      .matches(
        passwordRegexp,
        "Password requires uppercase, lowercase, symbols and numbers"
      ),
    confirmPassword: Yup.string()
      .required("Confirm New Password is required")
      .min(8, "Minimum 8 characters required")
      .matches(
        passwordRegexp,
        "Password requires uppercase, lowercase, symbols and numbers"
      )
      .oneOf([Yup.ref("newPassword")], "Passwords must match"),
  }).required();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(changePasswordYupSchema),
  });

  const submitHandler = async (body) => {
    const response = await dispatch(changePassword(body));
    if (!response.error && response.payload?.message) {
      onCloseChangePasswordModal();
      const refreshKey = getRefreshToken();
      dispatch(fetchRefreshedToken(refreshKey));
    }
  };
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  return (
    <Fragment>
      <form id="changePasswordForm" onSubmit={handleSubmit(submitHandler)}>
        <FormGroup>
          <FormLabel>Current Password</FormLabel>
          <InputGroup btnAddons>
            <FormControl
              fluid
              type={showCurrentPassword ? "text" : "password"}
              isValid={errors.currentPassword?.type ? false : true}
              { ...register("currentPassword") }
            />
            <LinkAddons
              onClick={() => setShowCurrentPassword(prev => !prev)}
            >
              {showCurrentPassword ? <icons.Eye /> : <icons.EyeSlash />}
            </LinkAddons>
          </InputGroup>
          <Validation
            isInvalid={errors.currentPassword?.message && true}
            isValid={!errors.currentPassword?.message && true}
          >
            {errors.currentPassword?.message}
          </Validation>
        </FormGroup>
        <FormGroup>
          <FormLabel>New Password</FormLabel>
          <InputGroup btnAddons>
            <FormControl
              fluid
              type={showNewPassword ? "text" : "password"}
              isValid={errors.newPassword?.type ? false : true}
              { ...register("newPassword") }
            />
            <LinkAddons
              onClick={() => setShowNewPassword(prev => !prev)}
            >
              {showNewPassword ? <icons.Eye /> : <icons.EyeSlash />}
            </LinkAddons>
          </InputGroup>
          <Validation
            isInvalid={errors.newPassword?.message && true}
            isValid={!errors.newPassword?.message && true}
          >
            {errors.newPassword?.message}
          </Validation>
        </FormGroup>
        <FormGroup>
          <FormLabel>Confirm New Password</FormLabel>
          <InputGroup btnAddons>
            <FormControl
              fluid
              type={showConfirmPassword ? "text" : "password"}
              isValid={errors.confirmPassword?.type ? false : true}
              { ...register("confirmPassword") }
            />
            <LinkAddons
              onClick={() => setShowConfirmPassword(prev => !prev)}
            >
              {showConfirmPassword ? <icons.Eye /> : <icons.EyeSlash />}
            </LinkAddons>
          </InputGroup>
          <Validation
            isInvalid={errors.confirmPassword?.message && true}
            isValid={!errors.confirmPassword?.message && true}
          >
            {errors.confirmPassword?.message}
          </Validation>
        </FormGroup>
      </form>
    </Fragment>
  );
};

export default ChangePasswordComponent;
