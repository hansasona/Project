/* eslint-disable max-len */
import React, { Fragment, useEffect, useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import {
  AuthBody,
  AuthCard,
  Brand,
  StyledTitle,
  StyledHeaderWrapper,
  StyledFooterWrapper,
  FormButtonWrapper,
  StyledLinkWrapper,
  FormFieldWrapper,
} from "./Auth.Styles";

import {
  StyledExternalLink,
  StyledLink,
  StyledSecondaryText,
} from "../../shared/styles/global/typography";
import logo from "../../../assets/images/logo.svg";
import footerLogo from "../../../assets/images/whelen-logo.png";
import Button from "../../shared/styles/components/Button";
import {
  FormGroup,
  FormLabel,
  FormControl,
  Validation,
  InputGroup, 
  LinkAddons
} from "../../shared/styles/components/Form";
import { useDispatch, useSelector } from "react-redux";
import Modal from "../../shared/styles/components/modal/Modal";
import TitleComponent from "../../shared/components/TitleComponent";
import { signIn, forgotPassword, troubleLogin } from "../../redux/user";
import * as icons from "react-bootstrap-icons";
import { useNavigate, createSearchParams } from "react-router-dom";
import { isUserLoggedin } from "../../shared/utils/localStore";

const LoginComponent = () => {
  const [showPassword, setShowPassword] = useState(false);
  const { firstTimeLogin, 
    token, uid, isLoading, isLoggedIn, forgotPasswordLoading, showTroubleLogin } = useSelector(state => state.user);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginSchema = yup.object().shape({
    username: yup
      .string()
      .email("Please enter valid Email Address (Format abc@xyz.com)")
      .required("Email Address is required")
      .min(5, "Please enter valid Email Address (Format abc@xyz.com)")
      .max(
        128,
        "Please enter valid Email Address (Max 128 character allowed in format abc@xyz.com"
      ),
    password: yup
      .string()
      .trim()
      .required("Password is required")
      .min("8", "Password must be minimum 8 characters")
      .max(256, "Please enter valid Password (Max 256 character allowed"),
  });


  const schema = yup.object().shape({
    email: yup.string()
      .email("Please enter valid Email Address (Format abc@xyz.com)")
      .required("Email Address is required")
      .min(5, "Please enter valid Email Address (Format abc@xyz.com)")
      .max(100, "Please enter valid Email Address (Max 128 character allowed in format abc@xyz.com"),
  }).required();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset: resetInput
  } = useForm({
    resolver: yupResolver(schema),
  });
  const { register: loginForm, handleSubmit: handleLoginSubmit, formState:{errors: errorsLogin} } = useForm({
    resolver: yupResolver(loginSchema),
  });

  const onSubmit = async (request) => {
    dispatch(forgotPassword(request));
  };

  const loginSubmit = (request) => {
    dispatch(signIn(request));
  };

  const viewModalTroubleLogin = () => {
    resetInput({"email": ""});
    dispatch(troubleLogin(true));
  };

  const modalClose = () => {
    dispatch(troubleLogin(false));
  };

  const handleEscKey = useCallback(
    (event) => {
      if (event.key === "Escape") {
        modalClose(false);
      }
    },
    [modalClose]
  );


  useEffect(() => {
    document.addEventListener("keyup", handleEscKey, false);
    return () => {
      document.removeEventListener("keyup", handleEscKey, false);
    };
  }, [handleEscKey]);

  useEffect(() => { 
    if (isUserLoggedin()) {
      navigate("/home");  
    }
    if (firstTimeLogin) {
      navigate({pathname: "/reset-password", search: createSearchParams({ uid: window.btoa(uid), token: window.btoa(token)}).toString() });
    }
    if (isLoggedIn) {
      setTimeout(() => navigate("/home"), 1000);
    }
  }, [firstTimeLogin, uid, token, isLoggedIn, forgotPasswordLoading, isUserLoggedin]);

  return (
    <Fragment>
      <TitleComponent title="Login" />
      <AuthCard>
        <AuthBody>
          <StyledHeaderWrapper>
            <a href="http://www.whelen.com" target="_blank" rel="noreferrer">
              <Brand src={logo} alt="Illumination Designer" />
            </a>
            <h5>Welcome to the</h5>
            <StyledTitle>Whelen Cloud Suite</StyledTitle>
          </StyledHeaderWrapper>
          <form onSubmit={handleLoginSubmit(loginSubmit)}>
            <FormFieldWrapper>
              <FormGroup>
                <FormLabel>Email Address</FormLabel>
                <FormControl 
                  fluid
                  { ...loginForm("username") } 
                  type="text"/>
                <Validation
                  isInvalid={errorsLogin.username?.type && true}
                  isValid={!errorsLogin.username?.type && true}
                >
                  {errorsLogin.username?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>Password</FormLabel>
                <InputGroup btnAddons>
                  <FormControl
                    fluid
                    type={showPassword ? "text" : "password"}
                    { ...loginForm("password") }
                    isValid={errorsLogin.password?.type ? false : true}
                  />
                  <LinkAddons
                    onClick={() => setShowPassword(prevState => !prevState)}
                  >
                    {showPassword ? <icons.Eye /> : <icons.EyeSlash />}
                  </LinkAddons>
                </InputGroup>
                <Validation
                  isInvalid={errorsLogin.password?.type && true}
                  isValid={!errorsLogin.password?.type && true}
                >
                  {errorsLogin.password?.message}
                </Validation>
              </FormGroup>
            </FormFieldWrapper>
            <FormButtonWrapper>
              <Button lg isLoading={isLoading}>Log in</Button>
              <StyledLinkWrapper>
                <small onClick={() => viewModalTroubleLogin()}>
                  <StyledLink>Trouble logging in?</StyledLink>
                </small>
                <StyledExternalLink href="/register">
									Create an Account
                </StyledExternalLink>
              </StyledLinkWrapper>
            </FormButtonWrapper>
          </form>
          <StyledFooterWrapper>
            <img src={footerLogo} alt="Whelen Cloud Platform®" />
          </StyledFooterWrapper>
        </AuthBody>
      </AuthCard>
      <form action="" method="post" onSubmit={handleSubmit(onSubmit)}>
        <Modal
          active={showTroubleLogin}
          hideModal={modalClose}
          title="Trouble Logging In?"
          footer={<Button type="submit" isLoading={forgotPasswordLoading}>Submit</Button>}
          size="sm"
        >
          <StyledSecondaryText>
						To reset your password enter your email address and a email will be
						sent with instructions.
          </StyledSecondaryText>
          <FormGroup lastChild>
            <FormLabel>Email Address</FormLabel>
            <FormControl
              type="text"
              {...register("email")}
              name="email"
              autoComplete="off"
              spellCheck="false"
              maxLength={100}
            />
            <Validation
              isInvalid={errors.email?.type && true}
              isValid={!errors.email?.type && true}
            >
              {errors.email?.message}
            </Validation>
          </FormGroup>
        </Modal>
      </form>
    </Fragment>
  );
};

export default LoginComponent;
