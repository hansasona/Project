import React, { Fragment, useEffect, useState } from "react";
import {
  AuthBody,
  AuthCard,
  Brand,
  StyledTitle,
  StyledHeaderWrapper,
  StyledFooterWrapper,
  FormButtonWrapper,
  StyledLinkWrapper,
  FormFieldWrapper,
} from "./Auth.Styles";
import { StyledLink } from "../../shared/styles/global/typography";
import logo from "../../../assets/images/logo.svg";
import footerLogo from "../../../assets/images/whelen-logo.png";
import {
  FormGroup,
  FormLabel,
  FormControl,
  InputGroup,
  Validation,
  LinkAddons
} from "../../shared/styles/components/Form";
import TitleComponent from "../../shared/components/TitleComponent";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import * as icons from "react-bootstrap-icons";
import { useDispatch, useSelector } from "react-redux";
import { resetPassword } from "../../redux/user";
import Button from "../../shared/styles/components/Button";

const ResetPasswordComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading, isLoggedIn } = useSelector(state => state.user);
  const [searchParams] = useSearchParams();
  const token = window.atob(searchParams.get("token"));
  const userId = window.atob(searchParams.get("uid"));
  const passwordRegexp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\^$*.[\]{}()?\-“!@#%&/,><’:;|_~`])\S{8,256}$/;
  const setpasswordSchema = yup
    .object({
      newPassword: yup
        .string()
        .required("New Password is required")
        .min(8, "Minimum 8 characters required")
        .matches(passwordRegexp, "Password requires uppercase, lowercase, symbols and numbers"),
      confirmPassword: yup
        .string()
        .required("Confirm New Password is required")
        .min(8, "Minimum 8 characters required")
        .matches(passwordRegexp, "Password requires uppercase, lowercase, symbols and numbers")
        .oneOf([yup.ref("newPassword")], "Passwords must match"),
    })
    .required();

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(setpasswordSchema),
  });

  const submitHandler = async (body) => {
    const { newPassword:password } = body; 
    dispatch(resetPassword({userId, token, password }));
  };

  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  useEffect(() => {
    if(isLoggedIn) {
      navigate("/home");
    }
    if(!searchParams.get("token") && !searchParams.get("userId")) {
      navigate("/login");
    }
  }, [isLoggedIn]);

  return (
    <Fragment>
      <TitleComponent title="Reset Password" />
      <AuthCard>
        <AuthBody>
          <StyledHeaderWrapper>
            <a href="http://www.whelen.com" target="_blank" rel="noreferrer">
              <Brand src={logo} alt="Illumination Designer" />
            </a>
            <StyledTitle>Reset Password</StyledTitle>
          </StyledHeaderWrapper>
          <form onSubmit={handleSubmit(submitHandler)}>
            <FormFieldWrapper>
              <FormGroup>
                <FormLabel>NEW PASSWORD</FormLabel>
                <InputGroup btnAddons>
                  <FormControl
                    fluid
                    type={showNewPassword ? "text" : "password"}
                    isValid={errors.newPassword?.type ? false : true}
                    { ...register("newPassword") }
                  />
                  <LinkAddons
                    onClick={() => setShowNewPassword(prev => !prev)}
                  >
                    {showNewPassword ? <icons.Eye /> : <icons.EyeSlash />}
                  </LinkAddons>
                </InputGroup>
                <Validation
                  isInvalid={errors.newPassword?.type && true}
                  isValid={!errors.newPassword?.type && true}
                >
                  {errors.newPassword?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>CONFIRM NEW PASSWORD</FormLabel>
                <InputGroup btnAddons>
                  <FormControl
                    fluid
                    type={showConfirmPassword ? "text" : "password"}
                    isValid={errors.confirmPassword?.type ? false : true}
                    { ...register("confirmPassword") }
                  />
                  <LinkAddons
                    onClick={() => setShowConfirmPassword(prevState => !prevState)}
                  >
                    {showConfirmPassword ? <icons.Eye /> : <icons.EyeSlash />}
                  </LinkAddons>
                </InputGroup>
                <Validation
                  isInvalid={errors.confirmPassword?.type && true}
                  isValid={!errors.confirmPassword?.type && true}
                >
                  {errors.confirmPassword?.message}
                </Validation>
              </FormGroup>
            </FormFieldWrapper>
            <FormButtonWrapper>
              <Button lg isLoading={isLoading}>Submit</Button>
              <StyledLinkWrapper>
                <small>
                  <StyledLink to="/login">Cancel</StyledLink>
                </small>
              </StyledLinkWrapper>
            </FormButtonWrapper>
          </form>
          <StyledFooterWrapper>
            <img src={footerLogo} alt="Whelen Cloud Platform®" />
          </StyledFooterWrapper>
        </AuthBody>
      </AuthCard>
    </Fragment>
  );
};

export default ResetPasswordComponent;
