import React, { Fragment, useState, useEffect } from "react";
import {
  AuthBody,
  AuthCard,
  StyledTitle,
  Brand,
  StyledHeaderWrapper,
  StyledFooterWrapper,
  FormButtonWrapper,
  StyledLinkWrapper,
  FormFieldWrapper,
} from "./Auth.Styles";

import { StyledExternalLink } from "../../shared/styles/global/typography";

import logo from "../../../assets/images/logo.svg";
import footerLogo from "../../../assets/images/whelen-logo.png";
import {
  FormGroup,
  FormLabel,
  FormControl,
  Validation,
} from "../../shared/styles/components/Form";
import TitleComponent from "../../shared/components/TitleComponent";
import { register as registerAction } from "../../redux/user";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";
import Button from "../../shared/styles/components/Button";
const RegisterComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isSubmitted, setSumbitted] = useState(false);
  const isLoading = useSelector((state) => state.user.isLoading);
  const phoneRegExp =
		/^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
  const schema = yup
    .object({
      name: yup
        .string()
        .required("First Name is required")
        .min(1, "First Name must be minimum 1 characters")
        .max(30)
        .matches(
          /^[ A-Za-z-/s]*$/,
          "Please enter valid characters only (English alphabets, space and hyphen)"
        ),
      lastName: yup
        .string()
        .required("Last Name is required")
        .min(1, "Last Name must be minimum 1 characters")
        .max(30)
        .matches(
          /^[ A-Za-z-/s]*$/,
          "Please enter valid characters only (English alphabets, space and hyphen)"
        ),
      email: yup
        .string()
        .email("Please enter valid email address (Format abc@xyz.com)")
        .max(50)
        .required("Email address is required"),
      phoneNumber: yup
        .string()
        .required("Phone number is required")
        .matches(phoneRegExp, "Please enter valid numbers only (0-9)")
        .min(10, "Phone number must be minimum 10 digits")
        .max(14, "Please enter valid numbers only (0-9)"),
      agency: yup
        .string()
        .required("Agency name is required")
        .min(1, "Agency name must contain 1 characters")
        .max(30)
        .matches(
          /(?=[A-Za-z0-9-_',/. ]+$)^(?=.*[a-zA-Z]).*$/,
          "Please enter valid Agency name (Allowed English character, numbers and ' , _ . - / )"
        ),
      agencyRole: yup.string()
        .required("Agency Role is required")
        .min(2, "Agency Role must be minimum 2 characters")
        .matches(/^[a-zA-Z]*$/, "Please enter valid characters"),
    })
    .required();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const submitForm = (reqBody) => {
    const request = { ...reqBody, role: "user" }; // set role default to user for now
    dispatch(registerAction(request))
      .unwrap()
      .then(() => setSumbitted(true));
  };

  useEffect(() => {
    if (isSubmitted) {
      setTimeout(() => {
        navigate("/login");
      }, 3000);
    }
  }, [isSubmitted, navigate]);

  return (
    <Fragment>
      <TitleComponent title="Register" />
      <AuthCard autoWidth>
        <AuthBody>
          <StyledHeaderWrapper>
            <a href="http://www.whelen.com" target="_blank" rel="noreferrer">
              <Brand src={logo} alt="Illumination Designer" />
            </a>
            <h5>Welcome to the</h5>
            <StyledTitle>Whelen Cloud Suite</StyledTitle>
          </StyledHeaderWrapper>
          <form onSubmit={handleSubmit(submitForm)}>
            <FormFieldWrapper flex>
              <FormGroup>
                <FormLabel>First Name</FormLabel>
                <FormControl {...register("name")} type="text" fluid />
                <Validation isInvalid={errors.name?.type && true}>
                  {errors.name?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>Last Name</FormLabel>
                <FormControl {...register("lastName")} type="text" fluid />
                <Validation isInvalid={errors.lastName?.type && true}>
                  {errors.lastName?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>Email</FormLabel>
                <FormControl {...register("email")} type="text" fluid />
                <Validation isInvalid={errors.email?.type && true}>
                  {errors.email?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>PHONE NUMBER</FormLabel>
                <FormControl {...register("phoneNumber")} type="text" fluid />
                <Validation isInvalid={errors.phoneNumber?.type && true}>
                  {errors.phoneNumber?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>Agency</FormLabel>
                <FormControl {...register("agency")} type="text" fluid />
                <Validation isInvalid={errors.agency?.type && true}>
                  {errors.agency?.message}
                </Validation>
              </FormGroup>
              <FormGroup>
                <FormLabel>Agency Role</FormLabel>
                <FormControl {...register("agencyRole")} type="text" fluid />
                <Validation isInvalid={errors.agencyRole?.type && true}>
                  {errors.agencyRole?.message}
                </Validation>
              </FormGroup>
            </FormFieldWrapper>
            <FormButtonWrapper>
              <Button isLoading={isLoading} lg>
								Sign Up
              </Button>
              <StyledLinkWrapper>
                <StyledExternalLink href="login">
									Back to Login
                </StyledExternalLink>
              </StyledLinkWrapper>
            </FormButtonWrapper>
          </form>
          <StyledFooterWrapper>
            <img src={footerLogo} alt="Whelen Cloud Platform®" />
          </StyledFooterWrapper>
        </AuthBody>
      </AuthCard>
    </Fragment>
  );
};

export default RegisterComponent;
