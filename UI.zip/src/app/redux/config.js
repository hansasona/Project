import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getConfigList, createConfig } from "../api/config";
import { setNotification } from "./notificationSlice";
// import { updateAuthStore } from "../shared/utils/localStore";
// import { useNavigate } from "react-router-dom";

export const getConfigs = createAsyncThunk("configs", async (body, thunkAPI) => {
  try {
    const data = await getConfigList(body.pageSize, body?.pageToken, body?.filterVal);
    return data.response; 
  } catch (error) {
    if (error.data && error.data.MESSAGE) {
      thunkAPI.dispatch(
        setNotification({ type: "error", message: error.data.MESSAGE })
      );
      return thunkAPI.rejectWithValue();
    } else {
      thunkAPI.dispatch(
        setNotification({ type: "error", message: "Something went wrong" })
      );
      return thunkAPI.rejectWithValue();
    }
  }
});

export const createNewConfig = createAsyncThunk("createConfig", async (requestData, thunkAPI) => {
  try {
    const data = await createConfig(requestData);
    thunkAPI.dispatch(setNotification({ type: "success", message: "Configuration Created successfull" }));
    thunkAPI.dispatch(setConfigId(requestData));
    return data.response.data; 
  } catch (error) {
    if (error.data && error.data.MESSAGE) {
      thunkAPI.dispatch(
        setNotification({ type: "error", message: error.data.MESSAGE })
      );
      return thunkAPI.rejectWithValue();
    } else {
      thunkAPI.dispatch(
        setNotification({ type: "error", message: "Something went wrong" })
      );
      return thunkAPI.rejectWithValue();
    }
  }
});

const initialState = {
  configDetails: null,
  configList: [],
  lastEvaluatedKey: null,
  isLoading: false,
  showProductCompare: false,
  compareProducts: []
};

const configSlice = createSlice({
  name: "config",
  initialState,
  reducers: {
    setConfigId: (state, { payload }) => {
      state.configData = payload;
    },
    setVisibility: (state, { payload }) => {
      state.showProductCompare = payload;
    },
    setCompareProducts: (state, { payload }) => {
      state.compareProducts = payload;
    }
  },
  
  extraReducers: {
    [getConfigs.fulfilled]: (state, { payload }) => {
      state.showLoader = false;
      state.configList = payload.configData;
      state.lastEvaluatedKey = payload.lastEvaluatedKey;
    },
    [getConfigs.rejected]: (state) => {
      state.showLoader = false;
    },
    [getConfigs.pending]: (state) => {
      state.showLoader = true;
    },
    [createNewConfig.fulfilled]: (state) => {
      state.isLoading = false;
    },
    [createNewConfig.rejected]: (state) => {
      state.isLoading = false;
    },
    [createNewConfig.pending]: (state) => {
      state.isLoading = true;
    },
  },
});
export const { setConfigId, setCompareProducts, setVisibility } = configSlice.actions;
export default configSlice.reducer;
