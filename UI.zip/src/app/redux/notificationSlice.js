import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  type: "",
  message: "",
  loading: false,
  finish: false
};
const notificationSlice = createSlice({
  name: "notification",
  initialState,
  reducers: {
    setNotification: (state, { payload }) => {
      state.type = payload.type;
      state.message = payload.message;
    },
    clearNotification: (state) => {
      state.type = "";
      state.message = "";
      state.loading = false;
      state.finish = false;
    },
    setLoading: (state) => {
      state.loading = true;
    },
    finishLoading: (state, { payload }) => {
      state.finish = true;
      state.loading = false;
      state.type = payload.type;
      state.message = payload.message;
    },
  },
});

export const { setNotification, clearNotification,finishLoading, setLoading } = notificationSlice.actions;
export default notificationSlice.reducer;