import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import { signUp } from "../api/auth";
import { login, logout, 
  setpassword, sendPasswordEmail, changeUserPassword, getRefreshedToken,products} from "../api/login";
import { setNotification, setLoading, finishLoading, clearNotification } from "./notificationSlice";
import { updateAuthStore, getAccessToken, clearAuthStore, updateTokens } from "../shared/utils/localStore";
const user = JSON.parse(localStorage.getItem("user")); // can be get from store ..
import { getUserName } from "../shared/utils/localStore";
import { ERROR_MESSAGES, SUCCESS_MESSAGES } from "../shared/constants/messages";

export const register = createAsyncThunk(
  "auth/register",
  async (reqBody, thunkAPI) => {
    try {
      const response = await signUp(reqBody);
      thunkAPI.dispatch(setNotification({ type: "success", message: "Registration successfull" }));
      return response.data;
    } catch (error) {
      if (error.data && error.data.MESSAGE) {
        thunkAPI.dispatch(setNotification({ type: "error", message: error.data.MESSAGE }));
        return thunkAPI.rejectWithValue();
      } else {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Something went wrong" }));
        return thunkAPI.rejectWithValue();
      }
    }
  }
);
export const forgotPassword = createAsyncThunk(
  "auth/forgotPassword",
  async (reqBody, thunkAPI) => {
    try {
      const response = await sendPasswordEmail(reqBody);
      thunkAPI.dispatch(setNotification({ type: "success", message: "Email has been Sent to Your Account" }));
      return response.data;
    } catch (error) {
      if (error.data && error.data.MESSAGE) {
        thunkAPI.dispatch(setNotification({ type: "error", message: error.data.MESSAGE }));
        return thunkAPI.rejectWithValue();
      } else {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Something went wrong" }));
        return thunkAPI.rejectWithValue();
      }
    }
  }
);

export const signIn = createAsyncThunk(
  "auth/login",
  async (body, thunkAPI) => {
    try {
      const { response } = await login(body);
      const { username } = body;
      const { userStatus } = response;
      if (userStatus !== "CONFIRMED") {
        thunkAPI.dispatch(setNotification({ type: "info", message: "Login Success, Please update your password" }));
        thunkAPI.dispatch(firstTimeLogin(response));
        return response;
      } else {
        const jwt = JSON.parse(atob(response.accessToken?.split(".")[1]));
        const jwtExp = jwt && jwt.exp && jwt.exp * 1000;
        const AuthenticationResult = {
          accessToken: response.accessToken,
          refreshToken: response.refreshToken,
          idToken: response.idToken,
          loggedIn: true,
          userId: response.userId,
          userName: username,
          firstName: response.firstName,
          lastName: response.lastName,
          ExpiresAt: jwtExp,
        };
        const userData = {
          userId: response.userId,
          userName: response.userName,
          firstName: response.firstName,
          lastName: response.lastName,
        };
        updateAuthStore(AuthenticationResult);
        thunkAPI.dispatch(setNotification({ type: "success", message: "Login Successfully" }));
        thunkAPI.dispatch(completeLogin(userData));
        return response;
      }
    } catch (error) {
      if (error.data && error.data.MESSAGE) {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Username or Password incorrect" }));
        return thunkAPI.rejectWithValue();
      } else {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Something went wrong" }));
        return thunkAPI.rejectWithValue();
      }
    }
  });


export const resetPassword = createAsyncThunk(
  "auth/resetPassword",
  async (body, thunkAPI) => {
    try {
      const { response } = await setpassword(body);
      thunkAPI.dispatch(
        setNotification(
          { type: "success", message: "Password Reset Successfully, Please wait logging you In" }));
      const { password } = body;
      const { userId: username } = response;
      thunkAPI.dispatch(signIn({ username, password }));
      return response;
    } catch (error) {
      if (error.data && error.data.MESSAGE) {
        thunkAPI.dispatch(setNotification({ type: "error", message: error.data.MESSAGE }));
        return thunkAPI.rejectWithValue();
      } else {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Something went wrong" }));
        return thunkAPI.rejectWithValue();
      }
    }
  }
);
export const productsData = createAsyncThunk(
  "configs/productsData", 
  async (body, thunkAPI) => {
    try {
      console.log(body);
      const { response } = await products(body);
     
      return response;
    } catch(error) {
      thunkAPI.dispatch(({type: "error", message: "Something went wrong"}));
      if (error.data && error.data.MESSAGE) {
        console.log(error.data);
        thunkAPI.dispatch(setNotification({type: "error", message: error.data.MESSAGE }));
        return thunkAPI.rejectWithValue();
      } else {
        thunkAPI.dispatch(setNotification({type: "error", message: "Something went wrong" }));
        return thunkAPI.rejectWithValue();
      }
    }
  }
);
export const signOut = createAsyncThunk(
  "users/logout", 
  async (_body, thunkAPI) => {
    const accessToken = getAccessToken();
    thunkAPI.dispatch(setLoading());
    if(accessToken) {
      try {
        const response = await logout({accessToken});
        clearAuthStore();
        thunkAPI.dispatch(doLogout());
        thunkAPI.dispatch(finishLoading({type:"success", message: "Logout successfull"}));
        thunkAPI.dispatch(clearNotification());
        return response;
      } catch(error) {
        console.log(error);
        thunkAPI.dispatch(finishLoading({type: "error", message: "Something went wrong"}));
        if (error.data && error.data.MESSAGE) {
          thunkAPI.dispatch(setNotification({type: "error", message: error.data.MESSAGE }));
          return thunkAPI.rejectWithValue();
        } else {
          thunkAPI.dispatch(setNotification({type: "error", message: "Something went wrong" }));
          return thunkAPI.rejectWithValue();
        }
      }
    } else {
      clearAuthStore();
      thunkAPI.dispatch(doLogout());
    }
  }
);
export const changePassword = createAsyncThunk(
  "user/change-password",
  /**
   @param  {} body Current Password and New Password
   @param  {} thunkAPI 
  */
  async (body, thunkAPI) => {
    try {
      const email = getUserName();
      const { currentPassword, newPassword } = body;
      const { response } = await changeUserPassword({
        email,
        currentPassword,
        newPassword,
      });
      thunkAPI.dispatch(
        setNotification({
          type: "success",
          message: SUCCESS_MESSAGES.PASSWORD_CHANGE_SUCCESS,
        })
      );
      return response;
    } catch (error) {
      console.log(error);
      const message =
        error.data && error.data.ERROR_MESSAGE_CODE ? error.data.ERROR_MESSAGE_CODE : null;
      if (message) {
        thunkAPI.dispatch(
          setNotification({ type: "error", message: ERROR_MESSAGES[message] })
        );
      } else {
        thunkAPI.dispatch(
          setNotification({ type: "error", message: "Something went wrong" })
        );
      }
      return thunkAPI.rejectWithValue();
    }
  }
);
export const fetchRefreshedToken = createAsyncThunk(
  "users/refresh-token",
  /**
   * @param  {} refreshKey refresh token
   * @param  {} thunkAPI thunk api middleware
   */
  async (refreshKey, thunkAPI) => {
    try {
      const { response } = await getRefreshedToken(refreshKey);
      if (response && response.message) {
        let tokenData = response.message;
        updateTokens(tokenData);
      }
      return true;
    } catch (error) {
      const message = error.data && error.data.ERROR_MESSAGE_CODE ? error.data.ERROR_MESSAGE_CODE : null;
      if (message && ERROR_MESSAGES[message]) {
        thunkAPI.dispatch(setNotification({ type: "error", message: ERROR_MESSAGES[message] }));
      } else {
        thunkAPI.dispatch(setNotification({ type: "error", message: "Something went wrong" }));
      }
      return thunkAPI.rejectWithValue();
    }
  }
);

const initialState = {
  user: user,
  getProductList: { records: [] },
  isLoggedIn: false,
  isLoading: false,
  firstTimeLogin: false,
  forgotPasswordLoading: false,
  showTroubleLogin: false,
  token: "",
  uid: "",
  showLoader: false,
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setRedirect: (state, action) => {
      state.redirect = action.payload;
    },
    doLogout: (state) => {
      state.isLoggedIn = false;
    },
    firstTimeLogin: (state, action) => {
      state.firstTimeLogin = true;
      state.token = action.payload.token;
      state.uid = action.payload.userId;
    },
    completeLogin: (state, { payload: { user } }) => ({
      ...state,
      user,
      isLoggedIn: true,
    }),
    troubleLogin: (state, { payload }) => {
      state.showTroubleLogin = payload;
    },
    updateProduct: (state, { payload }) => {
      state.getProductList.records[payload.productIndex].selectToCompare = payload.selectToCompare; 
    },
    updateAllProduct: (state) => {
      state.getProductList.records.map((prod) => {
        prod.selectToCompare = false;
      });
    }
  },

  extraReducers: {
    [register.fulfilled]: (state) => {
      state.isLoading = false;
    },
    [register.rejected]: (state) => {
      state.isLoading = false;
    },
    [register.pending]: (state) => {
      state.isLoading = true;
    },
    [signIn.pending]: (state) => {
      state.isLoading = true;
    },
    [signIn.fulfilled]: (state) => {
      state.isLoading = false;
    },
    [signIn.rejected]: (state) => {
      state.isLoading = false;
      state.isLoggedIn = false;
    },
    [signOut.fulfilled]: (state) => {
      state.isLoggedIn = false;
      state.isLoading = false;
      state.user = null;
    },
    [signOut.pending]: (state) => {
      state.isLoading = true;
    },
    [signOut.rejected]: (state) => {
      state.isLoading = false;
    },
    [resetPassword.pending]: (state) => {
      state.isLoading = true;
    },
    [resetPassword.fulfilled]: (state) => {
      state.isLoading = false;
    },
    [resetPassword.rejected]: (state) => {
      state.isLoading = false;
    },
    [forgotPassword.fulfilled]: (state) => {
      state.forgotPasswordLoading = false;
      state.showTroubleLogin = false;
    },
    [forgotPassword.pending]: (state) => { state.forgotPasswordLoading = true; },
    [forgotPassword.rejected]: (state) => {
      state.forgotPasswordLoading = false;
      state.showTroubleLogin = false;
    },
    [changePassword.fulfilled]: (state) => {
      state.isLoading = false;
    },
    [changePassword.rejected]: (state) => {
      state.isLoading = false;
    },
    [changePassword.pending]: (state) => {
      state.isLoading = true;
    },
    [productsData.fulfilled]: (state, action) => {
      state.showLoader = false;
      const productList = action.payload.records.map((prod) => {
        return { ...prod, selectToCompare: false};
      });
      state.getProductList.records = productList;
    },
    [productsData.rejected]: (state) => {
      state.showLoader = false;
    },
    [productsData.pending]: (state) => {
      state.showLoader = true;
    },
  },
});
export const { setRedirect, firstTimeLogin, completeLogin, troubleLogin, doLogout, updateProduct, updateAllProduct } = userSlice.actions;
export default userSlice.reducer;
