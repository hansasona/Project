import React, { useState } from "react";
import { MyAccount, ModalTip } from "./header/Header.Styles";
import * as Icon from "react-bootstrap-icons";
import { HiddenSmall } from "../styles/components/Media.styled";
import Dropdown, { DropDownListItem } from "../styles/components/Dropdown";
import ChangePasswordComponent from "../../pages/auth/ChangePasswordComponent";
import { ButtonList } from "../styles/components/Button";
import Modal from "../styles/components/modal/Modal";
import { Link, useNavigate } from "react-router-dom";
import { colors } from "../styles/global/variables";
import Button from "../styles/components/Button";
import ReactTooltip from "react-tooltip";
import { signOut } from "../../redux/user";
import { useDispatch, useSelector } from "react-redux";
import { getName } from "../utils/localStore";

const MyAccountComponent = (props) => {
  const [isOpen, setOpen] = React.useState(false); 
  const [isActive, setPopupActive] = React.useState(false);
  const [showChangePasswordModal, setStateShowChangePasswordModal] = useState(false);
  const [configName, setConfigName] = useState(" ");
  const { isLoading } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const logout = () => {
    dispatch(signOut()).unwrap().then(() => {
      window.location.href = "/";
    });
  };
  const onClickChangePassword = () => {
    setOpen(false);
    setStateShowChangePasswordModal(true);
  };
  const closeChangePasswordModal = () => {
    setStateShowChangePasswordModal(false);
  };
  return (
    <>
      <MyAccount onClick={() => setPopupActive(!isActive)}>
        <Icon.PersonCircle size={21} color={colors.haze} />
        <HiddenSmall as="aside">
          <h5> { getName() } </h5>
        </HiddenSmall>
        <Dropdown rightAlign isActive={isActive}>
          <DropDownListItem active={showChangePasswordModal}>
            <Link onClick={onClickChangePassword}>Change Password</Link>
          </DropDownListItem>
          <DropDownListItem>
            <Link onClick={() => logout()}>Logout</Link>
          </DropDownListItem>
        </Dropdown>
      </MyAccount>
      <Modal
        active={showChangePasswordModal}
        hideModal={closeChangePasswordModal}
        title={<>
          Change Password <ModalTip data-tip={`A new password must fulfill below criteria <br/ > <br/ >
                1) Minimum length of 8 characters <br/ >
                2) At least one uppercase, or capital letter (ex: A, B, etc.) <br/ >
                3) At least one lowercase letter (ex: a, b, etc.) <br/ >
                4) At least one number (ex: 0,1, etc.) <br/ >
                5) At least one non-alphanumeric symbol. <br/ > <br/ >
               .`} data-html={true}><Icon.QuestionCircle size={18} /></ModalTip>
          <ReactTooltip multiline place="right" effect="solid" />
        </>}
        size="sm"
        footer={
          <>
            <ButtonList>
              <Button btnLink onClick={closeChangePasswordModal}>
                Cancel
              </Button>
              <Button
                type="submit"
                autoFocus
                isLoading={isLoading}
                form="changePasswordForm"
              >Submit</Button>
            </ButtonList>
          </>

        }
      >
        <ChangePasswordComponent
          onCloseChangePasswordModal={closeChangePasswordModal}
        />
      </Modal>
    </>
  );
};

export default MyAccountComponent;
