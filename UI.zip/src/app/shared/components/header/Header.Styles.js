/**
 * @ External Dependencies
 */
import styled from "styled-components";
import Button from "../../styles/components/Button";
import { FormGroup } from "../../styles/components/Form";
import { theme } from "../../styles/global/theme";
import { Link } from "react-router-dom";

/**
 * @ Internal Dependencies
 */

import {
  device,
  colors,
  spacing,
  fontSize,
  fontWeight,
} from "../../styles/global/variables";

const Header = styled.header`
	display: flex;
	position: relative;
	z-index: 10;
	padding: 0 ${spacing.size2};
	border-bottom: solid 1px ${colors.metal};
	background: ${colors.cotton};
	min-height: ${theme.header_height};
	align-items: center;
	position: sticky;
	bottom: 100%;
	h4 {
		font-weight: ${fontWeight.fontWeightMedium};
		white-space: nowrap;
	}
	@media ${device.lg} {
		flex-wrap: wrap;
		min-height: 100px;
	}
`;

export const HeaderAside = styled.div`
	display: flex;
	align-items: center;
	max-width: 100%;
	padding: ${spacing.sm} 0;
	margin-right: ${spacing.size2};
	@media ${device.lg} {
		flex-grow: 1;
	}
`;
export const HeaderConfigure = styled.div`
	display: flex;
	flex-grow: 1;
	align-items: center;
	align-items: end;
	padding: ${spacing.sm};
	${FormGroup} {
		margin-bottom: 0;
	}
	@media ${device.lg} {
		order: 1;
		width: 100%;
		padding: ${spacing.sm} 0;
		border-top: solid 1px ${colors.metal};
		${Button} {
			padding: ${spacing.sm} ${spacing.size3};
			font-size: ${fontSize.sm};
			height: 28px;
			font-weight: ${fontWeight.fontWeightNormal};
		}
	}
`;

export const Toggler = styled.div`
	cursor: pointer;
	padding: ${spacing.sm} 0;
	@media ${device.lg} {
		padding: ${spacing.xs} 0;
	}
	${(props) =>
    props.isOpen &&
		`
    color:${colors.cherry};  
  `}
`;

export const Brand = styled.img`
	width: ${spacing.size4};
	margin-left: ${spacing.size5};
	margin-right: ${spacing.size1};
	margin-bottom: 5px;
`;

export const HeaderDropdown = styled.div`
	position: absolute;
	left: 0;
	top: 0;
	padding: ${spacing.sm} ${spacing.size2};
	${(props) =>
    props.isOpen &&
		`
    background: ${colors.cotton};
    box-shadow: 0 0 25px rgb(0 0 0 / 13%);
    ${NavDropdown} {
      height:auto;
      min-width: 220px;
      width:auto;
      margin:0 -${spacing.size2};
    }
`}
`;

export const NavDropdown = styled.div`
	height: 0;
	overflow: hidden;
	padding: 0;
	width: 0;
	left: 0;

	li {
		&:hover {
			background: ${colors.fog};
		}
		a {
			text-decoration: none;
			display: block;
			padding: ${spacing.size1} ${spacing.size2};
			&:hover {
				color: ${colors.cherry};
			}
		}
	}
`;
export const ModalTip = styled.span`
	margin-left:${spacing.size1};
`;
export const ListItem = styled.li`
	${(props) =>
    props.active &&
		`
		background: ${colors.fog};
		color: ${colors.cherry};
		svg {
			color:${colors.cherry}!important;
		}
	`}
	
`;
export const StyledLinkWrapper = styled.div`
  padding-top: ${spacing.size2};
  text-align: center;

  small {
    margin-bottom: ${spacing.size4};
    display: block;
  }
`;
export const FormFieldWrapper = styled.div`
  margin-bottom: ${spacing.size5};
  ${(props) =>
    props.flex &&
    `
       display:flex;
       flex-wrap:wrap;
       margin:0 -${spacing.size1} ${spacing.size5};
       @media ${device.sm} {
        flex-direction:column;
       }
       && ${FormGroup} {
         flex: 0 0 auto;
         width: 50%;
         padding:0 ${spacing.size1};
         @media ${device.sm} {
           width: 100%;
          }
       }
       
     `}
`;
export const FormButtonWrapper = styled.div`
  text-align: center;

  ${Button} {
    width: 220px;
  }
`;
export const MyAccount = styled.div`
	flex: 0 0 auto;
	display: flex;
	cursor: pointer;
	position: relative;
	align-items: center;
	padding: ${spacing.size1} 0 ${spacing.size1} ${spacing.size1};
	margin-left: ${spacing.size1};
	border-left: solid 1px ${colors.metal};
	@media${device.lg} {
		margin-right: 0;
		padding-left: 0;
		border: 0;
	}
	svg {
		margin-right: ${spacing.size1};
		@media${device.sm} {
			margin-right: 0;
		}
	}

	aside {
		h5 {
			margin-bottom: 0;
		}
		small {
			color: ${colors.muted};
		}
	}
`;

export default Header;
