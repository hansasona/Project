import React, { useState } from "react";
import logo from "../../../../assets/images/logo.svg";
import Header, {
  Brand,
  HeaderAside,
  HeaderConfigure,
  HeaderDropdown,
  NavDropdown,
  Toggler,
} from "./Header.Styles";
import * as Icon from "react-bootstrap-icons";
import { Link, useNavigate } from "react-router-dom";
import Button from "../../styles/components/Button";
import { useDispatch, useSelector } from "react-redux";
import ReactTooltip from "react-tooltip";
import {
  FormControl,
  FormGroup,
  FormLabel,
} from "../../styles/components/Form";
import Modal from "../../styles/components/modal/Modal";
import ViewCartModalComponent from "../../../pages/product-configuration/ViewCartModalComponent";
import MyAccountComponent from "../MyAccountComponent";
import VehiclePlacement from "../VehiclePlacement";
import ConfigListModal from "../../../pages/home/ConfigListModal";

const HeaderComponent = () => {
  const [active, setActive] = React.useState(false);
  const [isOpen, setOpen] = React.useState(false); 
  const navigate = useNavigate();
  const { configData }  = useSelector((state) => state.config);
  const viewCartModal = () => {
    setActive(true);
  };
  const [vehiclePlacement, setVehiclePlacement] = useState(false);
  const openVehicleModal = () => {
    setVehiclePlacement(true);
  };

  const openConfiggModal = () => {
    setActive(true);
  };
  
  return (
    <Header>
      <HeaderAside>
        <HeaderDropdown isOpen={isOpen}>
          <Toggler isOpen={isOpen} onClick={() => setOpen(!isOpen)}>
            <Icon.List size={24} />
          </Toggler>
          <NavDropdown>
            <ul>
              <li>
                <Link onClick={(e) => { e.preventDefault(); navigate("/home"); }}>New</Link>
              </li>
              <li>
                <Link onClick={(e) => { e.preventDefault(); openConfiggModal(); }}>Open</Link>
              </li>
              <li>
                <Link>Save</Link>
              </li>
              <li>
                <Link>Save As...</Link>
              </li>
              <li>
                <Link onClick={() => openVehicleModal()}>
                  Vehicle Placement
                </Link>
              </li>
              <li>
                <Link>View Installation Manual</Link>
              </li>
              <li>
                <Link>View Cart</Link>
              </li>
              <li>
                <Link>View ISO Plot</Link>
              </li>
              <li>
                <Link>Download 3D step file...</Link>
              </li>
              <li>
                <Link>Add New Light...</Link>
              </li>
              <li>
                <Link>Print Summary...</Link>
              </li>
            </ul>
          </NavDropdown>
        </HeaderDropdown>
        <Brand src={logo} alt="Illumination Designer" />
        <h4>Illumination Designer</h4>
      </HeaderAside>
      <HeaderConfigure>
        <FormGroup inline>
          <FormLabel>Configuration Name:</FormLabel>
          <FormControl value={configData?.configName} type="text" small />
        </FormGroup>
        <Button onClick={() => viewCartModal()}>
					View Cart <span>(0)</span>
        </Button>
      </HeaderConfigure>
      <MyAccountComponent />
      <Modal
        active={active}
        hideModal={() => setActive(false)}
        size="xl"
        pageBodyModal
      >
        <ViewCartModalComponent />
      </Modal>
      <Modal
        active={vehiclePlacement}
        hideModal={() => setVehiclePlacement(false)}
        modalType="fullscreen"
        title="Vehicle Placement"
        size="lg"
        scrollable
      >
        <VehiclePlacement />
      </Modal>
      
      <Modal
        active={active}
        hideModal={() => setActive(false)}
        title="Configuration List"
        size="sm"
        scrollable
      >
        <ConfigListModal />
      </Modal>
    </Header>
  );
};

export default HeaderComponent;
