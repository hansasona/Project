import React from "react";
import { Lead } from "../../shared/styles/global/typography";
import {
  ModalBodyScroller,
  ModalPageBodyTitle,
} from "../../shared/styles/components/modal/Modal.Styles";

import * as Icon from "react-bootstrap-icons";
import {
  ImageItem,
  PlacementImage,
} from "../../pages/product-configuration/ProductConfiguration.Styles";

const VehiclePlacement = () => {
  return (
    <div>
      <ModalPageBodyTitle>
        <Lead>Below are some suggested locations for vehicle placement</Lead>
      </ModalPageBodyTitle>

      <ModalBodyScroller>
        <PlacementImage>
          <ImageItem>
            <Icon.ImageAlt size={72} />
          </ImageItem>
          <ImageItem>
            <Icon.ImageAlt size={72} />
          </ImageItem>
          <ImageItem>
            <Icon.ImageAlt size={72} />
          </ImageItem>
        </PlacementImage>
      </ModalBodyScroller>
    </div>
  );
};

export default VehiclePlacement;
