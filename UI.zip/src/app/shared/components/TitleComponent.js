import React from "react";
import { Helmet } from "react-helmet";

const TitleComponent = (props) => {
  return (
    <Helmet>
      <title>{props.title ? props.title : ""}</title>
      <meta
        name="description"
        content={props.title} // change the content if want
      />
    </Helmet>
  );
};

export default TitleComponent;
