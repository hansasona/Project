import React, { useEffect,useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import { clearNotification } from "../../redux/notificationSlice";
const Notifications = () => {
  const { type, message, loading, finish } = useSelector(state => state.notification);
  const [toastId, setToastId] = useState("");
  const dispatch = useDispatch();
  useEffect(() => {
    const resetToaster = () => {
      dispatch(clearNotification());
    };
    if(type !=="" && message !== "" && !finish) {
      toast(message, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true, 
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        type,
        theme: "colored",
        onClose: resetToaster
      });
    }
    if (loading) {
      const id = toast("Please wait ...");
      setToastId(id);
    }
    if(finish) {
      toast.update(toastId, { render: message, type: type, isLoading: false, autoClose: 1000 } );
    }
  }, [type, message,loading, finish, dispatch]);
  return ( <ToastContainer/> );
};

export default Notifications;
