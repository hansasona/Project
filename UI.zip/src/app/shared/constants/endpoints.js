// const env = (window && window.location.host).toString().split('.')[0]; 
// commented for now, will require in further updates.
export const baseApiUrl = "https://53nvnodom6.execute-api.us-east-1.amazonaws.com/eic";
export const baseApiUrlEIC = "https://53nvnodom6.execute-api.us-east-1.amazonaws.com/eic";
export const baseApiUrlProd = "https://53nvnodom6.execute-api.us-east-1.amazonaws.com/eic";
export const baseUrlProd = "https://53nvnodom6.execute-api.us-east-1.amazonaws.com/eic";

export const userId = "";

export const config = "/config";
export const loginPath = "/auth/login";
export const logoutPath = "/auth/logout";
export const setpasswordPath = "/users/set-password";
export const forgotPasswordPath = "/users/forgot-password";
export const signUpPath = "/users";
export const changePasswordPath = "/users/change-password";
export const refreshedToken = "/auth/refresh-token";
export const configPath = "/configs";
export const productPath = "/configs/config-products-metadata?pageSize=20&pageNum=1";

export const sessionTimeout = 30; // minutes
export const sessionNotificationTimeout = 30; // seconds