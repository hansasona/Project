export const ERROR_MESSAGES = {
  GET_CONFIG_DATA: "Failed to retrieve configuration.",
  GET_TONES_DATA: "Failed to retrieve DVM tones.",
  GET_CONFIG_LIST: "Failed to retrieve configuration list.",
  SAVE_CONFIG: "Failed to save the configuration.",
  SAVE_AS_CONFIG: "Failed to save as the configuration.",
  CONFIG_NAME_VALIDATION: "Configuration name should be of min 4 and max 80 characters.",
  CONFIG_NAME_EXISTS_EXCEPTION: "Configuration already exist with the provided name.",
  CONFIG_REQUIRED_CONFIG_NAME: "Configuration name can not be empty",
  LOGIN_ERROR: "Invalid Username or Password",
  RESET_PASSWORD_ERROR: "Error in set password, Please try again later",
  USER_TOKEN_EXPIRED:
      "Link to reset the password is expired. Please click on \"Trouble Logging In?\" to reset the password.",
  USER_INVALID_INFO: "Process or URL is interrupted. Please try again with valid URL",
  SESSION_EXPIRED: "Session Is Expired. Please Sign In Again.",
};
  
export const SUCCESS_MESSAGES = {
  USER_SIGNUP: "Registration Successful. Please check your email.",
  SAVE_CONFIG: "Configuration updated successfully",
  SAVE_AS_CONFIG: "Configuration created successfully",
  DELETE_CONFIG: "Configuration deleted successfully",
  RESET_PASSWORD_SUCCESS: "Password set successfully",
  PASSWORD_CHANGE_SUCCESS: "Password changed successfully",
  TROUBLE_LOGIN_EMAIL_SENT: "Email has been sent to your email account.",
};
  
export const WARN_MESSAGES = {
  UNSAVED_CHANGES_CONFM:
      "You have some unsaved changes, would you like to save your current configuration before proceeding?"
};
  
  