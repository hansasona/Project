import { baseApiUrl, baseApiUrlEIC, baseApiUrlProd, baseUrlProd } from "../../shared/constants/endpoints";

const apiUrl = (() => {
  let host = window && window.location.host;

  if (!host || host.includes("localhost:")) {
    return baseApiUrl;
  }
  if (host && host.startsWith(baseUrlProd)) {
    return baseApiUrlEIC;
  }
  return baseApiUrlProd;
})();

export default apiUrl;
 