// import { localStore, authKey } from 'shared/constants/localStore';
const frPrefix = "@illumination.ui";
export const localStore = window.localStorage;
export const authKey = `${frPrefix}:auth`;
// Update the values stored in localstorage
export const updateAuthStore = ({
  accessToken,
  refreshToken,
  idToken,
  loggedIn,
  userId,
  userName,
  firstName,
  lastName,
  ExpiresAt,
}) => {
  if (localStore) {
    const authState = JSON.parse(localStore.getItem(authKey));
    localStore.setItem(
      authKey,
      JSON.stringify({
        ...authState,
        accessToken,
        refreshToken: refreshToken || getRefreshToken(),
        idToken,
        loggedIn,
        userId,
        userName,
        firstName,
        lastName,
        ExpiresAt,
        soundMute: false,
      })
    );
  }
};
// Update the values stored in localstorage
export const updateSoundMuteAuthStore = ({ soundMute }) => {
  if (localStore) {
    const authState = JSON.parse(localStore.getItem(authKey));
    localStore.setItem(
      authKey,
      JSON.stringify({
        ...authState,
        soundMute: soundMute,
      })
    );
  }
};

// Update the values stored in localstorage
export const setConfigIdinLocalStorage = ({ configId }) => {
  if (localStore) {
    const authState = JSON.parse(localStore.getItem(authKey));
    localStore.setItem(
      authKey,
      JSON.stringify({
        ...authState,
        configId,
      })
    );
  }
};
// Update token values stored in localstorage
export const updateTokens = (tokenData) => {
  const idToken = tokenData.IdToken;
  const accessToken = tokenData.AccessToken;
  const jwt = JSON.parse(atob(accessToken?.split(".")[1]));
  const jwtExp = jwt && jwt.exp && jwt.exp * 1000;
  if (localStore) {
    const authState = JSON.parse(localStore.getItem(authKey));
    localStore.setItem(
      authKey,
      JSON.stringify({
        ...authState,
        accessToken,
        idToken,
        ExpiresAt: jwtExp,
      })
    );
  }
};

// Fetch the data from localstorage
const getAuthState = () => JSON.parse(localStore.getItem(authKey));

// Remove the data from localstorage
export const clearAuthStore = () => {
  if (localStore) {
    localStore.setItem(authKey, JSON.stringify({}));
    localStore.setItem(authKey, JSON.stringify({ loggedIn: false }));
  }
};

// Get the Access token from local storage
export const getAccessToken = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { accessToken } = authState;
      return accessToken;
    }
    return "";
  }
};

// Get the Refresh token from local storage
export const getRefreshToken = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { refreshToken } = authState;
      return refreshToken;
    }
    return "";
  }
};

// Get the Id token from local storage
export const getIdToken = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { idToken } = authState;
      return idToken;
    }
    return "";
  }
};

// Get the Expiry Time from local storage
export const getExpiryTime = () => {
  if (localStore) {
    const authState = JSON.parse(localStore.getItem(authKey)) || {};
    if (authState) {
      const { ExpiresAt } = authState;
      return ExpiresAt;
    }
    return 0;
  }
};

// Check user is logged in and have valid token or not
export const loginIsFresh = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { AccessToken, IdToken, ExpiresAt } = authState;
      return AccessToken !== null && IdToken !== null && ExpiresAt > new Date().getTime();
    }
    return false;
  }
};

export const isExpired = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { ExpiresAt } = authState;
      return ExpiresAt <= new Date().getTime();
    }
    return false;
  }
};
// Get the vehicle data from local storage
export const getVehicleData = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { vehicleData } = authState;
      return vehicleData;
    }
    return "";
  }
};

// Get the configId from local storage
export const getConfigId = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { configId } = authState;
      return configId;
    }
    return "";
  }
};

// Check user is logged i or not frrom the localstorage
export const isUserLoggedin = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { loggedIn } = authState;
      return loggedIn;
    }
    return "";
  }
};

// get userId
export const getUserId = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { userId } = authState;
      return userId;
    }
    return "";
  }
};

// get name
export const getName = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { firstName, lastName } = authState;
      return `${firstName} ${lastName}`;
    }
    return "";
  }
};

// get userId
export const getUserName = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { userName } = authState;
      return userName;
    }
    return "";
  }
};

// get sound mute status
export const getSoundMute = () => {
  if (localStore) {
    const authState = getAuthState();
    if (authState) {
      const { soundMute } = authState;
      return soundMute;
    }
    return false;
  }
};
