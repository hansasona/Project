/**
 * @ External Dependencies
 */
import styled from "styled-components";
//When using this component always set the title to the value so that if truncation occurs, the full detail can be viewed in the tooltip
export const TruncatedText = styled.div`
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  ${(props) =>
    props.jobid &&
    `
    width : 450px;
  `};
  ${(props) =>
    props.jobname &&
    `
    width : 300px;
  `};
`;

//For use when wraping is desired, but truncation is needed with a long single word
export const TruncatedTextWithWrap = styled.div`
  overflow: hidden;
  text-overflow: ellipsis;
`;
