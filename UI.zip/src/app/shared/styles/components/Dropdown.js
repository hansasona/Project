/**
 * @ External Dependencies
 */
import styled from "styled-components";

/**
 * @ Internal Dependencies
 */

import {
  colors,
  spacing,
  borderRadius,
  fontWeight,
} from "../global/variables";


export default styled.div`
	box-shadow: 0 0.5rem 1rem rgb(0 0 0 / 15%);
	z-index: 1030;
	border: solid 1px #ddd;
	background: #fff;
	position: absolute;
	display: ${({ isActive }) => (isActive ? "block" : "none")};
	right: 0;
	left: auto;
	top: 100%;
	min-width: 11rem;
	padding: ${spacing.size1} 0;
	border-radius: ${borderRadius.sm};

	&:before {
		right: 0.75rem;
		content: "";
		position: absolute;
		top: -0.25rem;
		left: 0.75rem;
		display: block;
		background: inherit;
		width: 14px;
		height: 14px;
		transform: rotate(45deg);
		transform-origin: center;
		border: 1px solid;
		border-color: inherit;
		z-index: -1;
		clip: rect(0, 9px, 9px, 0);
	}
	${(props) =>
    props.rightAlign &&
		`
    &:before {
      left:auto;
    }
     
   `};
`;

export const DropDownListItem = styled.li`
  min-width: 11rem;
  margin: 0;
  line-height: 1.4285714286;
  clear: both;
  font-weight: ${fontWeight.fontWeightNormal};
  color: ${colors.midnight};
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  a {
    padding: ${spacing.sm} ${spacing.size2};
    display:block;
     text-decoration: none;
  }
  a:hover {
    color: ${colors.charcoal};
    background: ${colors.fog};
  }
}
`;

export const DropBox = styled.li`
  position:relative;
  padding:${spacing.size1} 0;
}
`;
