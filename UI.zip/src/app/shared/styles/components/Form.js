/**
 * @ External Dependencies
 */
import styled from "styled-components";
import {
  borderRadius,
  colors,
  fontSize,
  fontWeight,
  hexWithOpacity,
  spacing,
} from "../global/variables";

// Forms style

export const FormGroup = styled.div`
	margin-bottom: ${spacing.size3};

	:last-child {
		margin-bottom: 0;
	}

	${(props) =>
    props.inline &&
		`
        display:flex;
        flex-wrap:wrap;
        align-items:center;
        flex-grow:1;

        && > ${FormLabel} {
         margin:bottom:0;
         margin-right:5px;
        }
        && > ${FormControl} {
          max-width:200px;
        }
      `}
`;

export const FormLabel = styled.label`
	color: #151515;
	font-size: 11px;
	letter-spacing: 1.5px;
	white-space: nowrap;
	margin-bottom: 0.25rem;
	text-transform: uppercase;
	display: block;
	font-weight: ${fontWeight.fontWeightMedium};
	text-align: left;
	${(props) =>
    props.small &&
		`
    font-size: ${fontSize.xs};
    letter-spacing: 1.5px;
    text-transform: uppercase;
    `}
`;

export const FormControl = styled.input`
	display: block;
	width: 100%;
	max-width: 320px;
	padding: 0.4375rem 0.75rem;
	height: 40px;
	font-size: 0.875rem;
	font-weight: 400;
	line-height: 1.4285714286;
	color: inherit;
	background-color: ${colors.cotton};
	background-clip: padding-box;
	border: 1px solid ${colors.metal};
	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;
	border-radius: 3px;
	transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;

	&:focus {
		color: inherit;
		background-color: ${colors.cotton};
		border-color: #90b5e2;
		outline: 0;
		box-shadow: 0 0 0 0.25rem rgb(32 107 196 / 25%);
	}
	${(props) =>
    props.small &&
		`
    padding: 0.375rem 0.75rem;
    height: 30px;
    font-size: 0.725rem;
  `}

	${(props) =>
    props.fluid &&
		`
   max-width:100%;
  `}

  ${(props) =>
    props.inlineInput &&
		`
	padding: 0.4375rem 0;
    border:none;
	color:${colors.muted};
	background:none;
	border-bottom:solid 1px ${colors.metal};
  `}
`;

export const FormSelect = styled.select`
	display: block;
	width: 100%;
	max-width: 320px;
	padding: 0.4375rem 2.25rem 0.4375rem 0.75rem;
	background-repeat: no-repeat;
	background-position: right 0.75rem center;
	background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23a5a9b1' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
	background-size: 16px 12px;
	font-size: 0.875rem;
	font-weight: 400;
	line-height: 1.4285714286;
	color: inherit;
	background-color: ${colors.cotton};
	background-clip: padding-box;
	border: 1px solid ${colors.metal};
	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;
	border-radius: 3px;
	color: ${colors.haze};
	transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	${(props) =>
    props.small &&
		`
    padding: 0.375rem 0.75rem;
    height: 30px;
    font-size: 0.725rem;
  `}
	&:focus {
		color: inherit;
		background-color: ${colors.cotton};
		border-color: #90b5e2;
		outline: 0;
		box-shadow: 0 0 0 0.25rem rgb(32 107 196 / 25%);
	}
`;

export const Validation = styled.span`
	display: block;
	font-size: ${fontSize.sm};
	padding-top: ${spacing.xs};
	${(props) =>
    props.isInvalid &&
		`
      color:${colors.cherry};
      
    `}
	${(props) =>
    props.isValid &&
		`
      color:${colors.grass};
      
    `}
    ${(props) =>
    props.hidden &&
		`
        display:none;
        
    `}
`;

export const LinkClose = styled.span``;
export const InputGroupAddons = styled.div`
	position: relative;
	margin-bottom: ${spacing.size2};
	svg {
		position: absolute;
		top: 50%;
		left: 15px;
		transform: translateY(-50%);
		color: ${colors.muted};
	}
	${FormControl} {
		max-width: 100%;
		padding-left: ${spacing.size5};
	}
	${LinkClose} {
		position: absolute;
		top: 50%;
		right: 15px;
		transform: translateY(-50%);
		color: ${colors.muted};
		width: 2rem;
	}

`;

export const LinkAddons = styled.a``;

export const InputGroup = styled.div`
	position: relative;
	display: flex;
	flex-wrap: wrap;
	align-items: stretch;
	width: 100%;

	${(props) =>
    props.widthAuto &&
		`
      width:320px;
      
    `}

	&& > ${FormControl} {
		position: relative;
		flex: 1 1 auto;
		width: 1%;
		min-width: 0;
	}

	button {
		position: relative;
		z-index: 2;
		margin-left: -2px;
		border-radius: 0 3px 3px 0 !important;
	}
	${(props) =>
    props.btnAddons &&
		`
    position:relative;
    && > ${FormControl} {
      padding-right:${spacing.size5};
      height:auto;
    }
    ${LinkAddons} {
      font-size:${fontSize.normal};
      position:absolute;
      cursor:pointer;
      right:${spacing.size1};
      top: 50%;
      transform: translateY(-50%);
      height:${fontSize.normal};
    }   
  `}
`;

export const FormCheckList = styled.div`
	padding: ${spacing.xs} 0 0;
`;

export const InlineGroup = styled.div`
	display: flex;
	align-items: center;
	* {
		margin-right: ${spacing.size1};
	}
`;

export const FormCheck = styled.label`
	display: flex;
	cursor: pointer;
	font-weight: ${fontWeight.fontWeightMedium};
	position: relative;
	overflow: hidden;
	margin-bottom: 2px;
	input[type="radio"] {
		position: absolute;
		left: -9999px;
		&:checked + span {
			background-color: ${hexWithOpacity(colors.haze, 0.1)};
			color: ${colors.midnight};
			&:before {
				box-shadow: inset 0 0 0 0.4375em ${colors.cherry};
			}
		}
	}
	input[type="radio"] + span {
		display: flex;
		align-items: center;
		color: ${colors.haze};
		border-radius: 99em;
		transition: 0.25s ease;
		padding: ${spacing.xs} ${spacing.size2} ${spacing.xs} ${spacing.xs};
		&:hover {
			background-color: mix(#fff, ${colors.cherry}, 84%);
		}
		&:before {
			display: flex;
			flex-shrink: 0;
			content: "";
			background-color: #fff;
			width: 1.5em;
			height: 1.5em;
			border-radius: 50%;
			margin-right: 0.375em;
			transition: 0.25s ease;
			box-shadow: inset 0 0 0 0.125em ${colors.metal};
		}
	}
	input[type="checkbox"] {
		position: absolute;
		left: -9999px;
		&:checked + span {
			color: ${colors.midnight};
			&:before {
				box-shadow: inset 0 0 0 0.9em ${colors.cherry};
			}
			&:after {
				opacity: 1;
			}
		}
	}

	input[type="checkbox"] + span {
		display: flex;
		align-items: center;
		color: ${colors.haze};
		transition: 0.25s ease;
		padding: ${spacing.xs} ${spacing.size3} ${spacing.xs} ${spacing.xs};
		&:before {
			display: flex;
			flex-shrink: 0;
			content: "";
			background-color: ${colors.cotton};
			width: 1.5em;
			height: 1.5em;
			border-radius: ${borderRadius.xs};
			margin-right: ${spacing.sm};
			transition: 0.25s ease;
			box-shadow: inset 0 0 0 0.125em ${colors.metal};
		}
		&:after {
			content: "";
			opacity: 0;
			transition: 0.25s ease;
			display: block;
			position: absolute;
			top: 7px;
			left: 11px;
			width: 5px;
			height: 10px;
			border: solid ${colors.cotton};
			border-width: 0 1.5px 2px 0;
			transform: rotate(45deg);
		}
	}
`;
