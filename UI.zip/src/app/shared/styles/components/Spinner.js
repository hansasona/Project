import styled from "styled-components";
import { colors, spacing } from "../global/variables";

export const Spinner = styled.div`
  display: inline-block;
  width: 100%;
  height: 100%;
  vertical-align: text-bottom;
  border: 0.25em solid;
  border-color: ${colors.midnight};
  border-right: 0.25em solid transparent;
  border-radius: 50%;
  animation: spinner 0.75s linear infinite;
`;

export const ButtonSpinner = styled.div`
  width: 25px;
  height: 25px;
  vertical-align: text-bottom;
  border: 2px solid;
  border-color: ${colors.fog};
  border-right: 2px solid transparent;
  border-radius: 50%;
  animation: spinner 0.75s linear infinite;
  position: absolute;
  overflow: visible;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  cursor: not-allowed;
`;

export const TableSpinner = styled.div`
  min-width: 20px;
  min-height: 20px;
  max-width: 20px;
  max-height: 20px;
  vertical-align: text-bottom;
  border: 2px solid;
  border-color: ${colors.midnight};
  border-right: 2px solid transparent;
  border-radius: 50%;
  animation: spinner 0.75s linear infinite;
  margin-right: 13px;
`;

export const LoaderComponent = styled.div`
  position: absolute;
  left:0;
  top:0;
  color: transparent!important;
  pointer-events: none;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 99;
  backdrop-filter: blur(4px);
  background: rgba(0,0,0,0.2);
  &:after {
    content: "";
    display: inline-block;
    vertical-align: text-bottom;
    border: 3px solid ${colors.cotton};
    border-right-color: transparent;
    border-radius: 100rem;
    color:${colors.cotton};
    position: absolute;
    width: calc(${spacing.size4} + ${spacing.xs});
    height: calc(${spacing.size4} + ${spacing.xs});
    animation: spinner 0.75s linear infinite;
  }
`;
