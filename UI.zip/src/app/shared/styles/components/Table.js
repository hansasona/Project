/**
 * @ External Dependencies
 */
import styled from "styled-components";

/**
 * @ Internal Dependencies
 */
import { colors, fontWeight, spacing } from "../global/variables";

export default styled.table`
  width: 100%;
  color: ${colors.charcoal};
  vertical-align: top;
  caption-side: bottom;
  border-collapse: separate;
  border-spacing: 0;
  table > :not(caption) > * > * {
    padding: 0.5rem;
    background-color: var(--bs-table-bg);
    border-bottom-width: 1px;
    box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg);
  }

  tbody,
  td,
  tfoot,
  th,
  thead,
  tr {
    border-color: ${colors.metal};
    border-style: solid;
    border-width: 0;
  }

  table tr td:first-child,
  table tr th:first-child {
    padding-left: 1.5rem;
    border-left: 0;
  }

  table tr td:last-child,
  table tr th:last-child {
    padding-right: 1.5rem;
    border-right: 0;
  }

  th {
    color: ${colors.muted};
    font-size: 0.625rem;
    font-weight: ${fontWeight.fontWeightBold};
    text-transform: uppercase;
    letter-spacing: 0.04em;
    line-height: 1rem;
    text-align: left;
    padding: ${spacing.size1} ${spacing.size2} ${spacing.size1} ${spacing.size2};
    white-space: nowrap;
    border: none;
  }

  td {
    padding: 0 ${spacing.size2} ${spacing.size1} ${spacing.size2};
    color: ${colors.charcoal};
    font-size: 12px;
    border-bottom: solid 1px ${colors.fog};
  }
  .checkbox {
    margin-right: 16px;
  }

  tr {
    &:last-child td {
      border-bottom: 0 none;
    }

    &:hover {
      background: none;
    }
  }
`;

export const SortArrowSpan = styled.span`
  margin-left: 10px;
  opacity: 0;
  ${(props) =>
    props.isSorted &&
    `
    opacity: 1;
	`};
`;
