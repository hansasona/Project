import styled from "styled-components";
import { ProductContainer } from "../../../../pages/product-configuration/ProductConfiguration.Styles";
import { Lead } from "../../global/typography";
import { device, colors, spacing, fontSize } from "../../global/variables";
import Button from "../Button";


export const ModalOverlay = styled.div`
	bottom: 0;
	cursor: default;
	display: block;
	left: 0;
	position: fixed;
	right: 0;
	top: 0;
	opacity: 0.5;
`;

export const ModalBlock = styled.div`
	display: block;
	height: 100%;
	left: 0;
	outline: 0;
	overflow-y: scroll;
	overflow-x: hidden;
	position: fixed;
	top: 0;
	width: 100%;
	z-index: 1050;
	backdrop-filter: blur(4px);
	background: rgba(0, 0, 0, 0.5);
	padding: ${spacing.sm};

	${(props) =>
    props.pageBodyModal &&
		`
		${ModalContent} {
			height:100%;
		}
		${ModalDialog} {
			height: calc(100% - 3.5rem);
		}
		${ModalBody} {
			height:100%;
			padding:0;
			flex-direction: column;
			display: flex;
		}
		@media ${device.lg} {
			background:none;
			backdrop-filter: blur(0);
			padding:0;
			top:50px;
			${ModalContent} {
				border-radius:0;
				box-shadow: none;
			}	
			${ModalDialog} {
				margin:0;
			}
		}
		
    `}

	${(props) =>
    props.fullScreen &&
		`
		${ModalDialog} {
			height: 100%;
		}
		
		@media ${device.lg} {
			top:0px;
			${ModalPageBodyTitle} {
				padding-top:${spacing.size1};
			}
		}
		
    `}
`;



export const ModalBody = styled.div`
	color: #1e293b;
	flex: 1 1 auto;
	font-size: 0.875rem;
	padding: 1.5rem;
	position: relative;

	&.modal-dialog-scrollable {
		overflow-y: auto;
	}
`;

export const ModalContent = styled.div`
	background: #ffffff;
	border-radius: 5px;
	display: flex;
	flex-direction: column;
	background-color: #fafbfc;
	width: 100%;
	animation: slide-down 0.2s ease 1;
	z-index: 99;
	position: relative;
	box-shadow: 0 0.2rem 0.5rem rgba(48, 55, 66, 0.3);
`;

export const ModalDialog = styled.div`
	transition: transform 0.3s ease-out;
	position: relative;
	width: auto;
	margin: 1.75rem auto;
	display: flex;
	align-items: center;
	min-height: calc(100% - 3.5rem);
	max-width: ${(props) => {
    switch (props.size) {
    case "xs":
      return "420";
    case "sm":
      return "576";
    default:
      return "768";
    case "lg":
      return "992";
    case "xl":
      return "1200";
    case "xxl":
      return "1400";
    case "fluid":
      return "auto";
    }
  }}px;
	z-index: 1050;
	@media ${device.sm} {
		max-width:-webkit-fill-available;
		margin:0;		
	}
	${(props) =>
    props.scrollable &&
		`
		height: calc(100% - 3.5rem);
    	${ModalContent} {
			max-height: 100%;
			overflow: hidden;
		}
		${ModalBody} {
			overflow-y: auto;
		}    
    `}

	${ProductContainer} {
		border-bottom: none;
		margin-bottom: 0;
		padding-bottom: 0;
	}
	&.modal-dialog-scrollable {
		max-height: calc(100% - 3.5rem);
	}
`;

export const ModalHeader = styled.div`
	align-items: flex-start;
	border-bottom: 1px solid #dee2e6;
	border-top-left-radius: calc(0.3rem - 1px);
	border-top-right-radius: calc(0.3rem - 1px);
	display: flex;
	justify-content: space-between;
	padding: 1rem;
	background: ${colors.cotton};
	position: relative;
	text-align: left;
`;

export const ModalClose = styled.a`
	text-decoration: none !important;
	cursor: pointer;
	font-size: 1.25rem;
	height: 3.5rem;
	line-height: 3.5rem;
	right: 0;
	top: 0;
	width: 3.5rem;
	z-index: 10;
	position: relative;
	display: flex;
	position: absolute;
	align-items: center;
	justify-content: center;
	opacity: 0.5;

	&:hover {
		opacity: 1;
	}
`;


export const ModalTitle = styled.h3`
	font-size: 1.25rem;
	font-weight: 600;
	line-height: 1.4285714286;
	margin-bottom: 0;
	flex-grow: 1;
`;

export const ModalBodyScroller = styled.div`
	text-align:center;
	overflow-y: auto;
	padding:${spacing.size2};
	height:100%;
`;

export const ModalPageBodyTitle = styled.div`
	padding-top:${spacing.size1};
	text-align:center;
	margin-bottom:${spacing.size2};
	@media ${device.sm} {
		padding:0 ${spacing.size2};
		text-align:left;
		margin:0;
		${(props) =>
    props.CenterAlign &&
		`
		text-align:center;
    `}
	}
	${(props) =>
    props.CenterAlign &&
		`
		padding:0;
    `}
	
	${ModalTitle} {
		margin:${spacing.size1} 0;
	}
	${Lead} {
		color:${colors.muted};
		font-size:${fontSize.normal};
	}
`;


export const ModalFooter = styled.div`
	align-items: center;
	background: ${colors.cotton};
	border-bottom-left-radius: calc(0.3rem - 1px);
	border-bottom-right-radius: calc(0.3rem - 1px);
	border-top: 1px solid #dee2e6;
	display: flex;
	flex-wrap: wrap;
	justify-content: flex-end;
	padding: 0.75rem;
`;

export const AlertModal = styled.div`
	display: block;
	padding-top: ${spacing.size1};
	margin-bottom: ${spacing.size3};
	text-align: center;
	svg {
		margin-bottom: ${spacing.size3};
		color: ${colors.cherry};
	}
	p {
		font-size: ${fontSize.lg};
		color: ${colors.muted};
	}
`;

export const AlertFooter = styled.div`
	display: block;
	padding-top: ${spacing.size1};
	text-align: center;
	${Button} {
		margin: 0 ${spacing.sm};
	}
`;


export const ModalInlineFooter = styled.div`
	display: flex;
	padding: ${spacing.size1};
  	border-top: solid 1px ${colors.metal};
  	justify-content: end;
	${Button} {
		margin: 0 ${spacing.sm};
	}
	@media ${device.sm} {
		justify-content: center;
	}
`;