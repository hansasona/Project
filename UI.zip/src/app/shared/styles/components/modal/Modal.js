import React, { Fragment, useEffect } from "react";
import * as Icon from "react-bootstrap-icons";

import {
  ModalBlock,
  ModalDialog,
  ModalBody,
  ModalClose,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  ModalTitle,
} from "./Modal.Styles";

const Modal = ({
  title,
  footer,
  children,
  active,
  hideModal,
  size,
  scrollable,
  inBodyTitle,
  pageBodyModal,
  fullScreen,
  
}) => {
  useEffect(() => {
    if (active) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }},[active]);
  return (
    <Fragment>
      {active && (
        <ModalBlock pageBodyModal={pageBodyModal} fullScreen={fullScreen}>
          <ModalOverlay onClick={() => hideModal()}></ModalOverlay>
          <ModalDialog scrollable={scrollable} size={size}>
            <ModalContent>
              <ModalClose onClick={() => hideModal()}>
                <Icon.XLg />
              </ModalClose>
              {title && (
                <ModalHeader inBodyTitle={inBodyTitle}>
                  <ModalTitle>{title}</ModalTitle>
                </ModalHeader>
              )}
              <ModalBody>{children}</ModalBody>
              {footer && <ModalFooter>{footer}</ModalFooter>}
            </ModalContent>
          </ModalDialog>
        </ModalBlock>
      )}
    </Fragment>
  );
};
export default Modal;
