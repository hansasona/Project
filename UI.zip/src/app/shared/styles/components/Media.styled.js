import styled from "styled-components";

import { device } from "../global/variables";

export const HiddenMedium = styled.div`
  @media ${device.md} {
    display: none;
  }
`;

export const HiddenLarge = styled.div`
  @media ${device.lg} {
    display: none;
  }
`;

export const HiddenSmall = styled.div`
  @media ${device.sm} {
    display: none;
  }
`;

export const VisibleLarge = styled.div`
  display: none;
  @media ${device.lg} {
    display: block;
  }
`;

export const VisibleMedium = styled.div`
  display: none;
  @media ${device.md} {
    display: block;
  }
`;
