/**
 * @ External Dependencies
 */
import styled from "styled-components";
import { colors, fontSize, fontWeight, spacing } from "../global/variables";

/**
 * @ Internal Dependencies
 */

const ListGroup = styled.div`
  border-radius: 0.25rem;
  margin-bottom: 0;
  padding-left: 0;

  li {
    background-color: #fff;
    border-bottom: 1px solid rgba(0, 0, 0, 0.125);
    display: block;
    padding: ${spacing.size1} ${spacing.size2};
    position: relative;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    :last-child {
      border-bottom: none;
    }
    .nodata-record {
        text-align:center;
        color:${colors.muted};
    }
  }

  li + li {
    border-top-width: 0;
  }
`;

export const ListGroupScrollList = styled(ListGroup) `
  max-height:50vh;
  min-height:50px;
  overflow:auto
`;


export const NoResult = styled.div`
  font-size:${fontSize.normal};
  font-weight:${fontWeight.fontWeightLight};
  color:${colors.muted};
  padding:${spacing.size5};
  text-align:center;
`;

export default ListGroup;
