/**
 * @ External Dependencies
 */
import styled from "styled-components";
import { spacing } from "../global/variables";

/**
 * @ Internal Dependencies
 */

const Container = styled.div`
  width: 100%;
  padding-right: ${spacing.size3};
  padding-left: ${spacing.size3};
  margin-right: auto;
  margin-left: auto;
  max-width: 1024px;
  ${(props) =>
    props.fluid &&
    `
     max-width:100%;
     
   `};
  ${(props) =>
    props.pageContent &&
    `
     padding-bottom:${spacing.size3};
     
   `}
`;

export default Container;
