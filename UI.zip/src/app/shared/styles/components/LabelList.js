/**
 * @ External Dependencies
 */
import styled from "styled-components";

/**
 * @ Internal Dependencies
 */

import {
  colors,
  spacing,
  fontSize,
  borderRadius, 
} from "../global/variables";

export default styled.ul`
	display: flex;
	flex-wrap:wrap;
	li {
		margin: 1px;
	}
	li a {
		display: inline-block;
		border: solid 1px ${colors.metal};
		font-size: ${fontSize.xs};
		position: relative;
		text-decoration: none;
		padding: ${spacing.xs};
		background: ${colors.cotton};
		border-radius: ${borderRadius.xs};
		position: relative;
		&:hover {
			color: ${colors.charcoal};
		}
	}
	${(props) =>
    props.dismissible &&
		`
		li a {
			padding-right: ${spacing.size3};
			span {
				position: absolute;
				right: ${spacing.xs};
				&:hover {
					color: ${colors.cherry};
				}
			}
		}
   
  `}
`;
