/**
 * @ External Dependencies
 */
import styled from "styled-components";

/**
 * @ Internal Dependencies
 */
import { colors, fontWeight, spacing, device } from "../global/variables";

const Card = styled.div`
  background-color: #fff;
  border-radius: 2px;
  flex-grow: 1;
  border: solid 1px ${colors.metal};

  ${(props) =>
    props.flex &&
    `
     display:flex;
     flex-direction:column;
     
   `}

   ${(props) =>
    props.dimmer &&
    `
     position:relative;
     
   `}
`;

export const CardHeader = styled.div`
  border-bottom: solid 1px ${colors.metal};
  background: ${colors.fog};
  padding: ${spacing.size1} ${spacing.size2};
  display: flex;
  color: inherit;
`;

export const CardBody = styled.div`
  flex: 1 1 auto;
  padding: ${spacing.size2};
  color: inherit;

  ${(props) =>
    props.large &&
    `
     padding:${spacing.size4};
     @media ${device.lg} {
      padding:${spacing.size2};
     }
   `}

  ${(props) =>
    props.flex &&
    `
     display:flex;
     flex-direction:column;
     
   `}
`;

export const CardFooter = styled.div`
  border-top: solid 1px ${colors.metal};
  background: ${colors.gray25};
  padding: ${spacing.size2};
  display: flex;
  justify-content: end;
  color: inherit;

  button {
    margin-left: ${spacing.size1};
  }

  ${(props) =>
    props.large &&
    `
     padding:${spacing.size4};
     
   `}

  ${(props) =>
    props.flex &&
    `
     display:flex;
     flex-direction:column;
     flex-grow:1;
     
   `}
`;

export const CardTitle = styled.h4`
  display: block;
  margin: 0 0 1rem;
  color: ${colors.midnight};
  font-weight: ${fontWeight.fontWeightMedium};
  line-height: 1.5rem;
`;

export default Card;
