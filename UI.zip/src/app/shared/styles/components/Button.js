/**
 * @ External Dependencies
 */
import styled from "styled-components";
import { theme } from "../global/theme";

/**
 * @ Internal Dependencies
 */

import {
  device,
  colors,
  fontWeight,
  spacing,
  fontSize,
  hexWithOpacity,
} from "../global/variables";

const { haze, charcoal, midnight, cotton, cherry } = colors;

export default styled.button`
	display: inline-flex;
	align-items: center;
	white-space: nowrap;
	justify-content: center;
	padding: ${spacing.sm} ${spacing.size3};
	text-decoration: none;
	border-radius: ${spacing.size4};
	border: 2px solid ${midnight};
	letter-spacing: 0.5px;
	font-size: ${fontSize.sm};
	height: ${theme.base_util_height};
	font-weight: ${fontWeight.fontWeightBold};
	cursor: pointer;
	text-transform: uppercase;
	color: ${cotton};
	background: ${colors.midnight};
	transition: background 0.3s, color 0.3s;

	&:hover {
		background: ${charcoal};
		color: #fff;
	}

	${(props) =>
    props.lg &&
		`
    font-size:${fontSize.lg};
    font-weight:${fontWeight.fontWeightMedium};
    height:48px;
    padding: ${spacing.size2} ${spacing.size6};
  `}

	${(props) =>
    props.sm &&
		`
    font-size:${fontSize.xs};
    font-weight:${fontWeight.fontWeightNormal};
    border: 1px solid ${midnight};
    height: 28px;
    padding: ${spacing.xs} ${spacing.size3};
  `}

  ${(props) =>
    props.xs &&
		`   
    font-size:${fontSize.xs};
    font-weight:${fontWeight.fontWeightNormal};
    border: 1px solid ${midnight};
    text-transform:none;
    height: 21px;
    padding: ${spacing.xs} ${spacing.size2};
  `}

  ${(props) =>
    props.fluid &&
		`   
    width:100%;
  `}

  ${(props) =>
    props.flat &&
		`
      border-radius:0;
  `}

  ${(props) =>
    props.icon &&
		`
    padding: ${spacing.xs} ${spacing.size1};
    font-size:${fontSize.normal};
		svg {
      fill:${colors.cotton};
      font-weight:${fontWeight.fontWeightBold};
    }
  `}

  ${(props) =>
    props.hasIcon &&
		`
    color:${colors.cotton};
		svg {
      font-size:${fontSize.normal};
      margin-right:${spacing.size1};
      fill:${colors.cotton};
      font-weight:${fontWeight.fontWeightBold};
    }
  `}

  ${(props) =>
    props.primary &&
		`
    border: 1px solid ${cherry};
    color: ${cotton};
    background: ${cherry};
    &:hover {
			background: ${cotton};
      color: ${cherry};
  `}
  
	${(props) =>
    props.default &&
		`
		border: 1px solid ${hexWithOpacity(haze, 0.3)};
		color: ${haze};
    background:${colors.cotton};
		&:hover {
			background: ${haze};
    }
  `}

  ${(props) =>
    props.disabled &&
		`
		cursor: not-allowed;
    color:${hexWithOpacity(haze, 0.8)};
    background: ${charcoal};
    &:hover {
      color:${hexWithOpacity(haze, 0.8)};
    }
  `}

  ${(props) =>
    props.btnLink &&
		`
		border:none;
    color: ${haze};
    background:none;
    height:auto;
    padding:0;
    &:hover {
      background:none;
      color:${colors.charcoal};
    }
  `}

  ${(props) =>
    props.isLoading &&
		`
      position: relative;
      color: transparent!important;
      pointer-events: none;
      svg {
        fill: transparent!important;
      }
      &:after {
        content: "";
        display: inline-block;
        vertical-align: text-bottom;
        border: 2px solid ${colors.cotton};
        border-right-color: transparent;
        border-radius: 100rem;
        color:${colors.cotton};
        position: absolute;
        width: calc(${spacing.size2} + ${spacing.xs});
        height: calc(${spacing.size2} + ${spacing.xs});
        animation: spinner 0.75s linear infinite;
      }
    `}

  ${(props) =>
    props.submittingWithSpinner &&
		`
    background: ${midnight};
    color: ${midnight};
    cursor: not-allowed;
    text-align: center;
    padding: 10px 31px;
    min-width: 128px;
    font-size: 11px;
    &:hover {
			color: ${midnight};
    }
  `}

  ${(props) =>
    props.loginButton &&
		`
    width: 216px;
    background: ${colors.midnight};
    font-weight: ${fontWeight.fontWeightMedium};
    letter-spacing:.75px;
    @media${device.lg} {
      width: 190px;
      padding: 12px 15px;
      font-size: 11px;
    }

    &:hover {
      background: ${charcoal};
    }
  `}

  ${(props) =>
    props.loginWithSpinner &&
		`
    color: ${midnight};
    width: 216px;
    background: ${colors.midnight};
    cursor: not-allowed;
    @media${device.lg} {
      width: 190px;
    }
   
    &:hover {
      color: ${charcoal};
    }
  `}
`;

export const ButtonList = styled.div`
	display: flex;

	button {
		margin-left: ${spacing.size1};
	}
`;

export const ButtonWithSpinnerContainer = styled.div`
	display: inline-block;
	position: relative;
`;
