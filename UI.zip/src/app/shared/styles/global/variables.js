
export const breakpoints = {
  xs: 0,
  sm: "576px",
  md: "768px",
  lg: "992px",
  xl: "1200px",
  xxl: "1400px",
};

export const device = {
  xxl: `(max-width: ${breakpoints.xxl})`,
  xl: `(max-width: ${breakpoints.xl})`,
  lg: `(max-width: ${breakpoints.lg})`,
  md: `(max-width: ${breakpoints.md})`,
  sm: `(max-width: ${breakpoints.sm})`,
  xs: `(max-width: ${breakpoints.xs})`,
};

// BREAKPOINTS
export const minWidth = {
  xxl: `(min-width: ${breakpoints.xxl})`,
  xl: `(min-width: ${breakpoints.xl})`,
  lg: `(min-width: ${breakpoints.lg})`,
  md: `(min-width: ${breakpoints.md})`,
  sm: `(min-width: ${breakpoints.sm})`,
};

export const hexWithOpacity = (hexColor, alpha) => `rgba(
      ${parseInt(hexColor.slice(1, 3), 16)},
      ${parseInt(hexColor.slice(3, 5), 16)},
      ${parseInt(hexColor.slice(5, 7), 16)},
      ${alpha})`;


export const colors = {
  fog: "#f9f9f9",
  haze: "#8a909c",
  concrete: "#e5e5e5",
  cloud: "#f7f7f7",
  cherry: "#d82237",
  lightTangerine: "#e46473",
  cotton: "#ffffff",
  midnight: "#1c1c1c",
  blackberry: "#001f28",
  charcoal: "#424242",
  grass: "#4ca311",
  metal: "#e1e5ea",
  muted: "#616876",
  gray50: "#cccccc",
  gray25: "#fafafa",
};


// Font Size
export const fontSize = {
  xs: "10px",
  sm: "11px",
  md: "13px",
  lg: ".875rem",
  normal: "1rem",
  xl: "1.25rem",
  xxl: "1.5rem",
  display1: "1.75rem",
  display2: "2rem;",
  display3: "2.5rem",
  display4: "5rem",
};

// Spacing Size
export const spacing = {
  xs: ".25rem",
  sm: ".5rem",
  size1: ".75rem",
  size2: "1rem",
  size3: "1.5rem",
  size4: "2rem",
  size5: "2.5rem",
  size6: "3rem",
  size7: "3.5rem",
  size8: "4rem",
};

export const dir = {
  left: "left",
  right: "right",
  top: "top",
  bottom: "bottom",
};

// Line Height
export const lineHeight = {
  normal: 1,
  loose: 1.2,
  tight: 0.9,
};

// font Weight
export const fontWeight = {
  fontWeightThin: 100,
  fontWeightLight: 300,
  fontWeightNormal: 400,
  fontWeightMedium: 500,
  fontWeightBold: 600,
};

// font Weight
export const borderRadius = {
  xs: "3px",
  sm: "5px",
  md: "8px",
  lg: "12px",
  xl: "15px",
};
