/**
 * @ External Dependencies
 */
import styled from "styled-components";
import { fontWeight, colors, spacing, fontSize } from "./variables";
import { Link } from "react-router-dom";
/**
 * @ Internal Dependencies
 */

export const StyledLink = styled(Link)`
	text-decoration: none;
	color: ${colors.midnight};
	:hover {
		color: ${colors.haze};
	}
`;

export const StyledExternalLink = styled.a`
	text-decoration: none;
	color: ${colors.midnight};
	letter-spacing: 2.5px;
	text-transform: uppercase;
	font-weight: ${fontWeight.fontWeightNormal};
	:hover {
		color: ${colors.cherry};
	}
`;

export const StyledSecondaryText = styled.p`
	color: ${colors.muted};
	font-size: ${fontSize.md};
	line-height: 125%;
	margin-bottom: ${spacing.size3};
`;

export const Lead = styled.h4`
	font-size: 21px;
	font-weight: ${fontWeight.fontWeightLight};
`;
