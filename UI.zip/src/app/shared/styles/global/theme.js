export const theme = {
  container: "1360px",
  header_height: "60px",
  sidebar_width_collapsed: "50px",
  sidebar_width_expanded: "280px",
  font: "Roboto",
  font_size_base: "13px",
  line_height_base: "1.25",
  font_size_sm: "11px",
  base_util_height: "38px",
  font_size: {
    h1: "36px",
    h2: "30px",
    h3: "24px",
    h4: "17px",
    h5: "14px",
    h6: "12px",
  },
};

export const lightTheme = {
  text: "rgb(20, 20, 20)",
  text2: "rgb(55, 55, 55)",
  textInvert: "rgb(245, 245, 245)",
  textInvert2: "rgb(210, 210, 210)",
  primary: "#ff0000",
  primary2: "rgb(200, 117, 147)",
  bg: "rgb(252, 252, 252)",
  bg2: "rgb(225, 225, 225)",
};

export const darkTheme = {
  text: "rgb(245, 245, 245)",
  text2: "rgb(210, 210, 210)",
  textInvert: "rgb(20, 20, 20)",
  textInvert2: "rgb(55, 55, 55)",
  primary: "rgb(200, 117, 196)",
  primary2: "rgb(200, 117, 147)",
  bg: "rgb(3, 3, 3)",
  bg3: "#ffff00",
};
