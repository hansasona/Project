/* eslint-disable react/display-name */
import React from "react";

import Button, { ButtonWithSpinnerContainer } from "../../components/Button";
import { ButtonSpinner } from "../../components/Spinner";

const ButtonWithLoader = ({
  isLoading,
  confirmText,
  loadingStyleProp,
  notLoadingStyleProp,
  clickHandler,
  disabled,
  title,
  autoFocus,
}) =>
  isLoading ? (
    <ButtonWithSpinnerContainer>
      <Button
        type="submit"
        {...(loadingStyleProp ? { [loadingStyleProp]: true } : {})}
      >
        {confirmText}
      </Button>
      <ButtonSpinner />
    </ButtonWithSpinnerContainer>
  ) : (
    <>
      <Button
        type="submit"
        autoFocus={autoFocus}
        disabled={disabled}
        disabledStyleProp={disabled}
        {...(notLoadingStyleProp ? { [notLoadingStyleProp]: true } : {})}
        onClick={clickHandler}
        title={title}
      >
        {confirmText}
      </Button>
    </>
  );
export default ButtonWithLoader;
