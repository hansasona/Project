export const homePageStyles = {
  control: (provided, state) => ({
    ...provided,
    fontWeight: state.isSelected ? "bold" : "normal",
    borderColor: "#007bff",
    backgroundColor: "white",
  }),
  indicatorSeparator: () => ({
    display: "none",
  }),

  dropdownIndicator: (provided) => ({
    ...provided,
    paddingLeft: "10px",
    "&:hover": {
      color: "#007bff",
    },
    color: "#007bff",
  }),

  placeholder: (provided) => ({
    ...provided,
    paddingLeft: "10px",
    color: "#007bff",
  }),

  singleValue: (provided) => ({
    ...provided,
    color: "#007bff",
  }),

  menu: (provided) => ({
    ...provided,
    marginTop: "0",
  }),
};

export const dashboardStyles = {
  container: (provided) => ({
    ...provided,
    width: "170px",
  }),
  control: (provided, state) => ({
    ...provided,
    fontWeight: state.isSelected ? "bold" : "normal",
    borderColor: "#007bff",
    backgroundColor: "white",
    height: "31px",
    fontSize: "14px",
    minHeight: "31px",
  }),
  indicatorSeparator: () => ({
    display: "none",
  }),

  dropdownIndicator: (provided) => ({
    ...provided,
    padding: "1px 1px 1px 1px",
    "&:hover": {
      color: "#007bff",
    },
    color: "#007bff",
  }),

  placeholder: (provided) => ({
    ...provided,
    color: "#007bff",
  }),

  singleValue: (provided) => ({
    ...provided,
    color: "#007bff",
  }),

  menu: (provided) => ({
    ...provided,
    marginTop: "0",
    scrollBehavior: "auto",
  }),
};

export const pageSizesStyle = () => {
  const style = {
    control: (base) => ({
      ...base,
      border: "0 !important",
      boxShadow: "0 !important",
      "&:hover": {
        border: "0 !important",
      },
      height: 25,
      minHeight: 25,
      cursor: "pointer",
    }),
    menu: (base) => ({
      ...base,
      borderRadius: 0,
      marginTop: 2,
    }),
    menuList: (base) => ({
      ...base,
      padding: 0,
      height: 70,
    }),
    valueContainer: (base) => ({
      ...base,
      marginTop: -5,
    }),
    indicatorSeparator: () => ({
      display: "none",
    }),
    indicatorsContainer: () => ({
      marginTop: -5,
    }),
  };
  return style;
};

export const lightPositionStyles = {
  control: (provided, state) => ({
    ...provided,
    fontWeight: state.isSelected ? "bold" : "normal",
    borderColor: "#007bff",
    backgroundColor: "white",
  }),
  indicatorSeparator: () => ({
    display: "none",
  }),

  dropdownIndicator: (provided) => ({
    ...provided,
    paddingLeft: "10px",
    "&:hover": {
      color: "#007bff",
    },
    color: "#007bff",
  }),

  placeholder: (provided) => ({
    ...provided,
    paddingLeft: "10px",
    color: "#007bff",
  }),

  singleValue: (provided) => ({
    ...provided,
    color: "#007bff",
  }),

  menu: (provided) => ({
    ...provided,
    marginTop: "0",
  }),
};

export const stateStyle = () => {
  const style = {
    control: (base) => ({
      ...base,
      border: "0 !important",
      boxShadow: "0 !important",
      "&:hover": {
        border: "0 !important",
      },
      height: 7,
      minHeight: 7,
      cursor: "pointer",
    }),
    menu: (base) => ({
      ...base,
      borderRadius: 0,
      marginTop: 2,
    }),
    menuList: (base) => ({
      ...base,
      padding: 0,
      height: 40,
    }),
    valueContainer: (base) => ({
      ...base,
      marginTop: -7,
    }),
    indicatorSeparator: () => ({
      display: "none",
    }),
    indicatorsContainer: () => ({
      marginTop: -7,
    }),
  };
  return style;
};
