import React from "react";

import IconSvgComponent from "shared/ui/icons/IconSvgComponent";

import { DebounceInput } from "react-debounce-input";
import { SearchBox } from "../../styles/components/PageList";

const Searchbox = ({ searchText, searchChangeHandler, filterChangeHandler }) => {
  // Enter key handler
  const onKeyDownHandler = (e) => {
    if (e.keyCode === 13) {
      filterChangeHandler({ search_key: searchText });
    }
  };

  return (
    <SearchBox>
      <DebounceInput
        type="text"
        className="search"
        placeholder="Search"
        onKeyDown={onKeyDownHandler}
        value={searchText}
        onChange={searchChangeHandler}
      />
      {searchText ? (
        <button className="Search-box-button" onClick={() => filterChangeHandler({ search_key: "" })}>
          <IconSvgComponent svgFileName="searbox-close" title="Reset" alt="SearboxClose" />
        </button>
      ) : null}
      <button type="button" className="searchButton" onClick={() => filterChangeHandler({ search_key: searchText })}>
        <IconSvgComponent className="search-icon" svgFileName="searchbox" title="Search" alt="Search" />
      </button>
    </SearchBox>
  );
};

export default Searchbox;
