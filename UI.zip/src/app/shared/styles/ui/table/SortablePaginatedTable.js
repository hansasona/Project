import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import Table from "rc-table";
import reactStringReplace from "react-string-replace";
import { SORT_ORDER } from "shared/constants/table";
import { tableColumnSort } from "shared/utilities/table";
import { SortArrowSpan } from "shared/styles/components/Table";
import ReactPaginate from "react-paginate";
import { PaginationStyles, TableFilters } from "shared/styles/components/PageList";
import { PAGINATION_OPTIONS } from "shared/constants/pagination";
import { PaginationSelect } from "shared/styles/components/SelectField";
import { PAGINATION_DEFAULT_OPTION } from "shared/constants/pagination";
import Searchbox from "shared/ui/tableFilters/Searchbox";
import colors from "shared/constants/colors";
import { MatrixSelect } from "shared/styles/components/SelectField";
import * as exports from "shared/constants/matrixOptions";

// custom header cell component that wraps/overwrites default table header cell (see: Table -> components prop line 56)
const SortableHeaderCell = ({ children, isSorted, sortOrder, sortIndex, style, handleSort }) => {
  const onClick = sortIndex && (() => handleSort(sortIndex));
  const sortArrow = sortOrder === SORT_ORDER.ASC ? String.fromCharCode(9650) : String.fromCharCode(9660);

  return (
    <th onClick={onClick} style={style}>
      {children}
      <SortArrowSpan isSorted={isSorted}>{sortArrow}</SortArrowSpan>
    </th>
  );
};

const SortableTable = ({
  style,
  className,
  rowClassName,
  columns,
  tableData,
  onRow,
  rowKey,
  scroll,
  children,
  components,
  emptyText,
  refresh,
  optionChangeHandler,
  selectedAccount,
  envList,
  defaultSortOrder,
  hideEnvDropdown,
}) => {
  const [transformedData, updateTransformedData] = useState({
    tableData,
    index: null,
    order: null,
    isSorted: false,
  });
  const [pageSize, setPageSize] = useState(PAGINATION_DEFAULT_OPTION);
  const [currentPageData, setCurrentPageData] = useState(tableData.slice(0, pageSize.value));
  const [currentPageNum, setCurrentPageNum] = useState(0);
  const [totalPageCount, setTotalPageCount] = useState(Math.ceil(tableData.length / pageSize.value));
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    setTotalPageCount(Math.ceil(transformedData.tableData.length / pageSize.value));
    handlePaginate({ selected: currentPageNum });
  }, [transformedData]);

  useEffect(() => {
    handlePaginate({ selected: 0 });
  }, [refresh]);

  const handleSort = (sortIndex) => {
    const { tableData, order, index } = transformedData;
    let sortOrder;

    if (sortIndex === index) {
      // if we are clicking on a column thats already been sorted, we want to sort it using the reverse order
      sortOrder = order === SORT_ORDER.ASC ? SORT_ORDER.DESC : SORT_ORDER.ASC;
    } else {
      sortOrder = defaultSortOrder ? defaultSortOrder : SORT_ORDER.ASC;
    }

    const newTransformedData = tableColumnSort({
      data: tableData,
      sortIndex,
      order: sortOrder,
    });
    updateTransformedData({
      tableData: newTransformedData,
      order: sortOrder,
      index: sortIndex,
      isSorted: true,
    });
  };

  const handlePaginate = (pageData) => {
    let pNum = pageData.selected;
    let pSize = pageData.pageSize?.value ? pageData.pageSize?.value : pageSize.value;
    let items = transformedData.tableData.slice(pNum * pSize, pNum * pSize + pSize);
    if (!items.length && pNum) {
      items = transformedData.tableData.slice((pNum - 1) * pSize, (pNum - 1) * pSize + pSize);
      pNum = pNum - 1;
    }
    setCurrentPageData(items);
    setCurrentPageNum(pNum);
  };

  const searchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };

  const getIndexedColumnValue = (row, dataIndex) => {
    dataIndex = dataIndex.replace(/\[(\w+)\]/g, ".$1"); // convert indexes to properties
    dataIndex = dataIndex.replace(/^\./, ""); // strip a leading dot
    const formattedDataIndex = dataIndex.split(".");
    for (let i = 0, n = formattedDataIndex.length; i < n; ++i) {
      const col = formattedDataIndex[i];
      if (col in row) {
        row = row[col];
      } else {
        return;
      }
    }
    return row;
  };

  const replaceByHighlightedData = (fieldData, col, highlightedData) => {
    if (!col.searchIndex) {
      fieldData[col.dataIndex] = highlightedData;
    } else {
      if (col.searchIndex.includes(".")) {
        const levels = col.searchIndex.split(".");
        fieldData[levels[0]][levels[1]] = highlightedData;
      } else {
        fieldData[col.searchIndex] = highlightedData;
      }
    }
    return fieldData;
  };

  const filterChangeHandler = (e) => {
    setSearchText(e.search_key);
    let currTransformedData = { ...transformedData };
    if (!e.search_key) {
      const newTransformedData = tableColumnSort({
        data: tableData,
        sortIndex: currTransformedData.index,
        order: currTransformedData.order,
      });
      currTransformedData.tableData = newTransformedData;
      updateTransformedData(currTransformedData);
      return;
    }
    const searchValue = e.search_key?.toLowerCase();
    const filteredData = tableData
      .map((row) => {
        let fieldData = { ...row };
        let flag = false;
        columns.forEach((col) => {
          if (col.searchable === true && col.dataIndex) {
            let indexedValue = getIndexedColumnValue(
              fieldData,
              col.searchIndex ? col.searchIndex : col.dataIndex
            )?.toString();
            if (indexedValue) {
              indexedValue = indexedValue.toString();
            }
            if (indexedValue && indexedValue?.toLowerCase()?.includes(searchValue)) {
              flag = true;
              const highlightedData = reactStringReplace(indexedValue, e.search_key, (match, fieldData) => (
                <span key={fieldData} style={{ fontWeight: "bolder", color: colors.midnight }}>
                  {match}
                </span>
              ));
              fieldData = replaceByHighlightedData(fieldData, col, highlightedData);
            }
          }
        });
        if (flag) return fieldData;
      })
      .filter(Boolean);
    currTransformedData.tableData = filteredData;
    if (e.page_number == true) {
      setCurrentPageNum(currentPageNum);
    } else {
      setCurrentPageNum(0);
    }
    updateTransformedData(currTransformedData);
  };

  const configureCustomHeader = (column) => {
    return {
      ...column,
      onHeaderCell: (record) => {
        const prevOnHeaderCell = column.onHeaderCell ? column.onHeaderCell(record) : {};
        if (!column.dataIndex) return prevOnHeaderCell;

        const style = prevOnHeaderCell.style ? { ...prevOnHeaderCell.style, cursor: "pointer" } : { cursor: "pointer" };

        return {
          ...prevOnHeaderCell,
          style,
          handleSort,
          sortIndex: record.dataIndex,
          isSorted: record.dataIndex === transformedData.index,
          sortOrder: transformedData.order,
        };
      },
    };
  };

  const accChangeHandler = (e) => {
    optionChangeHandler(e);
  };

  const updatePageSize = (e) => {
    setPageSize(e);
    setTotalPageCount(Math.ceil(transformedData.tableData.length / e.value));
    handlePaginate({ selected: 0, pageSize: e });
  };

  // override columns and use existing/mandatory column props to pass in a sortIndex value and local handleSort function
  const sortableColumns = (() => {
    // if child column components are passed convert them to columns
    if (children) {
      return React.Children.map(
        children,
        (child) =>
          child &&
          Object.prototype.hasOwnProperty.call(child.props, "title") &&
          Object.prototype.hasOwnProperty.call(child.props, "dataIndex") &&
          configureCustomHeader(child.props)
      );
    }
    return columns.map((column) => configureCustomHeader(column));
  })();

  useEffect(() => {
    const { index, order } = transformedData;
    updateTransformedData({
      ...transformedData,
      tableData: tableColumnSort({ data: tableData, sortIndex: index, order }),
    });
    filterChangeHandler({ search_key: searchText, page_number: true });
  }, [tableData]);

  useEffect(() => {
    // default sort by first column
    if (!transformedData.isSorted) {
      const defaultSortIndex = sortableColumns.find((c) => c.dataIndex && c.title).dataIndex;
      handleSort(defaultSortIndex);
    }
  }, [transformedData.isSorted]);

  return (
    <PaginationStyles>
      <TableFilters>
        <div className="field-wrapper">
          {selectedAccount && !hideEnvDropdown ? (
            <div className="option">
              <div className="show-label">Env: </div>
              <MatrixSelect
                value={selectedAccount}
                clearable={false}
                searchable={false}
                autosize={true}
                options={envList.filter(
                  (d) => (d.value === "Dev") & (d.envName === "Dev") || d.envName === "Staging" || d.envName === "Prod"
                )}
                placeholder={"Select"}
                onChange={accChangeHandler}
              />
            </div>
          ) : null}
          <Searchbox
            searchText={searchText}
            searchChangeHandler={searchChangeHandler}
            filterChangeHandler={filterChangeHandler}
          />
        </div>
        <div className="pagination">
          <div className="page-size-dd">
            <div className="show-label">show</div>
            <PaginationSelect
              value={pageSize.value}
              clearable={false}
              searchable={false}
              autosize={true}
              options={PAGINATION_OPTIONS}
              onChange={updatePageSize}
            />
          </div>
          <ReactPaginate
            previousLabel={"previous"}
            nextLabel={"next"}
            breakLabel={"..."}
            breakClassName={"break-me"}
            pageCount={totalPageCount}
            marginPagesDisplayed={2}
            pageRangeDisplayed={2}
            onPageChange={handlePaginate}
            containerClassName={"pagination"}
            activeClassName={"active"}
            forcePage={currentPageNum}
            nextClassName={!currentPageData.length ? "disabled next-page" : "next-page"}
          />
        </div>
      </TableFilters>
      <Table
        style={style}
        className={className}
        rowClassName={rowClassName}
        columns={sortableColumns}
        data={currentPageData}
        onRow={onRow}
        rowKey={rowKey}
        scroll={scroll}
        emptyText={emptyText}
        components={{
          ...components,
          header: {
            ...(components && components.header),
            ...{ cell: SortableHeaderCell },
          },
        }}
      />
      <TableFilters>
        <div />
        <div className="pagination">
          <div className="page-size-dd">
            <div className="show-label">show</div>
            <PaginationSelect
              value={pageSize.value}
              clearable={false}
              searchable={false}
              autosize={true}
              options={PAGINATION_OPTIONS}
              onChange={updatePageSize}
            />
          </div>
          <ReactPaginate
            previousLabel={"previous"}
            nextLabel={"next"}
            breakLabel={"..."}
            breakClassName={"break-me"}
            pageCount={totalPageCount}
            marginPagesDisplayed={2}
            pageRangeDisplayed={2}
            onPageChange={handlePaginate}
            containerClassName={"pagination"}
            activeClassName={"active"}
            forcePage={currentPageNum}
            nextClassName={!currentPageData.length ? "disabled next-page" : "next-page"}
          />
        </div>
      </TableFilters>
    </PaginationStyles>
  );
};

export default connect((state) => ({
  envList: state.user.envList,
}))(SortableTable);
