import React from "react";
import { Helmet } from "react-helmet";
import { useSelector } from "react-redux";
import { ThemeProvider } from "styled-components";
import { GlobalStyles } from "./shared/styles/global/globalStyles";
import { darkTheme, lightTheme } from "./shared/styles/global/theme";
import AppRoutes from "./route/routes";
import Notifications from "./shared/components/Notification";
import { injectStyle } from "react-toastify/dist/inject-style";

const App = () => {
  const { theme } = useSelector((state) => state.ui);
  const currentTheme = theme === "light" ? lightTheme : darkTheme;
  injectStyle(); // inject notification styles

  return (
    <ThemeProvider theme={currentTheme}>
      {/* Global Styles */}
      <GlobalStyles />
      {/* Global Styles */}
      <AppRoutes />
      <Helmet
        titleTemplate="%s - Illumination Designer"
        defaultTitle="Illumination Designer"
      >
        <meta name="description" content="A React application" />
      </Helmet>
      <Notifications />
    </ThemeProvider>
  );
};

export default App;
