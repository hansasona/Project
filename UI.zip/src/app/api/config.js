import { configPath } from "../shared/constants/endpoints";
import { apiCall } from "./api";
import { getUserId } from "../shared/utils/localStore";

export const getConfigList = async (pageSize, lastEvaluatedKey = {}, configName = "") => {
  const userId = getUserId();
  const queryStringParameters = { userId, pageSize: pageSize };
  if (configName && lastEvaluatedKey.configId) {
    queryStringParameters.configName = configName;
    queryStringParameters.lastEvaluatedKey = lastEvaluatedKey.configId;
    queryStringParameters.lastEmailId = lastEvaluatedKey.emailId;
    queryStringParameters.lastModifiedDate = lastEvaluatedKey.lastModifiedDate;
    queryStringParameters.lastuserId = lastEvaluatedKey.userId;
  } else if (lastEvaluatedKey.configId) {
    queryStringParameters.lastEmailId = lastEvaluatedKey.emailId;
    queryStringParameters.lastEvaluatedKey = lastEvaluatedKey.configId;
    queryStringParameters.lastModifiedDate = lastEvaluatedKey.lastModifiedDate;
    queryStringParameters.lastuserId = lastEvaluatedKey.userId;
  } else if (configName) {
    queryStringParameters.configName = configName;
  }
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: configPath,
    method: "get",
    queryStringParameters,
  });
};

export const createConfig = async (body) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: configPath,
    method: "post",
    body,
  });
};