import { apiCall } from "./api";
import { signUpPath } from "../shared/constants/endpoints";

export const signUp = async (body) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: signUpPath,
    method: "post",
    body,
  });
};
