/**
 * External dependencies
 */
import { Amplify, API } from "aws-amplify";
import apiUrl from "../shared/utils/url";
import { getIdToken, isExpired, getAccessToken, getRefreshToken, updateTokens } from "../shared/utils/localStore";
import { ERROR_MESSAGES } from "../shared/constants/messages";
import { getRefreshedToken } from "../api/login";
import { toast } from "react-toastify";

export const getAuthToken = () => {
  return getAccessToken();
};

Amplify.configure({
  API: {
    endpoints: [
      {
        name: "cloudfrontAPI",
        endpoint: apiUrl,
        custom_header: async () => {
          return {
            Authorization: getAuthToken(),
          };
        },
      },
    ],
  },
});

const extractServerError = (e) => {
  return e.response.data && e.response.data.ERROR_MESSAGE_CODE ? e.response 
    : "Something went wrong. Please try later."; // if you see this error, backend is not sending data.errorMessage
};

export const apiCall = async ({ endpoint, path, method, queryStringParameters, body, headers, responseType }) => {
  try {
    if (
      !path.toString().includes("login") &&
      !path.toString().includes("users") &&
      !path.toString().includes("set-password") &&
      !path.toString().includes("forgot-password") &&
      !path.toString().includes("refresh-token")
    ) {
      if(isExpired()) {
        const { response } = await getRefreshedToken(getRefreshToken());
        if(response && response.message && response.message.AccessToken) {
          let tokenData = response.message;
          updateTokens(tokenData);
        }
      }
    }

    const apiResponse = await API[method](endpoint || "cloudfrontAPI", path, {
      responseType,
      response: true,
      queryStringParameters: queryStringParameters,
      body,
      headers,
    }); 
    return { response: apiResponse.data };
   
  } catch (e) {
    if (e.status === 400 && e.data && e.data.ERROR_MESSAGE_CODE === "NotAuthorizedException") {
      // In case of token expired
      toast(ERROR_MESSAGES.SESSION_EXPIRED, { type: "error" });
      setTimeout(() => {
        window.location.href = "/";
      }, 3000);
    } else if (!e.response || !e.response.status) {
      // if you see this error, backend is not sending response.status
      throw extractServerError(e);
    } else {
      throw extractServerError(e);
    }
  }
};
