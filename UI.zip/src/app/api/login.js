// eslint-disable-next-line max-len
import { loginPath,logoutPath, setpasswordPath, forgotPasswordPath, refreshedToken, changePasswordPath,productPath} from "../shared/constants/endpoints";
import { apiCall } from "./api";

export const login = async ({ username, password }) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: loginPath,
    method: "post",
    headers: {
      "x-login": username,
      "x-password": password,
    },
  });
}; 
export const products = async (body) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: productPath,
    method: "post",
    body,
  });
}; 
export const setpassword = async ({ userId, password, token }) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: setpasswordPath,
    method: "post",
    body: {
      userId: userId,
      password: password,
      token: token,
      changePassword: false,
    },
  });
};

export const sendPasswordEmail = async ({ email }) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: forgotPasswordPath,
    method: "post",
    body: {
      email,
    },
  });
};

export const getRefreshedToken = async (refreshKey) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: refreshedToken,
    method: "post",
    body: {
      refreshToken: refreshKey,
    },
    headers: {
      Authorization: "",
    },
  });
};

export const logout = async ({ accessToken }) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: logoutPath,
    method: "post",
    headers: {
      Authorization: accessToken,
    },
  });  
};
export const changeUserPassword = async ({ email, currentPassword, newPassword }) => {
  return await apiCall({
    endpoint: "cloudfrontAPI",
    path: changePasswordPath,
    method: "post",
    body: {
      email: email,
      currentPassword: currentPassword,
      newPassword: newPassword
    },
  });
};
